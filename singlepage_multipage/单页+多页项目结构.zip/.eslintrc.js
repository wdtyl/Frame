module.exports = {
  root: true,
  env: {
    node: true
  },
  extends: ['plugin:vue/essential', '@vue/standard'],
  rules: {
    'no-console': 'off',
    'no-debugger': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    'no-alert': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    'no-multiple-empty-lines': [0, { max: 2 }],
    'no-mixed-spaces-and-tabs': [2, false],
    'no-trailing-spaces': 2,
    quotes: [2, 'single'],
    'no-cond-assign': [2, 'always'],
    semi: [0, 'never'],
    'comma-dangle': [0, 'never'],
    indent: [
      0,
      4,
      {
        SwitchCase: 1,
        MemberExpression: 1,
        ObjectExpression: 1
      }
    ],
    'keyword-spacing': [
      2,
      {
        before: true,
        after: true
      }
    ],
    'space-infix-ops': [
      2,
      {
        int32Hint: false
      }
    ],
    'linebreak-style': [2, 'unix'],
    'no-unexpected-multiline': [2],
    'object-curly-newline': [
      0,
      {
        ObjectExpression: {
          minProperties: 1
        },
        ObjectPattern: {
          multiline: true
        }
      }
    ],
    'object-property-newline': 2,
    'space-before-function-paren': 0
  },
  parserOptions: {
    parser: 'babel-eslint'
  },
  globals: {
    gl: true,
    $i18n: true,
    EXIF: true,
    _fmOpt: true,
    Fingerprint2: true,
  }
}
