# panda_vietnam_project 越南项目

## node 内存溢出问题

运行 npm run fix-memory-limit
运行 npm run dev
根据提示删除相应文件中不识别的标识

## Project setup

```
npm/cnpm install
```

## 生产包

```
npm run build-pro
```

## 测试压缩包

```
npm run build-release
```

## 测试包未压缩

```
npm run build-dev
```

### Lints and fixes files

```
npm run lint
```

### 测试地址

```
https://dev-sit-vn.pinganzhiyuan.com/static/vn/index.html?channelKey=Facebook&local=zh
https://dev-sit-vn.pinganzhiyuan.com/static/vn/index.html?channelKey=Facebook&local=vn

https://dev-sit-ind.panda-fintech.com/static/vn/index.html?channelKey=Facebook&local=vn
```

### 生产地址

```
https://www.easypay.vn/
https://www.easypay.vn/static/vn/
https://pub-api.vn-aifintech.cc/static/vn/index.html
```
