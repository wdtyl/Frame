// 判断是iOS 还是 Android，或其他
import service from './service'
import axios from 'axios'
const ISAPPLEDEVICE = !!/(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent)
const ANDROIDDEVICE = !!/(Android)/i.test(navigator.userAgent)
/**
 * 根据参数名获取地址栏参数值
 * @param {String} name 参数名
 * @param {String} s 指定的查询字符串
 * @return {String} 返回参数值
 */
function _getQueryStringRegExp(name, s) {
  var reg = new RegExp('(^|\\?|&)' + name + '=([^&]*)(\\s|&|$)', 'i')
  var uri = ''
  if (s) {
    uri = s
  } else {
    uri = window.location.search
  }
  if (reg.test(uri)) {
    var result = decodeURIComponent(RegExp.$2.replace(/\+/g, ' '))
    return result === '' ? '' : result
  }
  return ''
}

/**
 * 获取参数数组
 * @param {Boolean} isDecode 是否对参数进行解码操作，默认true
 * @return {Array}
 */
function _getQueryStringArgs(isDecode) {
  // 取得查询字符串并去掉开头的问号
  var location = window.location
  var qs = location.search.length > 0 ? location.search.substring(1) : ''

  // 保存数据的对象
  var args = {}

  // 取得每一项
  var items = qs.split('&')
  var item = null
  var name = null
  var value = null
  var i

  // 逐个将每一项添加到args对象中
  for (i = 0; i < items.length; i++) {
    item = items[i].split('=')
    if (arguments.length === 1 && !isDecode) {
      name = item[0]
      value = item[1]
    } else {
      name = decodeURIComponent(item[0])
      value = decodeURIComponent(item[1])
    }
    args[name] = value
  }

  return args
}

/**
 * 千分位数字格式化
 * @param number 必需，要格式化的数字
 * @param decimals 可选，规定多少个小数位。
 * @param point 可选，规定用作小数点的字符串（默认为 . ）。
 * @param thousands 可选，规定用作千位分隔符的字符串（默认为 , ），如果设置了该参数，那么所有其他参数都是必需的。
 */
function _parseNumber(number, decimals, point, thousands) {
  number = (number + '').replace(/[^0-9+\-Ee.]/g, '')
  var n = !isFinite(+number) ? 0 : +number
  var prec = !isFinite(+decimals) ? 3 : Math.abs(decimals)
  var sep = thousands || ','
  var dec = point || '.'
  var s
  var toFixedFix = function(n, prec) {
    var k = Math.pow(10, prec)
    return '' + (Math.round(n * k) / k).toFixed(prec)
  }

  // Fix for IE parseFloat(0.55).toFixed(0) = 0;
  s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.')
  if (s[0].length > 3) {
    s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep)
  }
  if ((s[1] || '').length < prec) {
    s[1] = s[1] || ''
    s[1] += new Array(prec - s[1].length + 1).join('0')
  }
  return s.join(dec)
}

/**
 * @param {String} name cookie key
 */
function _getCookie(name) {
  let arr
  let reg = new RegExp('(^| )' + name + '=([^;]*)(;|$)')
  arr = document.cookie.match(reg)
  if (arr) {
    return unescape(arr[2])
  } else {
    return ''
  }
}

/**
 *
 * @param {String} name
 * @param {String} value
 * @param {Number} days
 */
function _setCookie(name, value, days) {
  let date = new Date()
  date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000)
  document.cookie = name + '=' + escape(value) + ';expires=' + date.toGMTString() + ';path=/'
}

/**
 * @param {Object} dictObj  service里面获取对应字典表字段
 * @param {Object} selList 页面的下拉对象
 * @param {String} val 匹配的字段
 * @param {Object} dataInfor  个人信息
 */
function _getDictInfor(dictObj, selList, val, dataInfor) {
  return axios.post(service.getDictionary, dictObj).then(res => {
    selList.list = res.data.data.dataGather
    let defaultIndex = ''
    if (!dataInfor[val]) {
      defaultIndex = selList.list.findIndex(element => element.dictDataCode === dataInfor[val])
    }
    // val = selList[defaultIndex].dictDataValue || ''
    return defaultIndex
  })
}

// 获取用户填写的信息
function _getUserInfo() {
  // service.getUserInfo
  return axios.post(service.getUserInfo).then(res => {
    return res.data
  })
}

/**
 * lang 资源包
 * local 语言
 */
function _i18n(lang, local) {
  window.$i18n = function(word) {
    return lang[local][word]
  }
  let i18ns = document.querySelectorAll('.i18n')
  // i18ns.forEach(item => {
  //   let word = item.getAttribute('i18n')
  //   item.textContent = lang[local][word]
  // })
  for (let index = 0; index < i18ns.length; index++) {
    const element = i18ns[index]
    let word = element.getAttribute('i18n')
    element.textContent = lang[local][word]
  }
}

export default {
  isIos: ISAPPLEDEVICE,
  isAndroid: ANDROIDDEVICE,
  getQueryStringRegExp: _getQueryStringRegExp,
  getQueryStringArgs: _getQueryStringArgs,
  getCookie: _getCookie,
  setCookie: _setCookie,
  getDictInfor: _getDictInfor,
  getUserInfo: _getUserInfo,
  parseNumber: _parseNumber,
  i18n: _i18n
}
