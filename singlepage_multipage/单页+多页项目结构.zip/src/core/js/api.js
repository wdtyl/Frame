// 发送请求示例
/*
// 在文件中引入 errorHandler ，这样可以使用通用处理函数
// import errorHandler from '@/core/js/errorHandler';
-----------post 请求------------
this.$http
  .post('/a', { a: 1, b: 2 })
  .then(response => {
      console.log(response.data);
  })
  .catch(errorHandler({}))
  .finally(() => {
      console.log('finally');
  });
-------------------------------------------
----------------get 请求------------------
this.$http
    .get('/b', { params: { a: 1, b: 2 } })
    .then(response => {
        console.log(response.data);
    })
    .catch(errorHandler({}))
    .finally(() => {
        console.log('finally');
    });
-----------------------------------------
------------自定义错误处理------------------
this.$http
    .get('/b', { params: { a: 1, b: 2 } })
    .then(response => {
        console.log(response.data);
    })
    .catch(errorHandler({other: (err)=>{
      console.log('自定义处理')
    }}))
    .finally(() => {
        console.log('finally');
    });
------------------------------------------------
------------- async/await 写法--------------
// 定义
async sendHttp () {
    let res = await this.$http.post('/a', { a: 1, b: 2 });
    console.log(res);
},
// 调用
this.sendHttp()
    .then(res => {
        console.log(res.data);
    })
    .catch(errorHandler())
    .finally(() => {
        console.log('finally');
    });
-------------------------
*/

import axios from 'axios'
// require('promise.prototype.finally').shim() // axios 可以使用 .finnaly 方法

axios.defaults.baseURL = process.env.VUE_APP_API
// axios.defaults.baseURL = 'http://vn.ngrok.xiayang.cc/api/'
axios.defaults.withCredentials = true
function formatParam(paramObj) {
  let paramArr = []
  let paramStr
  for (const key in paramObj) {
    if (paramObj.hasOwnProperty(key)) {
      const element = paramObj[key]
      if (element) {
        paramArr.push(`${key}=${element}`)
      } else {
        paramArr.push(`${key}=`)
      }
    }
  }
  paramStr = paramArr.join('&')
  return paramStr
}

// Add a request interceptor
axios.interceptors.request.use(
  function(config) {
    let method = config.method

    if (method === 'post' && !config.isFile) {
      config.headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'

      config.data = formatParam(config.data)
    } else {
      // 上传图片
      config.headers['Content-Type'] = 'multipart/form-data'
    }
    return config
  },
  function(error) {
    // Do something with request error
    return Promise.reject(error)
  }
)

// Add a response interceptor
axios.interceptors.response.use(
  response => {
    // return response
    let code = response.data.code
    try {
      // eslint-disable-next-line
      if (Vue && code === 500009) {
        // eslint-disable-next-line
        let vue = new Vue()
        vue.$toast({ message: 'Quá hạn phiên đăng nhập, xin mời đăng nhập lại', className: 'zindex' })
        setTimeout(() => {
          window.location = './index.html'
        }, 2000)
        return Promise.reject(response)
      }
    } catch (error) {}

    return response
    // 待确定
    // // Do something with response data
    // let code = response.data.stateCode;
    // // 业务成功
    // if (code === constants.ERROR.SUCCESS) {
    //     return response;
    // } else {
    //     let e;
    //     e = {
    //         config: response.config,
    //         name: 'Business Error',
    //         message: 'Business Error: stateCode is not 101',
    //         response: response
    //     };
    //     return Promise.reject(e);
    // }
  },
  error => {
    // Do something with response error
    return Promise.reject(error)
  }
)

export default axios
