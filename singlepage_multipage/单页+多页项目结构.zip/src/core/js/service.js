let resources = {
  // 个人信息
  perInforList: [
    {
      dictTypeCode: 'gender'
    },
    {
      dictTypeCode: 'live_time'
    },
    {
      dictTypeCode: 'industry'
    }
  ],
  // 联系信息
  conactInforList: [
    {
      dictTypeCode: 'r_relation'
    },
    {
      dictTypeCode: 'o_relation'
    }
  ],
  // 签约1
  signInforList: [
    {
      dictTypeCode: 'bank_code'
    }
  ],
  // 签约2
  signtInforList: [
    {
      dictTypeCode: 'bank_code'
    },
    {
      dictTypeCode: 'o_relation'
    }
  ],
  // 查询字典表
  getDictionary: '/query/dict_info',
  // 查询个人信息
  getUserInfo: '/user/info',
  // 获取贷款详情
  getLoanDetail: '/loan/detail',
  // 获取贷款列表
  getLoanList: '/loan/history',
  // 上传图片
  upload: '/file/upload_image',
  // 获取图片上传情况
  getUploadProgress: '/query/userDetailsinfo',
  // 提交工作信息
  submitWorkInfo: '/user/work_info',
  // 提交还款凭证
  submitRePayment: '/user/repayemnt_verify',
  // 获取还款va码
  getRepayment: 'loan/repayment',
  browserUpload: 'user/browser-upload'
}
export default resources
