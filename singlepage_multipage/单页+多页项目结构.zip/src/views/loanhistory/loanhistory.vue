<template>
  <div class="loanhistory">
    <loading v-if="isLoading"></loading>
    <comp-title :title="$t('message.loanHistory')" bg-color="rgb(26, 180, 53)" color="#fff" @clickLeft="clickLeft" :show-back="showBackBtn"></comp-title>
    <ul v-if="historyList.length > 0">
      <li v-for="(item, index) in historyList" :key="index" @click="goDetail(item.applyStatus,item.applyId)">
        <!-- 申请单号 -->
        <h4>{{$t('message.reqNumber')}}：{{item.applyNo}}</h4>
        <!-- 申请金额 -->
        <p class="amount">{{$t('message.applyAmount')}}：VND{{item.applyAmount | number(0,'.','.')}}</p>
        <!-- 申请日期 -->
        <p class="apply-data">{{$t('message.applyDate')}}：{{item.applyDate}}</p>
        <!-- 还款期限 -->
        <p class="repayment-term">{{$t('message.repayPeriod')}}：{{item.repayDay}}{{$t('message.daysNum')}}</p>
        <!-- 状态 -->
        <p class="contract-status">{{$t('message.hisStatus')}}：
          <span v-if="item.applyStatus == 1">{{$t('message.review')}}</span>
          <span v-if="item.applyStatus == 2">{{$t('message.applyFail')}}</span>
          <span v-if="item.applyStatus == 3">{{$t('message.pass')}}</span>
          <span v-if="item.applyStatus == 4">{{$t('message.loanFail')}}</span>
          <span v-if="item.applyStatus == 5">{{$t('message.pendRepayment')}}</span>
          <span v-if="item.applyStatus == 6">{{$t('message.overdue')}}</span>
          <!-- 已结清 -->
          <span v-if="item.applyStatus == 7">{{$t('message.payOff')}}</span>
        </p>
      </li>
    </ul>
    <div class="nolist" v-if="historyList.length < 1">
      <img src="./images/nomsg.png" alt="">
      <p>{{$t('message.noMsgList')}}</p>
    </div>
  </div>
</template>
<script>
  import CompTitle from '@/components/Title';
  import Loading from '@/components/loading'
  import service from '@/core/js/service'
  export default {
    name: 'loanhistory',
    components: {
      CompTitle,
      Loading
    },
    data() {
      return {
        historyList: [],
        showBackBtn: true,
        title: '贷款历史', // 页面title
        isLoading: false
      }
    },
    mounted() {
      this.isLoading = true
      this.findLoanHistory().then(res => {
        this.historyList = res.data
        this.isLoading = false
      })
    },
    methods: {
      clickLeft() {
        this.$router.go(-1)
      },
      findLoanHistory() {
        return this.$http.post(service.getLoanList).then(res => res.data)
      },
      goDetail(status, applyId) {
        if (status <= '4') {
          this.$router.push({ name: 'loanstatus', params: { applyId } })
        } else if (status > '4') {
          this.$router.push({ name: 'loandetails', params: { applyId } })
        }
      }
    },
  }

</script>
<style lang="scss" scoped>
  .loanhistory {
    height: 100%;
    padding-top: 86px;

    background: #f5f5f5;

    ul {
      overflow: hidden;

      li {
        position: relative;

        margin-top: 20px;
        padding: 25px 32px;

        background: #fff;

        h4 {
          font-size: 32px;
          line-height: 50px;

          height: 50px;
          margin-bottom: 20px;

          color: rgb(51, 51, 51);
          }

        p {
          font-size: 26px;
          line-height: 46px;

          height: 46px;

          color: rgb(153, 153, 153);
          }
        }

      li::before {
        position: absolute;
        top: 50%;
        right: 32px;

        display: block;

        width: 13px;
        height: 26px;
        margin-top: -10px;

        content: '';

        background: url('./images/historygo.png');
        background-size: 100%;
        }
      }

    .nolist {
      position: absolute;
      top: 400px;

      width: 100%;

      img {
        display: block;

        width: 216px;
        height: 195px;
        margin: 0 auto;
        }

      p {
        font-size: 30px;

        margin-top: 30px;

        text-align: center;

        color: rgb(153, 153, 153);
        }
      }
    }

</style>
