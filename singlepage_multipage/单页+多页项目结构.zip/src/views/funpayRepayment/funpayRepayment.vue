<template>
  <div class="repayguide">
    <loading v-if="isLoading"></loading>
    <!-- 收银台 -->
    <comp-title :title="$t('repayment.w1')" bg-color="rgb(26, 180, 53)" color="#fff" @clickLeft="clickLeft" :show-back="isShowBack"></comp-title>
    <div class="repayment-content">
      <!-- 请支付金额 -->
      <van-cell class="pay-amount" title-class="pay-amount-title" value-class="pay-amount-amount" :title="$t('repayment.w2')">
        <div slot="default">
          <span>{{result.payOrderBalance | number(0, '.', '.')}}</span>
          VND
        </div>
      </van-cell>
      <div class="pay-content">
        <!-- 选择支付方式 -->
        <div class="select-title">{{$t('repayment.w18')}}</div>
        <van-radio-group v-model="radio">
          <van-cell-group>
            <van-cell class="select-item" title="单选框 1" clickable @click="radio = 'atm'" title-class="select-item-title" label-class="select-item-label">
              <div slot="title" class="title-content">
                <div class="title-con">
                  <!-- 银行支付 -->
                  {{$t('repayment.w3')}}
                </div>
                <div class="img-con">
                  <img src="./images/atm1.png" alt="">
                </div>
              </div>
              <div slot="label">
                <div class="label-con">
                  <!-- 银行支付方式说明 -->
                  {{$t('repayment.w5')}}
                </div>
                <div class="tip" @click="showTip('atm', $event)"></div>
              </div>
              <van-radio slot="right-icon" name="atm" icon-size="22px" checked-color="#fda63c" />
            </van-cell>
            <van-cell class="select-item" title="单选框 2" clickable @click="radio = 'otc'" title-class="select-item-title" label-class="select-item-label">
              <div slot="title" class="title-content">
                <div class="title-con">
                  <!-- 便利店支付 -->
                  {{$t('repayment.w4')}}
                </div>
                <div class="img-con otc">
                  <img src="./images/otc.png" alt="">
                </div>
              </div>
              <div slot="label">
                <div class="label-con">
                  <!-- 便利店支付方式说明 -->
                  {{$t('repayment.w6')}}
                </div>
                <div class="tip" @click="showTip('otc', $event)"></div>
              </div>
              <van-radio slot="right-icon" name="otc" icon-size="22px" checked-color="#fda63c" />
            </van-cell>
          </van-cell-group>
        </van-radio-group>
        <!-- 查看支付码 -->
        <div class="show-vc-btn" @click="showVa">{{$t('repayment.w7')}}</div>
      </div>
      <div class="uploader-container">
        <van-uploader ref="uploader1" :after-read="onRead1"></van-uploader>
        <div class="placeholder">
          <div class="plho" @click="choose1">
            <!-- <img class="plh1" v-lazy="plh1" alt srcset> -->
            <!-- 已上传凭证，继续上传 -->
            <div class="tip" v-if="repaymentStatus">{{$t('repayment.w21')}}</div>
            <!-- 我已还款，上传凭证 -->
            <div class="tip" v-else>{{$t('repayment.w20')}}</div>
          </div>
        </div>
        <!-- 支付完成后预计30分钟到账，您可在个人中心-历史账单中查看还款状态。如还款状态未更新，请上传支付小票照片作为凭证。 -->
        <div class="upload-tip">{{$t('repayment.w9')}}</div>
      </div>
      <!-- server call -->
      <div class="server-call">
        <p>Liên Hệ CSKH:</p>
        <p><a href="tel:0938932313">0938932313 zalo</a></p>
        <p><a href="tel:0938738303">0938738303 zalo</a></p>
      </div>
    </div>
    <van-dialog v-model="isShowIns" :title="product.instructions" className="dialog-ins" :showConfirmButton="false">
      <div class="content" v-html="product.content"></div>
      <div class="ins-btn" @click="isShowIns = false">{{$t('repayment.w15')}}</div>
    </van-dialog>
    <van-dialog v-model="isShowPayNum" :title="product.vaTitle" className="dialog-vc" :showConfirmButton="false">
      <div class="content">
        <div class="va-content">
          <div class="va-header"><span class="left">{{$t('repayment.w11')}}：</span><span class="right">
              <span class="price">{{result.payOrderBalance || ''}} </span> VND
            </span></div>
          <div class="va-introduce" v-if="radio == 'atm'"><span class="left">{{$t('repayment.w14')}}: </span><span class="right">{{result.reciveName}}</span></div>
          <div class="va-introduce" v-if="radio == 'otc'">
            <img v-lazy="funpay" alt srcset>
          </div>
          <div class="va-code">{{result.vaCode || ''}}</div>
        </div>
      </div>
      <div class="close-btn" @click="isShowPayNum = false"></div>
    </van-dialog>
  </div>
</template>

<script>
  import Compressor from 'compressorjs';
  import Vue from 'vue'
  import { Button, Cell, RadioGroup, Radio, CellGroup, Uploader, Toast, Dialog } from 'vant'
  import CompTitle from '@/components/Title'
  import Loading from '@/components/loading'
  // import util from '@/core/js/util'
  import service from '@/core/js/service'

  Vue.use(Button).use(Cell).use(RadioGroup).use(Radio).use(CellGroup).use(Uploader).use(Toast).use(Dialog)
  // contract_id
  let applyId;
  export default {
    name: '',
    components: {
      CompTitle,
      Loading
    },
    data() {
      return {
        isShowBack: true,
        radio: 'atm',
        plh1: require('./images/plh1.png'),
        funpay: require('./images/funpay.png'),
        isShowIns: false,
        isShowPayNum: false,
        isLoading: false,
        result: {
          vaCode: '', // 还款码
          payType: '', // 还款方式  atm/otc
          payOrderBalance: '', // 还款金额
          expiredTime: '', // 过期时间
          reciveName: ''
        },
        procucts: {
          atm: {
            instructions: this.$t('repayment.w5'), // 银行支付方式说明
            content: this.$t('repayment.w17'),
            vaTitle: this.$t('repayment.w12') // 银行支付码
          },
          otc: {
            instructions: this.$t('repayment.w6'), // 便利店支付方式说明
            content: this.$t('repayment.w16'),
            vaTitle: this.$t('repayment.w10') // 便利店支付码
          },
        },
        product: {},
        atm: null,
        otc: null,
        repaymentStatus: false,
      }
    },
    mounted() {
      applyId = this.$route.query.contract_id || ''
      this.getRepayment()
    },
    methods: {
      showTip(item, event) {
        event.stopPropagation()
        event.preventDefault()
        this.product = this.procucts[item]
        this.isShowIns = true
      },
      showVa() {
        this.result = this[this.radio];
        this.product = this.procucts[this.radio]
        this.isShowPayNum = true;
      },
      clickLeft() {
        this.$router.go(-1)
      },
      choose1() {
        this.$refs.uploader1.$refs.input.click()
      },
      onRead1(file, detail) {
        let formData = new FormData()
        formData.append('type', 'repayment')
        formData.append('extra_param', 0)
        formData.append('apply_id', applyId)
        this.compress(file, formData, 1)
      },
      // 压缩图片
      compress(file, formData) {
        let _this = this
        let compress = new Compressor(file.file, { // eslint-disable-line
          quality: 0.4,
          success(result) {
            // alert(result.size / 1024 / 1024 + 'MB')
            // The third parameter is required for server
            formData.append('image', result);
            // Send the compressed image file to server with XMLHttpRequest.
            _this.upload(formData)
          },
          error(err) {
            // 压缩出错，直接上传
            formData.append('image', file.file);
            _this.upload(formData)
            console.log(err.message);
          },
        });
      },
      // 上传照片
      upload(formData) {
        this.isLoading = true

        this.$http
          .post(service.upload, formData, {
            isFile: true
          })
          .then(res => {
            if (Number(res.data.code) === 100000) {
              this.confirmPop()
            } else {
              this.isLoading = false
              this.$toast(this.$t('addition.word5'))
            }
          })
          .catch(() => {
            this.isLoading = false
            this.$toast(this.$t('addition.word4'))
          })
      },
      // 提交图片
      confirmPop() {
        this.$http
          .post(service.submitRePayment, { applyId: applyId })
          .then(res => {
            if (Number(res.data.code) === 100000) {
              this.isLoading = false
              this.repaymentStatus = true
              this.$toast(this.$t('repayment.w19'))
            } else {
              this.isLoading = false
              this.$toast(res.data.message)
            }
          })
          .catch(() => {
            this.isLoading = false
          })
      },
      // 获取va码
      getRepayment() {
        this.isLoading = true
        this.$http
          .post(service.getRepayment, { applyId }).then(res => {
            if (Number(res.data.code) === 100000) {
              let data = res.data.data.repaymentList;
              this.repaymentStatus = res.data.data.repaymentStatus;
              for (const key in data) {
                if (data.hasOwnProperty(key)) {
                  const element = data[key];
                  if (element.payType === 'atm') {
                    element.vaCode = element.vaCode
                      .replace(/\s/g, '')
                      .replace(/(.{4})/g, '$1 ');
                    this.atm = element;
                    this.result = this.atm;
                  } else if (element.payType === 'otc') {
                    this.otc = element;
                  }
                }
              }
            }
            this.isLoading = false
          }).catch(() => {
            this.isLoading = false
          })
      }
    }
  }

</script>

<style lang="scss" scoped>
  .repayguide {
    // height: 100%;
    background: #f5f5f5;
  }

  .van-cell:not(:last-child)::after {
    right: 0.21333rem;
  }

  .repayment-content {
    margin-top: 85px;
    // height: 100%;

    .pay-amount {
      line-height: 110px;
      background: #fff;
      padding: 0 30px;

      .pay-amount-title {
        font-size: 30px;
        color: #666;
      }

      .pay-amount-amount {
        color: #333333;
        font-size: 30px;

        span {
          font-size: 43px;
        }
      }
    }

    .pay-content {
      overflow: hidden;
      margin-top: 12px;
      background: #fff;

      .van-cell-group::after {
        border: none;
      }

      .select-title {
        line-height: 110px;
        font-size: 30px;
        color: #666;
        padding: 0 30px;
        position: relative;

        &::after {
          border-bottom: 1px solid #e6e6e6;
          transform: scaleY(.5);
          position: absolute;
          box-sizing: border-box;
          content: ' ';
          pointer-events: none;
          left: 0;
          right: 0;
          bottom: 0;
        }

      }

      .select-item {
        padding: 16px 30px 30px;
        line-height: 1;

        .select-item-title {
          line-height: 74px;
          font-size: 30px;

          color: #333333;

          .title-content {
            overflow: hidden;
            display: table;
          }

          .title-con {
            display: table-cell;

            padding-right: 12px;
          }

          .img-con {
            display: table-cell;
            vertical-align: middle;
            margin-left: 10px;
            width: 101px;
            height: 36px;

            &.otc {
              width: 145px;
              height: 36px;
            }

            img {
              display: block;
              width: 100%;
              height: 100%;
            }
          }
        }

        .select-item-label {
          margin: 0;
          font-size: 24px;
          line-height: 30px;
          color: #666666;

          .label-con {
            display: table-cell;
            padding-right: 12px;
          }

          .tip {
            display: table-cell;
            vertical-align: middle;
            width: 27px;
            height: 27px;
            position: relative;
            background: url('./images/tip.png') no-repeat;
            background-size: 100%;

            &::before {
              display: block;
              position: absolute;
              content: '';
              left: -10px;
              right: -10px;
              top: -10px;
              bottom: -10px;
            }
          }
        }
      }
    }

    .show-vc-btn {
      background-color: #ffa72b;
      border-radius: 10px;
      margin: 40px 40px 20px;
      font-size: 32px;
      color: #ffffff;
      line-height: 90px;
      text-align: center;
    }
  }

  .uploader-container {
    background-color: #fff;
    overflow: hidden;
  }

  .van-uploader {
    float: left;
    visibility: hidden;
  }

  .placeholder {
    width: 600px;
    margin: 0 auto;

    border-radius: 7px;
    // background-color: #f5f8ff;

    .plho {
      text-align: center;
    }

    .plh1 {
      display: block;
      width: 168px;
      height: 123px;
      margin: 0 auto;
    }

    .tip {
      font-size: 30px;

      // margin-top: 30px;
      padding: 0 10px;

      color: #0090ff;
    }
  }

  .upload-tip {
    margin-top: 25px;
    font-size: 24px;
    line-height: 40px;
    color: #666666;
    padding: 0 40px;

  }

  /deep/.dialog-ins {
    border-radius: 30px;

    .van-dialog__header {
      padding: 0;
      line-height: 92px;
      text-align: center;
      border-bottom: 1px solid #dedede;
      font-size: 26px;
      color: #000;

    }

    .content {
      padding: 30px 50px 50px;
      font-size: 20px;
      color: #000;
      line-height: 30px;
      text-align: justify;

      a {
        display: inline-block;
        color: #0090ff;
      }
    }

    .ins-btn {
      background: #ffa72b;
      line-height: 90px;
      color: #fff;
      font-size: 30px;
      text-align: center;
      margin: 0 50px 55px;
      border-radius: 10px;

    }
  }

  /deep/.dialog-vc {
    border-radius: 28px;
    overflow: visible;

    .van-dialog__header {
      padding: 0;
      line-height: 92px;
      text-align: center;
      font-size: 28px;
      color: #ffffff;
      background: #333333;
      // width: 100%;
      border-top-right-radius: 28px;
      border-top-left-radius: 28px;
    }

    .content {
      padding: 30px 50px 50px;
      font-size: 20px;
      color: #000;
      line-height: 30px;
    }

    .va-content {
      .left {
        font-size: 24px;
        color: #000;
      }

      .price {
        font-size: 40px;
        color: #333333;
      }

      .right {
        font-size: 24px;
        color: #666;

      }

      .va-introduce {
        line-height: 30px;
        margin-top: 20px;

        img {
          display: block;
          margin: 0 auto;
          width: 339px;
          height: 138px;
        }
      }

      .va-code {
        margin-top: 40px;
        background-color: #4c4c4c;
        border-radius: 10px;
        font-size: 40px;
        color: #fff;
        line-height: 94px;
        text-align: center;
      }
    }

    .close-btn {
      width: 50px;
      height: 50px;
      position: absolute;
      bottom: -80px;
      left: 50%;
      transform: translateX(-50%);
      background: url('./images/close.png') no-repeat;
      background-size: 100%;

      &::after {
        content: '';
        position: absolute;
        right: -10px;
        left: -10px;
        bottom: -10px;
        top: -10px;
      }
    }
  }

  .server-call {
    background: #fff;
    padding: 106px 0;
    text-align: center;

    p {
      font-size: 28px;
      color: #999999;
      line-height: 40px;

      a {
        color: #0090ff;
      }
    }
  }

</style>
