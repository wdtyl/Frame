<template>
  <div class="fillinfo signing">
    <loading v-if="isLoading"></loading>
    <comp-title :title="title" bg-color="rgb(26, 180, 53)" color="#fff" @clickLeft="clickLeft" :show-back="showBackBtn">
    </comp-title>
    <div class="center">
      <comp-signingTop></comp-signingTop>
      <div class="signingNav"></div>
      <div class="meg">
        <!-- 账户信息  -->
        <h4>{{$t('message.accountInfor')}}</h4>
        <ul class="personMeg">
          <li>
            <!-- 姓名 -->
            <span>{{$t('message.userName')}}</span>
            <input :value="baseInfo.name" readonly class="width7" />
          </li>
          <li>
            <!-- 银行名称 -->
            <div>{{$t('message.bankname')}}</div>
            <div class="work-info">
              <input :value="bankShowName" readonly :placeholder="$t('message.pleaseChoose')" />
              <i class="selectIcon" @click="showBankList"></i>
            </div>
          </li>
          <li>
            <!-- 银行账号 -->
            <div>{{$t('message.bankAccount')}}</div>
            <input v-model="signInfo.bankCard" :placeholder="$t('message.pleaseEnter')" />
          </li>
        </ul>
        <!-- 补充联系人 -->
        <h4>{{$t('message.supContact')}}</h4>
        <ul class="personMeg">
          <li class="inputbefore">
            <input :value="relation" readonly :placeholder="$t('message.relations')" />
            <i class="selectIcon" @click="showRelationList"></i>
          </li>
          <li>
            <!-- 联系人全名 -->
            <div>{{$t('message.otherName')}}</div>
            <input v-model="signInfo.bName" :placeholder="$t('message.pleaseEnter')" />
            <i class="clean" @click="clearInput"></i>
          </li>
          <li>
            <!-- 联系人电话 -->
            <div>{{$t('message.otherPhone')}}</div>
            <input v-model="signInfo.bPhone" :placeholder="$t('message.pleaseEnter')" />
          </li>
        </ul>
        <!-- 点击"完成"即表示同意签署《平台借款合同》 -->
        <p class="tips">{{$t('message.agreeToSign')}}<span @click="showContract">《{{$t('message.loanContract')}}》</span></p>
        <!-- 完成 -->
        <div class="completebtn" @click="confirmPop">{{$t('message.carryOut')}}</div>
        <!-- 返回 -->
        <div class="backbtn">{{$t('message.goBack')}}</div>
        <div class="bottom-tip">{{$t('message.bottomTip')}}</div>
      </div>
    </div>
    <!-- 确认签约 -->
    <sign-layer ref="showFlag" :sign="signInfo"></sign-layer>
    <!-- 合同模版 -->
    <contract ref="showContract" :asyncUserInfo="asyncUserInfo"></contract>
    <!-- 选择银行卡列表 -->
    <van-popup v-model="isShowBankList" position="bottom">
      <van-picker value-key="dictDataValue" :columns="bankList" @confirm="bankNameChange" @cancel="cancelPiker(1)" show-toolbar :default-index="bankIndex" />
    </van-popup>
    <!-- 选择联系人关系列表 -->
    <van-popup v-model="isShowRelationList" position="bottom">
      <van-picker value-key="dictDataValue" :columns="relationList" @confirm="relationChange" show-toolbar @cancel="cancelPiker(2)" />
    </van-popup>
  </div>
</template>
<script>
  import Vue from 'vue'
  import CompTitle from '@/components/Title';
  import util from '@/core/js/util'
  import service from '@/core/js/service'
  import CompSigningTop from '@/components/SigningTop';
  import Loading from '@/components/loading'
  import { Popup, Picker, Toast } from 'vant';
  import '../css/signing.scss'
  import SignLayer from '../components/signlayer.vue'
  import Contract from '../components/contract.vue'
  import constant from '@/core/js/constant';

  function getLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        function(position) {
          var latitude = position.coords.latitude // 纬度
          var longitude = position.coords.longitude // 经度
          localStorage.setItem('positionInfo', JSON.stringify({ latitude, longitude }))
        },
        function(error) {
          console.log(error)
        }
      )
    }
  }

  Vue.use(Popup).use(Picker).use(Toast);
  export default {
    components: {
      CompTitle,
      CompSigningTop,
      SignLayer,
      Loading,
      Contract
    },
    data() {
      return {
        isLoading: true,
        title: '签约',
        showBackBtn: true,
        loanInfo: {}, // 贷款信息
        // bankName: '', // 银行卡
        relation: '', // 关系
        bankList: [], // 银行卡列表
        relationList: [], // 关系列表
        isShowBankList: false, // 是否显示银行卡
        isShowRelationList: false, // 是否显示联系人列表
        signInfo: {
          bankCode: '', // 银行卡所属银行
          bankCard: '', // 卡号
          bRelation: '', // 补充联系人关系，码表
          bName: '', // 补充联系人姓名
          bPhone: '', // 补充联系人手机号
          loanAmount: '', // 借款金额
          loanDay: '', // 借款期限
          latitude: '', // 纬度
          longitude: '' // 经度
        },
        baseInfo: {},
        asyncUserInfo: {},
      }
    },
    created() {
      let loanInfo = JSON.parse(localStorage.getItem('loanInfo')) || {}
      if (!loanInfo.loanAmount && !loanInfo.loanDay) {
        window.location = './index.html'
        return
      }
      this.loanInfo = loanInfo
      getLocation()
      util.getUserInfo().then(res => {
        let data = res.data
        // this.signInfo = data.signInfo
        this.baseInfo = data.baseInfo
        this.signInfo = Object.assign({}, this.signInfo, data.signInfo)
        let userInfo = Object.assign({}, data.baseInfo, loanInfo, { registerMobile: data.registerMobile })
        this.asyncUserInfo = userInfo
        // 取消loaidng
        this.isLoading = false;
      }) // 获取码表数据
      this.findBankList().then(res => {
        let result = res.data
        this.bankList = result.dataGather
      })
      this.findRelationList().then(res => {
        let result = res.data
        this.relationList = result.dataGather
      })
    },
    computed: {
      bankIndex() {
        return this.bankList.findIndex(e => e.dictDataCode === this.signInfo.bankCode)
      },
      bankShowName() {
        let name = this.bankList.find(e => e.dictDataCode === this.signInfo.bankCode)
        if (name) {
          return name.dictDataValue
        } else {
          return ''
        }
      }
    },
    methods: {
      clickLeft() {
        this.$router.go(-1)
      },
      confirmPop() {
        if (!this.signInfo.bankCode) {
          this.$toast(this.$t('message.pcBankName')) // 请选择银行卡所属银行
          return false
        } else if (!this.signInfo.bankCard) {
          this.$toast(this.$t('message.peBankNum')) // 请输入银行卡号
          return false
        } else if (this.signInfo.bankCard.length < 4 || this.signInfo.bankCard.length > 16) {
          this.$toast(this.$t('message.piCorrectlyBankId'))
          return false
        } else if (!this.signInfo.bRelation) {
          this.$toast(this.$t('message.psShip')) // 请选择联系人关系
          return false
        } else if (!this.signInfo.bName) {
          this.$toast(this.$t('message.psName')) // 请输入联系人姓名
          return false
        } else if (this.signInfo.bName.length > 50) {
          this.$toast(this.$t('message.piCorrectlyThName'))
          return false
        } else if (/^(\d)\1+$/.test(this.signInfo.bPhone) || !constant.MOBILE_REG.test(this.signInfo.bPhone)) {
          this.$toast(this.$t('message.piCorrectlyOTel')) // 请输入联系人手机号
          return false
        }
        let position = JSON.parse(localStorage.getItem('positionInfo')) || {}
        this.signInfo = Object.assign({}, this.signInfo, position, this.loanInfo)
        this.$refs.showFlag.show = true;
      },

      // 选择银行卡名称
      bankNameChange(value) {
        this.signInfo.bankCode = value.dictDataCode
        this.isShowBankList = false
      },
      // 显示银行卡名称列表
      showBankList() {
        this.isShowBankList = true
      },
      // 选择关系
      relationChange(value) {
        this.relation = value.dictDataValue
        this.signInfo.bRelation = value.dictDataCode
        this.isShowRelationList = false
      },
      // 显示关系列表
      showRelationList() {
        this.isShowRelationList = true
      },
      cancelPiker(type) {
        if (type === 1) {
          this.isShowBankList = false
        } else {
          this.isShowRelationList = false
        }
      },
      // 获取银行卡码表
      findBankList() {
        return this.$http
          .post(service.getDictionary, { dictTypeCode: 'bank_code' })
          .then(res => res.data)
      },
      // 获取关系码表
      findRelationList() {
        return this.$http
          .post(service.getDictionary, { dictTypeCode: 'o_relation' })
          .then(res => res.data)
      },
      // 显示合同模版
      showContract() {
        this.$refs.showContract.show = true
      },
      clearInput() {
        this.signInfo.bName = ''
      }
    },
    beforeRouteLeave(to, from, next) {
      if (this.$refs.showContract.show) {
        this.$refs.showContract.show = false
        next(false)
      } else {
        next()
      }
    }
  }

</script>
<style lang="scss" scoped>
  .signing {
    background: #fff;

    .center {
      overflow: hidden;

      padding-top: 85px;


      .signingNav {
        background: url('../images/navicon3.png') 0 0 no-repeat;
        background-size: 100% 100%;
        }

      .tips {
        text-align: center;
        font-size: 28px;

        color: rgb(51, 51, 51);

        span {
          color: rgb(0, 27, 255);
          }
        }

      .completebtn {
        font-size: 34px;
        line-height: 84px;

        width: 600px;
        height: 84px;
        margin: 20px auto;

        text-align: center;

        color: #fff;
        border-radius: 10px;
        background: $themeBgColor;
        box-shadow: 0 6px 10px rgba(39, 177, 60, .42);
        }

      .backbtn {
        font-size: 34px;
        line-height: 84px;

        width: 600px;
        height: 84px;
        margin: 40px auto;

        text-align: center;

        color: rgb(153, 153, 153);
        border: 1px solid rgb(79, 79, 79);
        border-radius: 10px;
        }
      }
    }

</style>
