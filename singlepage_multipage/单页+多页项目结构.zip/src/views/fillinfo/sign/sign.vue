<template>
  <div class="fillinfo signing">
    <loading v-if="isLoading"></loading>
    <comp-title :title="$t('message.signing')" bg-color="rgb(26, 180, 53)" color="#fff" @clickLeft="clickLeft" :show-back="showBackBtn"></comp-title>
    <div class="center">
      <comp-signingTop></comp-signingTop>
      <div class="signingNav"></div>
      <div class="meg">
        <!-- 账户信息  -->
        <h4>{{$t('message.accountInfor')}}</h4>
        <ul class="personMeg">
          <li>
            <!-- 姓名 -->
            <span>{{$t('message.userName')}}</span>
            <input :placeholder="$t('message.pleaseEnter')" readonly class="width7" :value="baseInfo.name">
          </li>
          <li>
            <!-- 银行名称 -->
            <div>{{$t('message.bankname')}}</div>
            <div class="work-info">
              <input :value="bankName" readonly :placeholder="$t('message.pleaseEnter')">
              <i class="selectIcon" @click="showBankList"></i>
            </div>
          </li>
          <li>
            <!-- 银行卡号 -->
            <div>{{$t('message.bankAccount')}}</div>
            <input v-model="signInfo.bankCard" :placeholder="$t('message.pleaseEnter')">
          </li>
        </ul>
        <!-- 点击"完成"即表示同意签署《平台借款合同》 -->
        <p class="tips">
          {{$t('message.agreeToSign')}}
          <span @click="showContract">《{{$t('message.loanContract')}}》</span>
        </p>
        <!-- 完成 -->
        <van-button class="completebtn" round type="default" @click="confirmPop">{{$t('message.carryOut')}}</van-button>
        <!-- <div class="completebtn" @click="confirmPop">{{$t('message.carryOut')}}</div> -->
        <!-- 返回 -->
        <div class="backbtn" @click="clickLeft">{{$t('message.goBack')}}</div>
        <div class="bottom-tip">{{$t('message.bottomTip')}}</div>
      </div>
    </div>
    <!-- 确认签约 -->
    <sign-layer ref="showFlag" :sign="signInfo"></sign-layer>
    <!-- 合同模版 -->
    <contract ref="showContract" :asyncUserInfo="asyncUserInfo"></contract>
    <!-- 选择银行卡列表 -->
    <van-popup v-model="isShowBankList" position="bottom">
      <van-picker :columns="bankList" @confirm="bankNameChange" @cancel="bankNameCancel" value-key="dictDataValue" show-toolbar />
    </van-popup>
  </div>
</template>
<script>
  import Vue from 'vue'
  import CompTitle from '@/components/Title'
  import CompSigningTop from '@/components/SigningTop'
  import Loading from '@/components/loading'
  import util from '@/core/js/util'
  import service from '@/core/js/service'
  import { Popup, Picker, Toast, Button } from 'vant'
  import '../css/signing.scss'
  import SignLayer from '../components/signlayer.vue'
  import Contract from '../components/contract.vue'

  function getLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        function(position) {
          var latitude = position.coords.latitude // 纬度
          var longitude = position.coords.longitude // 经度
          localStorage.setItem('positionInfo', JSON.stringify({ latitude, longitude }))
        },
        function(error) {
          console.log(error)
        }
      )
    }
  }
  Vue.use(Popup).use(Picker).use(Toast).use(Button)
  export default {
    components: {
      CompTitle,
      CompSigningTop,
      SignLayer,
      Loading,
      Contract
    },
    data() {
      return {
        isLoading: false,
        showBackBtn: true,
        signInfo: {
          bankCode: '', // 银行卡所属银行
          bankCard: '', // 银行卡号
          latitude: '', // 维度
          longitude: '', // 经度
          loanAmount: '', // 借款金额
          loanDay: '', // 借款期限
        },
        bankName: '', // 银行卡所属银行名称
        baseInfo: {},
        bankList: [], // 银行卡列表
        isShowBankList: false, // 是否显示银行卡
        loanInfo: {}, // 贷款信息
        btnLoading: false,
        asyncUserInfo: {},
      }
    },
    created() {
      let loanInfo = JSON.parse(localStorage.getItem('loanInfo')) || {}
      this.loanInfo = loanInfo
      this.isLoading = true
      getLocation()
      // 获取码表数据
      this.findBankList().then(res => {
        let result = res.data
        this.bankList = result.dataGather
      })
      // 占位 信息返显
      util.getUserInfo().then(res => {
        let data = res.data
        this.baseInfo = data.baseInfo
        this.isLoading = false
        let userInfo = Object.assign({}, data.baseInfo, loanInfo, { registerMobile: data.registerMobile })
        this.asyncUserInfo = userInfo
      })
    },
    methods: {
      clickLeft() {
        this.$router.go(-1)
      },
      confirmPop() {
        if (this.btnLoading) return
        // 取localstorage中的地理位置
        if (!this.signInfo.bankCode) {
          this.$toast(this.$t('message.pcBankName')) // 请选择银行卡所属银行
          return false
        } else if (!this.signInfo.bankCard) {
          this.$toast(this.$t('message.peBankNum')) // 请输入银行账号
          return false
        } else if (this.signInfo.bankCard.length < 4 || this.signInfo.bankCard.length > 16) {
          this.$toast(this.$t('message.piCorrectlyBankId'))
          return false
        } else {
          let position = JSON.parse(localStorage.getItem('positionInfo')) || {}
          this.signInfo = Object.assign({}, this.signInfo, position, this.loanInfo)
          this.$refs.showFlag.show = true
        }
      },
      bankNameChange(value) {
        this.bankName = value.dictDataValue
        this.signInfo.bankCode = value.dictDataCode
        this.bankNameCancel()
      },
      bankNameCancel() {
        this.isShowBankList = false
      },
      showBankList() {
        this.isShowBankList = true
      },
      // 获取银行卡码表
      findBankList() {
        return this.$http
          .post(service.getDictionary, { dictTypeCode: 'bank_code' })
          .then(res => res.data)
      },
      // 显示合同模版
      showContract() {
        this.$refs.showContract.show = true
      }
    },
    beforeRouteLeave(to, from, next) {
      if (this.$refs.showContract.show) {
        this.$refs.showContract.show = false
        next(false)
      } else {
        next()
      }
    }
  }

</script>
<style lang="scss" scoped>
  .signing {
    background: #fff;

    .center {
      overflow: hidden;

      padding-top: 85px;

      .signingNav {
        background: url('../images/navicon3.png') 0 0 no-repeat;
        background-size: 100% 100%;
      }

      .tips {
        text-align: center;
        font-size: 28px;

        color: rgb(51, 51, 51);

        span {
          color: rgb(0, 27, 255);
        }
      }

      .completebtn {
        font-size: 34px;
        line-height: 84px;
        display: block;

        width: 600px;
        height: 84px;
        margin: 20px auto 0;

        text-align: center;

        color: #fff;
        border-radius: 10px;
        background: $themeBgColor;
      }

      .backbtn {
        font-size: 34px;
        line-height: 84px;

        width: 600px;
        height: 84px;
        margin: 40px auto;

        text-align: center;

        color: rgb(79, 79, 79);
        border: 1px solid rgb(79, 79, 79);
        border-radius: 10px;
      }
    }
  }

</style>
