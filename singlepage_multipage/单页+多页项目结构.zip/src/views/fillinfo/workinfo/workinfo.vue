<template>
  <div class="fillinfo work-info">
    <loading v-if="isLoading"></loading>
    <comp-title :title="$t('message.workInfo')" bg-color="rgb(26, 180, 53)" color="#fff" @clickLeft="clickLeft" :show-back="showBackBtn"></comp-title>
    <div class="center">
      <comp-signingTop></comp-signingTop>
      <div class="signingNav"></div>
      <div class="meg">
        <ul class="personMeg">
          <!-- 从事行业 -->
          <li class="liflex">
            <div class="fl">{{$t('message.career')}}</div>
            <input :value="causeShowName" readonly class="frinput" :placeholder="$t('message.pleaseChoose')">
            <i class="selectIcon selectIcon1" @click="pickerShow(1)"></i>
          </li>
          <div v-if="isShowMore">
            <!-- 工作地址 -->
            <!-- <li class="address">
              <div class="pdbtm tstyle">{{$t('message.resAddress')}}</div>
              <dl>
                <dt>{{$t('message.province')}}</dt>
                <dd>
                  <input
                    :value="workInfo.companyProvince"
                    readonly
                    class="frinput"
                    :placeholder="$t('message.pleaseChoose')"
                  >
                  <i class="selectIcon" @click="pickerShow(2)"></i>
                </dd>
              </dl>
              <dl>
                <dt>{{$t('message.area')}}</dt>
                <dd>
                  <input
                    :value="workInfo.companyCity"
                    readonly
                    class="frinput"
                    :placeholder="$t('message.pleaseChoose')"
                  >
                  <i class="selectIcon" @click="pickerShow(3)"></i>
                </dd>
              </dl>
              <dl>
                <dt>{{$t('message.commune')}}</dt>
                <dd>
                  <input
                    :value="workInfo.companyCounty"
                    readonly
                    class="frinput"
                    :placeholder="$t('message.pleaseChoose')"
                  >
                  <i class="selectIcon" @click="pickerShow(4)"></i>
                </dd>
              </dl>
            </li>-->
            <!-- 单位名称 -->
            <li>
              <div class="pdbtm tstyle">{{$t('message.workName')}}</div>
              <input :placeholder="$t('message.inpCompanyName')" v-model="workInfo.companyName" maxlength="50">
            </li>
            <!-- 工作地点 -->
            <li>
              <div class="pdbtm tstyle">{{$t('message.workAddress')}}</div>
              <input :placeholder="$t('message.inpWorkAddress')" v-model="workInfo.companyAddress" maxlength="80">
            </li>
            <!-- 职位 -->
            <li>
              <div class="pdbtm tstyle">{{$t('message.title')}}</div>
              <input :placeholder="$t('message.inpTitle')" v-model="workInfo.employeePosition" maxlength="50">
            </li>
            <!-- 公司的电话号码 -->
            <!-- <li>
              <div class="pdbtm tstyle">{{$t('message.companyPhone')}}</div>
              <input type="tel" :placeholder="$t('message.inpCompanyPhone')" v-model="workInfo.companyPhone" maxlength="10">
            </li> -->
            <!-- 同事的电话号码 -->
            <li :style="{height: 'auto'}">
              <div class="pdbtm" v-if="!local || local === 'vn'">
                {{$t('message.collPhone')}}
                <span>{{$t('message.coll')}}</span>
              </div>
              <div class="pdbtm" v-else>
                <span>{{$t('message.coll')}}</span>{{$t('message.collPhone')}}
              </div>
              <input type="tel" :placeholder="$t('message.inpCollPhone')" v-model="workInfo.coWorkerMobile" maxlength="10">
            </li>
            <!-- 每月总收入 -->
            <li>
              <div class="pdbtm">{{$t('message.income')}}</div>
              <input type="tel" class="has-unit" :placeholder="$t('message.inpIncome')" v-model="workInfo.wages" maxlength="9">
              <div class="unit">VND</div>
            </li>
            <!-- 发薪日 -->
            <li class="liflex">
              <div class="fl tstyle">{{$t('message.payday')}}</div>
              <input :value="workInfo.payDay" readonly class="frinput" :placeholder="$t('message.pleaseChoose')">
              <i class="selectIcon selectIcon1" @click="pickerShow(6)"></i>
            </li>
            <!-- 工作年限 -->
            <!-- <li class="liflex">
              <div class="fl tstyle">{{$t('message.workTime')}}</div>
              <input :value="timeShowName" readonly class="frinput" :placeholder="$t('message.pleaseChoose')">
              <i class="selectIcon selectIcon1" @click="pickerShow(5)"></i>
            </li> -->
          </div>
          <!-- 另外一个手机号 -->
          <li v-else>
            <div class="pdbtm tstyle">{{$t('message.otherMobile')}}</div>
            <input type="tel" :placeholder="$t('message.pleaseEnter')" v-model="workInfo.otherMobile" maxlength="10">
          </li>
        </ul>
        <!-- 下一步 -->
        <div class="completebtn" @click="confirmWorkInfo">{{$t('message.nextStep')}}</div>
        <!-- 返回 -->
        <div class="backbtn" @click="clickLeft">{{$t('message.goBack')}}</div>
      </div>
    </div>
    <!-- 事业 -->
    <van-popup v-model="causeObj.showPicker" position="bottom">
      <van-picker :default-index="causeIndex" show-toolbar :columns="causeObj.list" @confirm="pickerConfirm($event,1)" @cancel="pickerCancel(1)" value-key="dictDataValue" />
    </van-popup>
    <!-- 省选择 -->
    <!-- <van-popup v-model="provinceObj.showPicker" position="bottom">
      <van-picker
        :default-index="provinceIndex"
        show-toolbar
        :columns="provinceObj.list"
        @confirm="pickerConfirm($event,2)"
        @cancel="pickerCancel(2)"
      />
    </van-popup>-->
    <!-- 市选择 -->
    <!-- <van-popup v-model="cityObj.showPicker" position="bottom">
      <van-picker
        :default-index="cityIndex"
        show-toolbar
        :columns="cityObj.list"
        @confirm="pickerConfirm($event,3)"
        @cancel="pickerCancel(3)"
      />
    </van-popup>-->
    <!-- 社区选择 -->
    <!-- <van-popup v-model="countyObj.showPicker" position="bottom">
      <van-picker
        :default-index="countyIndex"
        show-toolbar
        :columns="countyObj.list"
        @confirm="pickerConfirm($event,4)"
        @cancel="pickerCancel(4)"
      />
    </van-popup>-->
    <!-- 发薪日 -->
    <van-popup v-model="payDayObj.showPicker" position="bottom">
      <van-picker :default-index="payDayIndex" show-toolbar :columns="payDayObj.list" @confirm="pickerConfirm($event,6)" @cancel="pickerCancel(6)" />
    </van-popup>
    <!-- 工作时长 -->
    <!-- <van-popup v-model="liveTimeObj.showPicker" position="bottom">
      <van-picker :default-index="timeIndex" show-toolbar :columns="liveTimeObj.list" @confirm="pickerConfirm($event,5)" @cancel="pickerCancel(5)" value-key="dictDataValue" />
    </van-popup> -->
  </div>
</template>

<script>
  import Vue from 'vue'
  import CompTitle from '@/components/Title'
  import util from '@/core/js/util'
  import service from '@/core/js/service'
  import CompSigningTop from '@/components/SigningTop'
  import Loading from '@/components/loading'
  import { Popup, Picker, Toast } from 'vant'
  import '../css/signing.scss'
  import constant from '@/core/js/constant'

  Vue.use(Popup)
    .use(Picker)
    .use(Toast)
  // let cityList = {}
  // let countyList = {}

  export default {
    name: 'workinfo',
    components: {
      CompTitle,
      CompSigningTop,
      Loading
    },
    data() {
      return {
        isLoading: true,
        title: '',
        showBackBtn: true,
        isShowMore: true,
        causeShowName: '', // 事业展示值
        workInfo: {
          industry: '', // 从事行业码表
          // companyProvince: '', // 公司所在省
          // companyCity: '', // 公司所在市区
          // companyCounty: '', // 公司所在社区
          companyAddress: '', // 工作地点
          companyName: '', // 公司名称
          // companyPhone: null, // 公司联系电话
          coWorkerMobile: '', // 同事电话
          // workLives: '', // 工作年限
          payDay: '', // 发薪日
          employeePosition: '', // 职务
          otherMobile: '', // 本人另一个手机号
          wages: '' // 总收入
        },
        // 事业
        causeObj: {
          showPicker: false, //  事业picker
          list: [] //  事业数组
        },
        // 发薪日
        payDayObj: {
          showPicker: false,
          list: [...Array(30).keys()].map(e => ++e)
        },
        // // 省份
        // provinceObj: {
        //   showPicker: false,
        //   list: []
        // },
        // // 城市
        // cityObj: {
        //   showPicker: false,
        //   list: []
        // },
        // // 社区
        // countyObj: {
        //   showPicker: false,
        //   list: []
        // },
        liveTimeObj: {
          showPicker: false,
          list: []
        },
        local: '', // 本地环境
      }
    },
    created() {
      // this.handleGetCityInfoSucc()
      this.findWork()
      this.findTime()
      this.findUser().then(res => {
        let workInfo = res.data.workInfo
        this.workInfo = Object.assign({}, this.workInfo, workInfo)
        this.isLoading = false
      })
      let local = localStorage.getItem('local') || ''
      this.local = local
    },
    computed: {
      causeIndex() {
        return this.causeObj.list.findIndex(e => e.dictDataCode === this.workInfo.industry) || 0
      },
      causeName() {
        return this.workInfo.industry
      },
      // timeIndex() {
      //   return this.liveTimeObj.list.findIndex(e => e.dictDataCode === this.workInfo.workLives) || 0
      // },
      // timeShowName() {
      //   let name = this.liveTimeObj.list.find(e => e.dictDataCode === this.workInfo.workLives)
      //   if (name) {
      //     return name.dictDataValue
      //   } else {
      //     return ''
      //   }
      // },
      payDayIndex() {
        return this.payDayObj.list.findIndex(e => e === this.workInfo.payDay) || 0
      }
      // provinceIndex() {
      //   return this.provinceObj.list.findIndex(e => e === this.workInfo.companyProvince) || 0
      // },
      // provinceShowName() {
      //   return this.workInfo.companyProvince
      // },
      // cityIndex() {
      //   return this.cityObj.list.findIndex(e => e === this.workInfo.companyCity) || 0
      // },
      // cityShowName() {
      //   return this.workInfo.companyCity
      // },
      // countyIndex() {
      //   return this.countyObj.list.findIndex(e => e === this.workInfo.companyCounty) || 0
      // },
      // countyShowName() {
      //   return this.workInfo.companyCounty
      // }
    },
    watch: {
      causeName(val, old) {
        let name = this.causeObj.list.find(e => e.dictDataCode === val)
        if (name) {
          if (
            name.dictDataCode === 'E0001' ||
            name.dictDataCode === 'E0003' ||
            name.dictDataCode === 'E0005' ||
            name.dictDataCode === 'E0006'
          ) {
            this.isShowMore = false
          } else {
            this.isShowMore = true
          }
          this.causeShowName = name.dictDataValue
        } else {
          this.causeShowName = ''
        }
      }
      // provinceShowName(val, old) {
      //   this.cityObj.list = cityList[val] || []
      // },
      // cityShowName(val, old) {
      //   this.countyObj.list = countyList[this.provinceShowName][val] || []
      // }
    },
    methods: {
      findWork() {
        this.$http.post(service.getDictionary, { dictTypeCode: 'industry' }).then(res => {
          let result = res.data.data
          this.causeObj.list = result.dataGather
        })
      },
      findTime() {
        this.$http.post(service.getDictionary, { dictTypeCode: 'work_year' }).then(res => {
          let result = res.data.data
          this.liveTimeObj.list = result.dataGather
        })
      },
      async findUser() {
        let res = await util.getUserInfo()
        return res
      },
      clickLeft() {
        this.$router.go(-1)
      },
      // 选择
      pickerConfirm(value, type) {
        switch (type) {
          case 1:
            this.causeObj.showPicker = false
            this.workInfo.industry = value.dictDataCode
            break
            // case 2:
            //   this.provinceObj.showPicker = false
            //   this.workInfo.companyProvince = value
            //   this.workInfo.companyCity = ''
            //   this.workInfo.companyCounty = ''
            //   break
            // case 3:
            //   this.cityObj.showPicker = false
            //   this.workInfo.companyCity = value
            //   this.workInfo.companyCounty = ''
            //   break
            // case 4:
            //   this.countyObj.showPicker = false
            //   this.workInfo.companyCounty = value
            //   break
            // case 5:
            //   this.liveTimeObj.showPicker = false
            //   this.workInfo.workLives = value.dictDataCode
            //   break
          case 6:
            this.payDayObj.showPicker = false
            this.workInfo.payDay = value
            break
          default:
            break
        }
      },
      pickerCancel(type) {
        switch (type) {
          case 1:
            this.causeObj.showPicker = false
            break
            // case 2:
            //   this.provinceObj.showPicker = false
            //   break
            // case 3:
            //   this.cityObj.showPicker = false
            //   break
            // case 4:
            //   this.countyObj.showPicker = false
            //   break
          case 5:
            this.liveTimeObj.showPicker = false
            break
          case 6:
            this.payDayObj.showPicker = false
            break
          default:
            break
        }
      },
      pickerShow(type) {
        switch (type) {
          case 1:
            this.causeObj.showPicker = true
            break
            // case 2:
            //   this.provinceObj.showPicker = true
            //   break
            // case 3:
            //   if (this.workInfo.companyProvince === '') {
            //     this.$toast(this.$t('message.pcpRovince'))
            //   } else {
            //     this.cityObj.showPicker = true
            //   }
            //   break
            // case 4:
            //   if (this.workInfo.companyProvince === '') {
            //     this.$toast(this.$t('message.pcpRovince'))
            //   } else if (this.workInfo.companyCity === '') {
            //     this.$toast(this.$t('message.pcDistrict'))
            //   } else {
            //     this.countyObj.showPicker = true
            //   }
            //   break
          case 5:
            this.liveTimeObj.showPicker = true
            break
          case 6:
            this.payDayObj.showPicker = true
            break
          default:
            break
        }
      },
      // handleGetCityInfoSucc() {
      //   let res
      //   require.ensure(
      //     [],
      //     require => {
      //       res = require('../personalinfo/vietnam-city-new.js')
      //       this.provinceObj.list = res.provinceList
      //       cityList = res.cityList
      //       countyList = res.countyList
      //     },
      //     'cityJson'
      //   )
      // },
      confirmWorkInfo() {
        // 预留判断
        if (!this.workInfo.industry) {
          this.$toast(this.$t('message.pcIndustry')) // 请选择从事行业
          return false
        }
        if (this.isShowMore) {
          this.workInfo.otherMobile = '' // 本人另一个手机号
          if (this.workInfo.companyAddress && this.workInfo.companyAddress.length < 5) {
            this.$toast(this.$t('message.checkAddress')) // 公司地址
            return false
          } else if (this.workInfo.employeePosition && this.workInfo.employeePosition.length < 2) {
            this.$toast(this.$t('message.checkTitle')) // 职位
            return false
          } else if (/^(\d)\1+$/.test(this.workInfo.coWorkerMobile) || !constant.MOBILE_REG.test(this.workInfo.coWorkerMobile)) {
            this.$toast(this.$t('message.checkCollPhone')) // 同事手机号
            return false
          } else if (!/^(0|[1-9][0-9]*)$/.test(this.workInfo.wages)) {
            this.$toast(this.$t('message.checkIncome')) // 收入
            return false
          }
        } else {
          this.workInfo.companyAddress = '' // 公司详细地址
          this.workInfo.companyName = '' // 公司名称
          // this.workInfo.companyPhone = '' // 公司联系电话
          // this.workInfo.workLives = '' // 工作年限
          this.workInfo.wages = '' // 总收入
          this.workInfo.coWorkerMobile = '' // 同事电话
          this.workInfo.payDay = '' // 发薪日
          this.workInfo.employeePosition = '' // 职务
          if (this.workInfo.otherMobile && (/^(\d)\1+$/.test(this.workInfo.otherMobile) || !constant.MOBILE_REG.test(this.workInfo.otherMobile))) {
            this.$toast(this.$t('message.pePhone')) // 手机号
            return false
          }
        }

        this.$http.post(service.submitWorkInfo, this.workInfo).then(res => {
          if (res.data.code === 100000) {
            this.$router.push('additional')
          } else {
            this.$toast(res.data.message)
          }
        })
      }
    }
  }

</script>

<style lang="scss" scoped>
  .work-info {
    background: #fff;

    .meg {
      padding-top: 0;
      }

    .center {
      overflow: hidden;

      padding-top: 85px;

      .signingNav {
        background: url('../images/navicon3.png') 0 0 no-repeat;
        background-size: 100% 100%;
        }

      .personMeg {
        li {
          height: 139px;
          padding: 30px 0;

          input {
            font-size: 28px;

            padding-left: 25px;
            }

          div.pdbtm {
            padding-bottom: 10px;

            span {
              color: red;
              float: inherit;
              width: auto;
              }
            }

          div {
            padding: 0;
            }

          div.fl {
            float: left;
            }

          div.tstyle::before {
            display: none;
            }

          .selectIcon {
            bottom: 17px;
            }

          .selectIcon1 {
            bottom: 50%;

            transform: translateY(50%);
            }

          .clean {
            bottom: 17px;
            }

          input.frinput {
            width: 50%;
            padding-right: 65px;

            text-align: right;
            }

          input.frinput1 {
            width: 50%;
            padding-right: 10px;

            text-align: right;
            }

          input.cityipt {
            overflow: hidden;

            width: 90%;

            white-space: nowrap;
            text-overflow: ellipsis;
            }
          }

        li.address {
          height: auto;

          border-bottom: none;

          dl {
            font-size: 30px;
            line-height: 60px;

            position: relative;

            overflow: hidden;

            height: 60px;
            margin-top: 40px;
            padding-left: 25px;

            border-bottom: 1px solid rgb(230, 230, 230);

            dt {
              float: left;

              width: 20%;
              }

            dd {
              float: left;

              width: 70%;

              input {
                width: 100%;
                padding-right: 60px;

                text-align: left;
                }

              .selectIcon {
                bottom: 8px;
                }
              }
            }

          dl:nth-of-type(1) {
            margin-top: 0;
            }
          }

        .pnum {
          input.frinput1 {
            width: 40%;
            }
          }

        .has-unit {
          width: 60%;
          }

        .unit {
          &::before {
            display: none;
            }
          }

        .liflex {
          display: flex;

          align-items: center;
          justify-content: space-between;

          p {
            text-align: right;

            label {
              position: relative;

              width: 80px;

              text-align: right;

              input {
                position: absolute;
                top: 10px;

                float: none;

                width: 14px;
                height: 14px;
                }

              input[type='radio'] {
                display: none;
                }

              span {
                position: relative;

                float: none;

                padding-left: 49px;

                color: rgb(39, 177, 60);
                }

              input[type='radio']+i {
                position: absolute;
                top: 0;
                left: 0;

                display: block;

                width: 40px;
                height: 40px;

                content: '';
                transform: scale(0.5);

                border: 1px solid #646464;
                border-radius: 100%;
                }

              input[type='radio']:checked+i::after {
                position: absolute;
                top: 3px;
                left: 3px;

                display: block;

                width: 28px;
                height: 28px;

                content: '';

                border-radius: 100%;
                background: #646464;
                }
              }

            label:nth-of-type(1) {
              padding-right: 54px;
              }
            }
          }
        }
      }

    .completebtn {
      font-size: 34px;
      line-height: 84px;

      width: 600px;
      height: 84px;
      margin: 20px auto;

      text-align: center;

      color: #fff;
      border-radius: 10px;
      background: $themeBgColor;
      box-shadow: 0 6px 10px rgba(39, 177, 60, 0.42);
      }

    .backbtn {
      font-size: 34px;
      line-height: 84px;

      width: 600px;
      height: 84px;
      margin: 40px auto;

      text-align: center;

      color: rgb(153, 153, 153);
      border: 1px solid rgb(79, 79, 79);
      border-radius: 10px;
      }
    }

</style>
