<template>
  <!-- 合同页面begin -->
  <van-popup class="contract" v-model="show" position="right" :overlay="false">
    <comp-title bg-color="rgb(26, 180, 53)" color="#fff" @clickLeft="close" :show-back="true"></comp-title>
    <div class="contract-content">
      <h2 class="title">HỢP ĐỒNG DỊCH VỤ</h2>
      <div class="cl1">Số:_____________</div>
      <p>- Căn cứ Bộ Luật Dân sự 2015 của Nước Công hòa Xã Hội Chủ nghĩa Việt Nam ban hành ngày 24 tháng 11 năm 2015 và các văn bản hướng dẫn thi hành;</p>
      <p>- Căn cứ sự thỏa thuận của các bên;</p>
      <p>Bên A: <span>lamboiboi</span></p>
      <p>Họ và tên:<span>lamboiboi</span></p>
      <p>Quốc tịch:<span>Việt Nam </span></p>
      <p>CMND Số:<span>025652556</span></p>
      <p>Bên B: BÊN VAY</p>
      <!-- 用户名称 -->
      <p>Họ và tên:<span>{{asyncUserInfo.name ?asyncUserInfo.name : '_____________'}}</span></p>
      <!-- 用户生日 -->
      <p>Ngày sinh:<span>{{asyncUserInfo.birthday ? asyncUserInfo.birthday: '_____________'}}</span></p>
      <!-- 用户身份证号 -->
      <p>CMND Số:<span>{{asyncUserInfo.idCard ? asyncUserInfo.idCard : '_____________'}}</span></p>
      <!-- 用户注册手机号 -->
      <p>Số Điện thoại:<span>{{asyncUserInfo.registerMobile ? asyncUserInfo.registerMobile : '_____________'}}</span></p>
      <p>Bên C: CÔNG TY TNHH SEVEN-UP TECHNOLOGY</p>
      <p>Địa chỉ trụ sở : 915/74/8 Lê Văn Lương,Xã Phước Kiền,Huyện Nhà Bè,Thành Phố Hồ Chí Minh,Việt Nam</p>
      <p>Mã số doanh nghiệp:0315517137</p>
      <p>Đại diện bởi ông: LÊ CẦN VŨ</p>
      <!-- 合同号 -->
      <p>Các Bên chúng tôi Thỏa thuận và thông nhất kí kết Hợp đồng dịch vụ Số:_____________(Sau đây gọi tắt là “Hợp đồng”) với các điều khoản sau đây:</p>
      <p>ĐIỀU 1. GIẢI THÍCH TỪ NGỮ</p>
      <p>Trong Hợp đồng này, các bên thống nhất hiểu các từ ngữ dưới đây như sau:</p>
      <p>“Giao dịch vay” là giao dịch vay tiền giữa Bên A và Bên B;</p>
      <p>“Điểm kết nối giao dịch điện tử ” là hệ thống điểm kết nối giao dịch được thực hiện bằng phương pháp điện tử, dữ liệu thông tin trên internet <span>www.easypay.vn</span></p>
      <p>“Thông tin Cá nhân ” là thông tin về một bên mang tính nhận dạng, bao gồm nhưng không giới hạn tên, số chứng minh thư nhân dân, số giấy khai sinh, số hộ chiếu, quốc tịch, địa chỉ, số điện thoại, số fax, thông tin ngân hàng, thông tin thẻ tín dụng, dân tộc, giới tính, ngày sinh, tình trạng hôn nhân, tình trạng cư trú, nền tảng giáo dục, tình trạng tài chính, sở thích cá nhân, địa chỉ thư điện tử (email) của một bên, nghề nghiệp, định danh của một bên, ngành làm việc của một bên, bất kỳ thông tin nào về một bên mà một bên đã cung cấp choXXXDongtrong các đơn đăng ký, đơn xin gia nhập hoặc bất kỳ đơn tương tự nào và/hoặc bất kỳ thông tin nào về một bên đã được hoặc sẽ đượcXXXDongthu thập, lưu trữ, sử dụng và xử lý theo thời gian và bao gồm các thông tin cá nhân nhạy cảm như các dữ liệu về sức khỏe, tôn giác hoặc tín ngưỡng tương tự khác.</p>
      <p>“Hợp đồng” có nghĩa là Hợp đồng hợp tác được ký kết giữa các bên trong Hợp đồng và, bao gồm cả các Phụ lục đính kèm, các thỏa thuận sửa đổi, bổ sung được ký kết giữa các Bên sau này (nếu có).</p>
      <p>“Ngày làm việc ” là ngày không phải Chủ nhật và các ngày nghỉ lễ theo quy định pháp luật nước Cộng hòa Xã hội Chủ nghĩa Việt Nam.</p>
      <p>“Tranh chấp” nghĩa là bất cứ vấn đề, tranh luận, tranh cãi, bất đồng hoặc yêu cầu xuất phát từ hoặc liên quan đến Hợp đồng này hoặc tới sự vi phạm, chấm dứt hoặc hiệu lực của Hợp đồng này;</p>
      <p>“Pháp luật” hoặc “Pháp Luật Việt Nam” nghĩa là luật, nghị định, quyết định, thông tư và các quy định khác có liên quan (bao gồm tất cả các sửa đổi tuỳ từng thời điểm) áp dụng đối với các giao dịch dân sự tại Việt Nam;</p>
      <p>“Cơ quan nhà nước” và “ Các cơ quan nhà nước” nghĩa là bất kỳ Cơ quan Chính phủ, Ủy ban nhân dân, Bộ, cơ quan công quyền, hoặc bất kỳ uỷ ban, hội đồng, đơn vị, hoặc cơ quan thuộc Chính phủ mà một Bên hoặc các Bên yêu cầu phải được sự cho phép, chấp thuận, cam kết, hoặc tham vấn ý kiến của những cơ quan này đối với bất kỳ việc gì hoặc vấn đề gì mà hoạt động kinh doanh theo Hợp đồng này liên quan tới hoặc nhắm tới;</p>
      <p>“Việt Nam” nghĩa là nước Cộng hoà Xã hội Chủ nghĩa Việt Nam;</p>
      <p>“Đồng” hoặc “VNĐ” nghĩa là đồng tiền lưu hành hợp pháp của Việt Nam</p>
      <p>ĐIỀU 2. NỘI DUNG HỢP TÁC VỀ CHO VAY</p>
      <!-- 合同金额 -->
      <p>2.1. Bên A đồng ý cho Bên B vay số tiền là:
        <span v-if="asyncUserInfo.contractAmount">{{asyncUserInfo.contractAmount | number(0,'.','.')}}</span>
        <span v-else>_____________</span>
        <!-- 借款起始日期 -->
        Kể từ ngày:
        <span>{{asyncUserInfo.a ? asyncUserInfo.a : '_____________'}}</span>
        <!-- 还款日期 -->
        đến ngày:
        <span>{{asyncUserInfo.a ? asyncUserInfo.a : '_____________'}}</span>
        <!-- 应还总金额 -->
        Số tiền phải thanh toán cuối kỳ:
        <span v-if="asyncUserInfo.alsoAmount">{{asyncUserInfo.alsoAmount | number(0,'.','.')}}</span>
        <span v-else>_____________</span>
      </p>
      <p>Trong đó :</p>
      <p>2.2. Lãi suất giao dịch vay là 15%/1 năm ( Bằng chữ: Mười năm phần trăm trên một năm) tương đương với lãi suất 1.25%/1 tháng ( Bằng chữ: Một phẩy hai năm phần trăm trên một tháng)</p>
      <p>2.3. Phí giới thiệu khoản vay: số tiền hợp đồng nhân 2.1% mỗi ngày.</p>
      <!-- 放款日期 -->
      <p>2.4. Ngày giải ngân là ngày<span>{{asyncUserInfo.a ? asyncUserInfo.a : '_____________'}}</span></p>
      <!-- 还款日期 -->
      <p>2.5. Ngày thanh toán của giao dịch vay là ngày<span>{{asyncUserInfo.a ? asyncUserInfo.a : '_____________'}}</span></p>
      <p>2.6. Nếu thanh toán quá hạn sẽ phải chịu mức phí quá hạn theo 3% số tiền hợp đồng mỗi ngày .</p>
      <p>2.7Ngày bắt đầu tính lãi xác định theo công thức: Tính từ thời điểm tiền được chuyển cho người vay (bên B) thành công</p>
      <p>2.8. Bên A và Bên B thực hiện các giao dịch chuyển tiền và nhận tiền. Toàn bộ chi phí phát sinh trên điểm kết nối giao dịch do bên A chịu.</p>
      <p>ĐIỀU 3. QUYỀN LỢI VÀ TRÁCH NHIỆM BÊN A</p>
      <p>3.1. Bên A có đầy đủ các quyền sau:</p>
      <p>a. Được quyền lựa chọn người vay, thời gian vay, số tiền vay phù hợp;</p>
      <p>b. Được hưởng lãi suất giao dịch vay theo quy định của hợp đồng</p>
      <p>c. Nhận lại gốc và lãi của khoản đầu tư đúng thời hạn trong hợp đồng;</p>
      <p>d. Được quyền ủy thác cho Bên thứ 3 để thu hồi món nợ để đảm bảo việc thanh toán đúng hạn;</p>
      <p>e. Được quyền gia hạn thời gian trả nợ cho Bên B trong trường hợp thấy cần thiết.</p>
      <p>3.2. Bên A có các trách nhiệm sau:</p>
      <p>a. Không được rút gốc, lãi trước thời gian quy định trong hợp đồng này;</p>
      <p>b. Bảo mật thông tin người vay và thông tin hợp đồng;</p>
      <p>c. Đọc và hiểu rõ các điều khoản, điều kiện sử dụng dịch vụ điểm kết nối giao dịch điện tử XXXDong(công ty seven-up) và dịch vụ được cung cấp qua điểm kết nối giao dịch điện tử XXXDong trước khi đăng ký tài khoản và sử dụng dịch vụ, và đọc và hiểu các điều khoản Hợp đồng, điều kiện sử dụng dịch vụ khi nhận được thông báo về thay đổi, điều chỉnh quy chế hoạt động, điều khoản, điều kiện sử dụng dịch vụ và tham gia giao kết theo Hợp đồng này. Việc một bên sử dụng dịch vụ hoặc tiếp tục sử dụng dịch vụ được coi là thành viên đã đọc, hiểu và đồng ý với điều khoản, điều kiện sử dụng dịch vụ và giao kết Hợp đồng tại điểm kết nối giao dịch điện tử XXXDong;</p>
      <p>d. Tự chịu trách nhiệm về bảo mật, lưu giữ và mọi hoạt động sử dụng dịch vụ dưới tên đăng ký, mật khẩu và hòm thư điện tử của mình;</p>
      <p>e. Thông báo kịp thời cho XXXDong về những hành vi sử dụng trái phép, lạm dụng, vi phạm bảo mật, lưu giữ tên đăng ký và mật khẩu của mình để hai bên cùng hợp tác xử lý;</p>
      <p>f. Cam kết những thông tin cung cấp cho XXXDong là chính xác và hoàn chỉnh và giữ cho thông tin của mình trên ứng dụng của XXXDong được cập nhật, chính xác và hoàn chỉnh;</p>
      <p>g. Tự chịu trách nhiệm về nội dung, hình ảnh và các thông tin khác, cũng như toàn bộ quá trình giao dịch với các đối tác qua điểm kết nối giao dịch XXXDong;</p>
      <p>h. Chủ động trong việc giải quyết tranh chấp với Bên Vay, và bồi thường thiệt hại cho Bên Vay nếu tranh chấp được chứng minh là do lỗi của Bên Cho Vay;</p>
      <p>i. Cung cấp thông tin về giao dịch của mình khi có yêu cầu của cơ quan nhà nước có thẩm quyền;</p>
      <p>j. Tuân thủ quy định pháp luật về thanh toán, quảng cáo, khuyến mại, bảo vệ quyền sở hữu trí tuệ, bảo vệ quyền lợi người tiêu dùng và các quy định pháp luật có liên quan khác khi tham gia giao dịch vay tại điểm kết nối giao dịch điện tử XXXDong;</p>
      <p>k. Cam kết, đồng ý không sử dụng dịch vụ tại điểm kết nối giao dịch điện tử XXXDong cho những mục đích bất hợp pháp, không hợp lý, lừa đảo, đe dọa, thăm dò thông tin bất hợp pháp, phá hoại, tạo ra và phát tán vi-rút gây hư hại tới hệ thống, cấu hình, truyền tải thông tin của điểm kết nối giao dịch điện tử XXXDong cho mục đích đầu cơ, tạo lệnh đặt dịch vụ giả, lũng đoạn thị trường, bao gồm phục vụ cho việc phán đoán nhu cầu thị trường. Trong trường hợp vi phạm thì Bên Cho Vay phải chịu trách nhiệm về các hành vi của mình trước pháp luật;</p>
      <p>l. Cam kết không thay đổi, chỉnh sửa, sao chép, truyền bá, phân phối, cung cấp và tạo những công cụ tương tự của dịch vụ doXXXDong cung cấp cho một bên thứ ba nếu không được sự đồng ý của XXXDong;</p>
      <p>m. Không được hành động gây mất uy tín của điểm kết nối giao dịch điện tử XXXDong dưới mọi hình thức, bao gồm nhưng không giới hạn, việc gây mất đoàn kết giữa các thành viên bằng cách sử dụng tên đăng ký thứ hai, thông qua một bên thứ ba, hoặc tuyên truyền, phổ biến những thông tin không có lợi cho uy tín của XXXDong.</p>
      <p>ĐIỀU 4. QUYỀN LỢI VÀ TRÁCH NHIỆM CỦA BÊN B</p>
      <p>4.1. Bên B có đầy đủ các quyền sau:</p>
      <p>- Gửi yêu cầu vay bất cứ lúc nào, không cần thiết phải gặp mặt Bên A và không cần đưa ra tài sản bảo đảm cho khoản vay với Bên A;</p>
      <p>- Được hưởng mức phí hợp lý;</p>
      <p>- Được tư vấn, hỗ trợ làm thủ tục đăng ký khoản vay phù hợp.</p>
      <p>- Khi chưa nhận tiền vay, bên B có quyền từ chối, hủy yêu cầu vay bất cứ khi nào.</p>
      <p>4.2. Bên B có các trách nhiệm sau:</p>
      <p>a. Khai báo thông tin cá nhân chính xác và chịu trách nhiệm về các thông tin khai báo;</p>
      <p>b. Chịu trách nhiệm thanh toán đúng hạn gốc, lãi của khoản vay trong Hợp đồng này;</p>
      <p>c. Trường hợp Bên B không trả nợ đúng hạn và trả đủ khoản vay, Bên A hoặc Bên C đều có quyền công khai thông tin cá nhân của Bên A cũng các thông tin khác liên quan để thu hồi khoản vay;</p>
      <p>d. Trong trường hợp Bên B cố tình không trả nợ đúng hạn, Bên B phải thực hiện các trách nhiệm liên quan bao gồm nhưng không giới hạn như triệu tập làm việc, nhắc nợ cá nhân và người thân, công khai thông tin trên các phương tiện thông tin đại chúng, mạng xã hội,áp dụng các biện pháp thu hồi nợ hợp pháp khác.</p>
      <p>e. Đọc và hiểu rõ các điều khoản, điều kiện sử dụng dịch vụ điểm kết nối giao dịch điện tử XXXDong và dịch vụ được cung cấp qua điểm kết nối giao dịch điện tử XXXDong trước khi đăng ký tài khoản và sử dụng dịch vụ, và đọc và hiểu các điều khoản Hợp đồng, điều kiện sử dụng dịch vụ khi nhận được thông báo về thay đổi, điều chỉnh quy chế hoạt động, điều khoản, điều kiện sử dụng dịch vụ và tham gia giao kết theo Hợp đồng này. Việc một bên sử dụng dịch vụ hoặc tiếp tục sử dụng dịch vụ được coi là thành viên đã đọc, hiểu và đồng ý với điều khoản, điều kiện sử dụng dịch vụ và giao kết Hợp đồng tại điểm kết nối giao dịch điện tử XXXDong;</p>
      <p>f. Tự chịu trách nhiệm về bảo mật, lưu giữ và mọi hoạt động sử dụng dịch vụ dưới tên đăng ký, mật khẩu và số điện thoại hoặc hòm thư điện tử của mình;</p>
      <p>g. Thông báo kịp thời cho XXXDong về những hành vi sử dụng trái phép, lạm dụng, vi phạm bảo mật, lưu giữ tên đăng ký và mật khẩu của mình để hai bên cùng hợp tác xử lý;</p>
      <p>h. Cam kết những thông tin cung cấp cho XXXDong là chính xác và hoàn chỉnh và giữ cho thông tin của mình trên ứng dụng của XXXDong được cập nhật, chính xác và hoàn chỉnh;</p>
      <p>i. Tự chịu trách nhiệm về nội dung, hình ảnh và các thông tin khác, cũng như toàn bộ quá trình giao dịch với các đối tác qua điểm kết nối giao dịch XXXDong;</p>
      <p>j. Chủ động trong việc giải quyết tranh chấp với Bên Cho Vay, và bồi thường thiệt hại cho Bên Cho Vay nếu tranh chấp được chứng minh là do lỗi của Bên Vay;</p>
      <p>k. Cung cấp thông tin về giao dịch của mình khi có yêu cầu của cơ quan nhà nước có thẩm quyền;</p>
      <p>l. Tuân thủ quy định pháp luật về thanh toán, quảng cáo, khuyến mại, bảo vệ quyền sở hữu trí tuệ, bảo vệ quyền lợi người tiêu dùng và các quy định pháp luật có liên quan khác khi tham gia giao dịch vay tại điểm kết nối giao dịch điện tử XXXDong;</p>
      <p>m. Cam kết, đồng ý không sử dụng dịch vụ tại điểm kết nối giao dịch điện tử XXXDong cho những mục đích bất hợp pháp, không hợp lý, lừa đảo, đe dọa, thăm dò thông tin bất hợp pháp, phá hoại, tạo ra và phát tán vi-rút gây hư hại tới hệ thống, cấu hình, truyền tải thông tin của điểm kết nối giao dịch điện tửXXXDongcho mục đích đầu cơ, tạo lệnh đặt dịch vụ giả, lũng đoạn thị trường, bao gồm phục vụ cho việc phán đoán nhu cầu thị trường. Trong trường hợp vi phạm thì Bên Vay phải chịu trách nhiệm về các hành vi của mình trước pháp luật;</p>
      <p>n. Cam kết không thay đổi, chỉnh sửa, sao chép, truyền bá, phân phối, cung cấp và tạo những công cụ tương tự của dịch vụ do XXXDong cung cấp cho một bên thứ ba nếu không được sự đồng ý của XXXDong;</p>
      <p>o. Không được hành động gây mất uy tín của điểm kết nối giao dịch điện tử XXXDong dưới mọi hình thức, bao gồm nhưng không giới hạn, việc gây mất đoàn kết giữa các thành viên bằng cách sử dụng tên đăng ký thứ hai, thông qua một bên thứ ba, hoặc tuyên truyền, phổ biến những thông tin không có lợi cho uy tín của XXXDong.</p>
      <p>ĐIỀU 5. NỒI DUNG VỀ ĐIỂM KẾT NỐI GIAO DỊCH</p>
      <p>5.1. Bên A và Bên B đồng ý thực hiện các giao dịch chuyển và nhận tiền vay trên điểm kết nối giao dịch điện tử do Bên C là chủ sở hữu và quản lý.</p>
      <p>5.2. Để duy trì hoạt động của điểm kết nối giao dịch điện tử giữa Bên A và Bên B, Bên C có quyền thu một khoản phí hợp lý . Khoản phí này có thể thay đổi theo giá trị thị trường từng thời điểm. Khoản phí này do Bên A chịu.</p>
      <p>5.3. Quy trình giao dịch</p>
      <p>Bước 1: Bên B tải app XXXDong và gửi yêu cầu vay</p>
      <p>Bước 2: Bên C tập hợp hồ sơ của bên B đầy đủ và đưa lên app Nhà đầu tư</p>
      <p>Bước 3: Bên A vào app Nhà đầu tư để chấp nhận cho bên B vay.</p>
      <p>Bước 4: Bên A chuyển tiền vào tài khoản ngân hàng cho bên B vay</p>
      <p>Bước 5: Bên B nhận tiền vay qua tài khoản ngân hàng Kết thúc quy trình vay</p>
      <p>Đến ngày trả nợ, bên B chuyển trả tiền cho bên A .</p>
      <p>5.4. Quy trình về đối soát, thanh toán giao dịch vay:</p>
      <p>Bước 1: Đến hạn trả nợ, bên B chuyển tiền trả nợ cho bên A và phí giới thiệu cho bên C.</p>
      <p>Bước 2: Ngay sau khi bên B chuyển tiền.</p>
      <p>+ Gốc, lãi cho vay chuyển về tài khoản của bên A</p>
      <p>+ Phí tư vấn khoản vay chuyển cho bên A</p>
      <p>Bước 3 : Bên C đối soát khoản vay giữa các bên, sau khi kiểm tra thấy khoản vay đã được thanh toán đầy đủ, bên C tiến hành đóng hồ sơ vay trên hệ thống.</p>
      <p>ĐIỀU 6. QUYỀN LỢI VÀ TRÁCH NHIỆM CỦA BÊN C</p>
      <p>6.1. Bên C có đầy đủ các quyền sau:</p>
      <p>a. Đươc thu phí duy trì dịch vụ của điểm kết nối giao dịch, và các chi phí khác phát sinh như giới thiệu và kết nối giữa Bên Vay và Bên Cho Vay. Mọi chi phí phát sinh bổ sung do Bên A chịu;</p>
      <p>b. Được quyền khai thác, thu thập, sử dụng, quản lý, lưu trữ thông tin các bên theo quy định tại Điều 09 của Hợp đồng này;</p>
      <p>c. Không chịu trách nhiệm, can thiệp, liên quan đối với giao dịch vay giữa Bên A và Bên B trừ trường hợp Bên C phải tham gia với tư cách là một bên hỗ trợ cung cấp thông tin và hỗ trợ giải quyết tranh chấp theo Hợp đồng này và/hoặc trong trường hợp theo yêu cầu của Cơ quan nhà nước có thẩm quyền.</p>
      <p>6.2. Bên C có các trách nhiệm sau:</p>
      <p>a. Thực hiện các chương trình quảng cáo, marketing kết nối giữa người vay và nhà đầu tư;</p>
      <p>b. Tự bỏ chi phí liên quan đến việc giới thiệu, kết nối;</p>
      <p>c. Tự xây dựng cơ sở dữ liệu để lưu trữ, đảm bảo thông tin giao dịch, người sử dụng cũng như bảo hành, sửa chữa khi có sự cố phát sinh;</p>
      <p>d. Gửi thông tin người vay (không trả nợ đúng hạn) cho bên A;</p>
      <p>e. Bảo mật thông tin cá nhân của Bên A và Bên B (trừ trường hợp Bên B không thực hiện đúng và đủ nghĩa vụ trả nợ).</p>
      <p>f. Lưu trữ thông tin đăng ký của cá nhân tham gia điểm kết nối giao dịch điện tử và thường xuyên cập nhật những thông tin thay đổi, bổ sung có liên quan;</p>
      <p>g. Áp dụng các biện pháp cần thiết để đảm bảo an toàn thông tin liên quan đến bí mật kinh doanh của tổ chức, cá nhân và thông tin cá nhân của mỗi bên;</p>
      <p>h. Có biện pháp xử lý kịp thời khi phát hiện hoặc nhận được phản ánh về hành vi kinh doanh vi phạm pháp luật trên sàn giao dịch thương mại điện tử;</p>
      <p>i. Hỗ trợ cơ quan quản lý nhà nước điều tra các hành vi kinh doanh vi phạm pháp luật, cung cấp thông tin đăng ký, lịch sử giao dịch và các tài liệu khác về đối tượng có hành vi vi phạm pháp luật trên điểm kết nối giao dịch điện tử;</p>
      <p>j. Xây dựng thỏa thuận hợp tác với các điều khoản rõ ràng về quyền lợi và nghĩa vụ của mỗi bên tham gia, quy định về chi phí sử dụng phần mềm kết nối, điều kiện thanh toán chi phí, chế độ hỗ trợ, thưởng cho nhà cung cấp dịch vụ vận tải;</p>
      <p>k. Chấm dứt việc cung cấp dịch vụ kết nối đối với các trường hợp không đáp ứng đủ các điều kiện tham gia giao dịch hoặc có hành vi vi phạm pháp luật;</p>
      <p>l. Thông báo đầy đủ cho mỗi bên về điều khoản, điều kiện áp dụng của dịch vụ cung cấp bởi XXXDong;</p>
      <p>m. Hỗ trợ cơ quan quản lý nhà nước điều tra các hành vi vi phạm pháp luật, cung cấp thông tin đăng ký, lịch sử giao dịch và các tài liệu khác về đối tượng có hành vi vi phạm pháp luật trên điểm kết nối giao dịch điện tử.</p>
      <p>ĐIỀU 7. CƠ CHẾ KHAI THÁC, SỬ DỤNG, QUẢN LÝ VÀ BẢO MẬT THÔNG TIN</p>
      <p>7.1. Thu thập Thông tin Cá nhân</p>
      <p>“Thông tin Cá nhân” là thông tin mang tính nhận dạng, bao gồm nhưng không giới hạn tên, số chứng minh thư nhân dân, số giấy khai sinh, số hộ chiếu, quốc tịch, địa chỉ, số điện thoại, số fax, thông tin ngân hàng, thông tin thẻ tín dụng, dân tộc, giới tính, ngày sinh, tình trạng hôn nhân, tình trạng cư trú, nền tảng giáo dục, tình trạng tài chính, sở thích cá nhân, địa chỉ thư điện tử (email) của một bên, nghề nghiệp, định danh, thông tin của một bên, ngành làm việc, bất kỳ thông tin nào về một bên mà bên đó đã cung cấp cho XXXDong trong các đơn đăng ký, đơn xin gia nhập hoặc bất kỳ đơn tương tự nào và/hoặc bất kỳ thông tin nào về bạn đã được hoặc sẽ được XXXDong thu thập, lưu trữ, sử dụng và xử lý theo thời gian và bao gồm các thông tin cá nhân nhạy cảm như các dữ liệu về sức khỏe, tôn giác hoặc tín ngưỡng tương tự khác.</p>
      <p>7.2. Mục đích và phạm vi sử dụng thông tin</p>
      <p>a. Phạm vi thu thập thông tin</p>
      <p>Việc một bên cung cấp Thông tin Cá nhân của một bên là hoàn toàn tự nguyện. Tuy nhiên, nếu một bên không cung cấp cho XXXDong Thông tin Cá nhân của một bên,XXXDong sẽ không thể xử lý Thông tin Cá nhân của một bên cho các Mục đích và Mục đích Bổ sung như được nêu dưới đây.</p>
      <p>Nếu Bên A và Bên B tham gia trong Hợp đồng này thì Thông tin Cá nhân của mỗi bên là bắt buộc, và việc không cung cấp Thông tin Cá nhân sẽ là hành vi vi phạm thỏa thuận hoặc các quy định pháp lý, và có thể khiến XXXDong không thể hợp tác và hỗ trợ với một bên để cung cấp các dịch vụ hoặc sản phẩm hoặc thực hiện các giao dịch hỗ trợ cho một bên về sản phẩm hoặc dịch vụ mà một bên muốn sử dụng.</p>
      <p>Bên cạnh những Thông tin Cá nhân một bên trực tiếp cung cấp cho XXXDong,XXXDong có thể thu thập Thông tin Cá nhân của một bên từ nhiều nguồn khác nhau như:</p>
      <p>Điền các đơn đăng ký hoặc đơn xin gia nhập hoặc các đơn tương tự khác;</p>
      <p>Từ các nguồn công khai khác như danh bạ;</p>
      <p>Từ các trang mạng xã hội của XXXDong, nếu một bên theo dõi, thích hoặc một bên là fan của các trang đó (nếu có);</p>
      <p>Từ các tổ chức báo cáo tín dụng;</p>
      <p>Khi một bên tương tác và giao tiếp vớiXXXDongtại bất kỳ sự kiện hay hoạt động nào;</p>
      <p>Từ nhiều thực thể hoặc đơn vị thuộc XXXDong; hoặc</p>
      <p>Qua việc sử dụng các trang web của XXXDong, bao gồm tất cả các trang web doXXXDongđiều hành và đặt dưới tên thương hiệu tương ứng (“các Trang Web”). Thông tin Cá nhân của một bên có thể được thu thập từ tập cookies được sử dụng trên các Trang Web.</p>
      <p>b. Mục đích và phạm vi sử dụng thông tin</p>
      <p>Mục đích chung:</p>
      <p>Để trả lời các câu hỏi, bình luận và phản hồi của một bên;</p>
      <p>Để liên lạc với một bên về bất kỳ mục đích nào được liệt kê tại Hợp đồng này;</p>
      <p>Để phục vụ mục đích quản lý nội bộ như kiểm toán, phân tích dữ liệu, lưu trữ cơ sở dữ liệu;</p>
      <p>Để phục vụ mục đích phát hiện, ngăn chặn và truy tố tội phạm;</p>
      <p>Để giúp XXXDong tuân thủ các nghĩa vụ theo quy định của pháp luật;</p>
      <p>Để thực hiện các nghĩa vụ của XXXDong theo bất kỳ thỏa thuận nào được ký kết với các bên;</p>
      <p>Để cung cấp cho một bên bất kỳ dịch vụ nào mà bên đó yêu cầu;</p>
      <p>Để xử lý các đăng ký của một bên và để cung cấp các dịch vụ cho khách hàng;</p>
      <p>Khi một bên yêu cầu tải xuống và sử dụng ứng dụng và để cung cấp cho bên đó giấy phép sử dụng ứng dụng;</p>
      <p>Để xử lý, quản lý hoặc xác minh việc đăng ký theo dõi của khách hàng đối vớiXXXDongvà để cung cấp cho khách hàng các lợi ích dành cho người theo dõi;</p>
      <p>Để phát triển, tăng cường, và cung cấp các sản phẩm và dịch vụ để đáp ứng được nhu cầu của một bên;</p>
      <p>Để xử lý việc trao đổi hoặc trả lại sản phẩm;</p>
      <p>Để xử lý các thanh toán liên quan đến bất kỳ sản phẩm hoặc dịch vụ nào mà một bên cung cấp;</p>
      <p>Để liên lạc với mỗi bên theo các thỏa thuận trong Hợp đồng này.</p>
      <p>Mục đích tiếp thị và quảng bá:</p>
      <p>XXXDong cũng sử dụng và xử lý thông tin của khách hàng để thông qua đường bưu điện, điện thoại, tin nhắn sms, trực tiếp và/hoặc qua email:</p>
      <p>Gửi cho khách hàng các cảnh báo, bản tin, cập nhật, bưu phẩm, tài liệu quảng cáo, đặc quyền, lời chúc mừng trong các dịp đặc biệt từ XXXDong, các đối tác, nhà tài trợ và nhà quảng cáo của XXXDong;</p>
      <p>Thông báo và gửi giấy mời cho khách hàng về các sự kiện hoặc hoạt động do XXXDong, đối tác, nhà tài trợ hoặc nhà quảng cáo củaXXXDongtổ chức;</p>
      <p>Xử lý các đăng ký tham gia của một bên vào các sự kiện hoặc hoạt động và để liên lạc với bên đó về sự tham gia tại sự kiện hoặc hoạt động đó;</p>
      <p>Chia sẻ Thông tin Cá nhân của khách hàng giữa các công ty con, công ty liên kết và liên doanh cũng như các đại lý, người bán hàng, nhà cung cấp dịch vụ, đối tác, nhà thầu, những bên có thể liên lạc với khách hàng để tiếp thị về sản phẩm, dịch vụ, sự kiện hoặc khuyến mại của họ.</p>
      <p>Mục đích thu hồi nợ và/hoặc thực hiện Hợp đồng:</p>
      <p>Nhận ủy quyền từ Bên Cho vay hoặc tự mình có quyền công khai thông tin cá nhân, các thông tin liên quan của cá nhân đó của Bên Vay như thông tin lý lịch, hình ảnh nhân thân, chứng minh nhân dân, , video hoặc các thông điệp dữ liệu điện tử khác (hình ảnh có thể là ảnh/clip chứa hình ảnh nhân thân hoặc các đoạn chat, trò chuyện của cá nhân đó)… trên các phương tiện thông tin công cộng bao gồm nhưng không giới hạn mạng xã hội, truyền hình, các phương tiện điện tử trực tuyến khác để hỗ trợ vào việc thực hiện Hợp đồng này và/hoặc hoạt động thu hồi nợ, hoạt động đảm bảo thực hiện nghĩa vụ liên quan khác, khảo sát nhằm đánh giá tín nhiệm…</p>
      <p>7.3. Thời gian lưu trữ thông tin</p>
      <p>Dữ liệu cá nhân của một bên sẽ được bảo mật trên máy chủ của XXXDong.</p>
      <p>7.4. Những người hoặc tổ chức có thể được tiếp cận với thông tin</p>
      <p>a. Chuyển giao Thông tin Cá nhân</p>
      <p>Thông tin Cá nhân của một bên có thể được chuyển giao, truy cập hoặc tiết lộ cho bên thứ ba để phục vụ các Mục đích và Mục đích Bổ sung. Ngoài ra,XXXDongcó thể làm việc với các công ty, nhà cung cấp dịch vụ hoặc cá nhân khác để thay mặtXXXDongthực hiện các chức năng, và vì vậy có thể cung cấp quyền tiếp cận hoặc tiết lộ Thông tin Cá nhân của một bên cho nhà cung cấp dịch vụ hoặc bên thứ ba đó. Bên thứ ba bao gồm, nhưng không giới hạn:</p>
      <p>Các đối tác của XXXDong, bao gồm các bên mà XXXDong cộng tác trong các sự kiện, chương trình và hoạt động nhất định;</p>
      <p>Các công ty tổ chức sự kiện và nhà tài trợ sự kiện;</p>
      <p>Các công ty nghiên cứu thị trường;</p>
      <p>Các nhà cung cấp dịch vụ, bao gồm, các nhà cung cấp dịch vụ công nghệ thông tin (CNTT) về cơ sở hạ tầng, phần mềm và công tác phát triển;</p>
      <p>Các cố vấn chuyên môn và kiểm toán viên bên ngoài, bao gồm cố vấn pháp lý, cố vấn tài chính và chuyên gia tư vấn;</p>
      <p>Các tổ chức khác trong XXXDong; và</p>
      <p>Các cơ quan Chính phủ để thực hiện các quy định của pháp luật.</p>
      <p>Thông tin Cá nhân cũng có thể được chia sẻ liên quan đến giao dịch doanh nghiệp, ví dụ như bán chi nhánh hoặc bộ phận, sáp nhập, hợp nhất, hoặc bán tài sản, hoặc trong trường hợp hiếm là giải thể doanh nghiệp.</p>
      <p>b. Phương thức và công cụ để một bên tiếp cận và chỉnh sửa dữ liệu cá nhân của mình</p>
      <p>Đối với quyền truy cập và/hoặc đính chính Thông tin Cá nhân của một bên,XXXDongcó quyền từ chối các yêu cầu truy cập và/hoặc đính chính Thông tin Cá nhân của một bên với các lý do cho phép theo pháp luật, ví dụ như khi chi phí để cho một bên quyền truy cập không tương xứng với những rủi ro đối với quyền riêng tư của một bên hoặc của một người khác.</p>
      <p>7.5. Thông tin Cá nhân của Trẻ chưa thành niên và Cá nhân Khác</p>
      <p>a. Nếu một bên là một bậc cha mẹ hoặc người giám hộ, xin vui lòng không cho phép trẻ chưa thành niên (người dưới 18 (mười tám) tuổi) dưới sự giám hộ của người dùng gửi Thông tin Cá nhân tới XXXDong. Trong trường hợp Thông tin Cá nhân như vậy được cung cấp cho XXXDong, bằng cách này người dùng chấp thuận cho việc xử lý Thông tin Cá nhân của trẻ chưa thành niên và cá nhân người dùng chấp nhận và đồng ý ràng buộc bởi Hợp đồng này và chịu trách nhiệm đối với các hành động của trẻ.</p>
      <p>b. Trong một số trường hợp một bên có thể đã cung cấp Thông tin Cá nhân liên quan đến cá nhân khác (ví dụ như vợ/chồng, các thành viên trong gia đình hoặc bạn bè của người dùng) và trong những trường hợp đó người dùng thay mặt và đảm bảo rằng người dùng được ủy quyền cung cấp Thông tin Cá nhân của họ cho XXXDong và người dùng đã có sự chấp thuận của họ về việc Thông tin Cá nhân của họ được xử lý và sử dụng theo cách thức như đã nêu trong Hợp đồng này.</p>
      <p>ĐIỀU 8. THỪA NHẬN VÀ CHẤP THUẬN</p>
      <p>8.1. Bằng cách trao đổi, sử dụng các dịch vụ, mua các sản phẩm, hoặc qua làm việc với XXXDong, một bên thừa nhận rằng một bên đã đọc và hiểu Hợp đồng này và đồng ý và chấp thuận việc XXXDong sử dụng, xử lý và chuyển giao Thông tin Cá nhân của các bên như được mô tả trong Hợp đồng này.</p>
      <p>8.2.XXXDongcó quyền chỉnh sửa, cập nhật hoặc sửa đổi các điều khoản của Hợp đồng này bất cứ lúc nào bằng cách công bố Hợp đồng cập nhật trên các Trang Web. Bằng cách tiếp tục trao đổi, bằng cách tiếp tục sử dụng các dịch vụ, mua các sản phẩm hoặc qua tiếp tục làm việc với XXXDong sau khi Hợp đồng này được chỉnh sửa, cập nhật hoặc sửa đổi, những hành động như vậy có nghĩa là một bên chấp nhận những chỉnh sửa, cập nhật hoặc sửa đổi đó.</p>
      <p>ĐIỀU 9. TRÁCH NHIỆM TRONG TRƯỜNG HỢP PHÁT SINH LỖI KỸ THUẬT</p>
      <p>9.1.XXXDongcam kết nỗ lực đảm bảo sự an toàn và ổn định của toàn bộ hệ thống kỹ thuật. Tuy nhiên, trong trường hợp xảy ra sự cố do lỗi của XXXDong,XXXDongsẽ ngay lập tức áp dụng các biện pháp cần thiết để đảm bảo quyền lợi cho thành viên;</p>
      <p>9.2. Khi thực hiện các giao dịch qua Ứng dụng XXXDong, các bên phải thực hiện theo đúng các quy trình đã được hướng dẫn;</p>
      <p>9.3.XXXDong cam kết cung cấp chất lượng dịch vụ tốt nhất cho các bên tham gia giao dịch. Trường hợp phát sinh lỗi kỹ thuật, lỗi phần mềm hoặc các lỗi khách quan khác dẫn đến việc thành viên không thể tham gia giao dịch được thì các bên cần thông báo cho XXXDong.</p>
      <p>9.4.XXXDongsẽ không chịu trách nhiệm giải quyết trong trường hợp thông báo của các bên không đến được XXXDong, phát sinh từ lỗi kỹ thuật, lỗi đường truyền, lỗi phần mềm hoặc lỗi khác không phải doXXXDonggây ra.</p>
      <p>ĐIỀU 10. VI PHẠM HỢP ĐỒNG VÀ BỒI THƯỜNG THIỆT HẠI</p>
      <p>10.1. Trừ Sự kiện bất khả kháng theo Hợp đồng này, trường hợp Bên A và Bên B không thực hiện bất kỳ nội dung quy định trong Hợp đồng này, Bên vi phạm ngay lập tức phải chấm dứt vi phạm của mình, khắc phục những hậu quả do hành vi vi phạm trong một thời gian nhất định được yêu cầu bởi Bên bị vi phạm.</p>
      <p>10.2. Trường hợp có thiệt hại do Bên A và Bên B vi phạm nghĩa vụ gây ra, Bên A và Bên B phải bồi thường toàn bộ thiệt hại cho Bên bị thiệt hại, trừ trường hợp hợp có thỏa thuận khác.</p>
      <p>10.3. Trong mọi trường hợp,XXXDong không chịu bất kì trách nhiệm nào liên quan đến các hành vi vi phạm nghĩa vụ của các Bên trong Hợp đồng này. Đồng thời quy định tại khoản này không giới hạn/loại trừ quyền của XXXDong trong việc phạt vi phạm và yêu cầu bồi thường thiệt hại từ các Bên vi phạm theo quy định tại Khoàn 10.1 và 10.2 của Điều này.</p>
      <p>ĐIỀU 11. SỰ KIỆN BẤT KHẢ KHÁNG</p>
      <p>11.1. Các Bên thống nhất hiểu và nghi nhận Sự kiện bất khả là sự kiện xảy ra một cách khách quan không thể lường trước được và không thể khắc phục được mặc dù đã áp dụng mọi biện pháp cần thiết và khả năng cho phép bao gồm nhưng không giới hạn các sự kiện: thiên tai, hoả hoạn, lũ lụt, động đất, tai nạn, thảm hoạ, hạn chế về dịch bệnh, nhiễm hạt nhân hoặc phóng xạ, chiến tranh, nội chiến, khởi nghĩa, đình công hoặc bạo loạn, can thiệp của Cơ quan Chính phủ, hệ thống thiết bị của các bên gặp sự cố kỹ thuật trong quá trình vận hành khai thác hoặc do hạn chế về khả năng kỹ thuật các hệ thống thiết bị.</p>
      <p>11.2. Nếu một trong các Bên không thể thực thi được toàn bộ hay một phần nghĩa vụ của mình theo Hợp đồng này do Sự kiện bất khả kháng thì Bên đó sẽ phải nhanh chóng thông báo cho bên kia bằng văn bản về việc không thực hiện được nghĩa vụ của mình do Sự kiện bất khả kháng. Bên thông báo việc thực hiện Hợp đồng của họ trở nên không thể thực hiện được do Sự kiện bất khả kháng có trách nhiệm phải thực hiện mọi nỗ lực để hoặc giảm thiểu ảnh hưởng của Sự kiện bất khả kháng đó.</p>
      <p>11.2. Trong thời gian 07 (bảy) ngày kể từ ngày xảy ra Sự kiện bất khả kháng, Bên không thể thực thi được toàn bộ hay một phần nghĩa vụ của mình theo Hợp đồng này do Sự kiện bất khả kháng phải chuyển thư bảo đảm cho Bên có quyền liên quan các bằng chứng về việc xảy ra Sự kiện bất khả kháng và khoảng thời gian xảy ra Sự kiện bất khả kháng đó.</p>
      <p>11.3. Khi Sự kiện bất khả kháng xảy ra, nghĩa vụ của các Bên tạm thời không thực hiện và sẽ ngay lập tức phục hồi lại các nghĩa vụ của mình theo Hợp đồng khi chấm dứt Sự kiện bất khả kháng hoặc khi Sự kiện bất khả kháng đó bị loại bỏ.</p>
      <p>ĐIỀU 12. TẠM HOÃN, CHẤM DỨT, HỦY BỎ HỢP ĐỒNG</p>
      <p>12.1. Tạm hoãn thực hiện nghĩa vụ hợp đồng : là việc các Bên tạm thời không thực hiện một hoặc một số các nghĩa vụ của mình trong một thời hạn nhất định do Bên còn lại ấn định trong các trường hợp sau:</p>
      <p>a. Trường hợp khẩn cấp: Một Bên phát hiện có dấu hiệu bất thường trong quá trình hợp tác mà kết quả có thể dẫn đến thiệt hại cho Bên mình;</p>
      <p>b. Một Bên phát hiện Bên kia vi phạm các điều khoản trong Hợp đồng hoặc không khắc phục các vi phạm trong thời hạn mà Bên bị vi phạm quy định;</p>
      <p>c. Bên thực hiện nghĩa vụ trước chưa thực hiện nghĩa vụ của mình khi đến hạn, các Bên thực hiện nghĩa vụ sau có quyền tạm hoãn việc thực hiện nghĩa vụ đến hạn.</p>
      <p>12.2. Hợp đồng này chấm dứt trong các trường hợp sau đây:</p>
      <p>a. Các Bên hoàn thành đúng và đầy đủ nghĩa vụ của mình theo Hợp đồng;</p>
      <p>b. Các Bên thỏa thuận về việc chấm dứt Hợp đồng;</p>
      <p>c. Trong thời hạn 60 (sáu mươi) ngày kể từ ngày nhận được thông báo về Sự kiện bất khả kháng mà vẫn chưa khắc phục được Sự kiện bất khả kháng, các Bên có quyền thỏa thuận để chấm dứt Hợp đồng;</p>
      <p>d. Các trường hợp khác theo quy định của pháp luật hiện hành.</p>
      <p>Khi chấm dứt thực hiện Hợp đồng, các Bên không phải tiếp tục thực hiện nghĩa vụ, trừ thỏa thuận về phạt vi phạm, bồi thường thiệt hại và thỏa thuận về giải quyết tranh chấp. Bên đã thực hiện nghĩa vụ có quyền yêu cầu bên kia thanh toán phần nghĩa vụ đã thực hiện.</p>
      <p>12.3. Một Bên có quyền hủy bỏ Hợp đồng trong trường hợp sau đây:</p>
      <p>a. Bên có nghĩa vụ không thực hiện đúng nghĩa vụ mà Bên có quyền yêu cầu thực hiện nghĩa vụ trong một thời hạn nhất định nhưng Bên có nghĩa vụ không thực hiện hoặc thực hiện không đúng, không đầy đủ nghĩa vụ thì Bên có quyền có thể hủy bỏ hợp đồng.</p>
      <p>b. Trường hợp Bên có nghĩa vụ không thể thực hiện được một phần hoặc toàn bộ nghĩa vụ của mình làm cho mục đích của Bên có quyền không thể đạt được thì Bên có quyền có thể hủy bỏ Hợp đồng, yêu cầu bồi thường thiệt hại và phạt vi phạm.</p>
      <p>c. Bên có quyền hủy bỏ Hợp đồng phải thông báo ngay cho bên kia biết về việc hủy bỏ, nếu không thông báo mà gây thiệt hại thì phải bồi thường.</p>
      <p>d. Trừ trường hợp quy định tại điểm c khoản 6.4 Điều này, Bên có quyền hủy bỏ Hợp đồng không phải bồi thường thiệt hại.</p>
      <p>ĐIỀU 13. GIẢI QUYẾT TRANH CHẤP</p>
      <p>Trong quá trình thực hiện hợp đồng nếu có tranh chấp phát sinh, các bên sẽ cùng nhau thương lượng giải quyết trên cơ sở bình đẳng, hợp tác. Nếu không giải quyết được thông qua thương lượng, một trong các bên có quyền đưa tranh chấp ra giải quyết tại Toà án nhân dân có thẩm quyền.</p>
      <p>ĐIỀU 14. ĐIỀU KHOẢN CHUNG</p>
      <p>14.1. Hợp đồng này có hiệu lực kể từ ngày ký.</p>
      <p>14.2. Mọi sửa đổi, bổ sung hợp đồng (nếu có) phải được lập bằng văn bản có chữ ký của đại diện có thẩm quyền của các bên.</p>
      <p>14.3. Sự thay đổi người đại diện của các bên không làm thay đổi giá trị của Hợp đồng.</p>
      <p>14.4. Những điều không quy định trong Hợp đồng này sẽ được hiểu và thực hiện theo quy định của pháp luật Việt Nam.</p>
      <p>14.5. Tất cả các điều khoản và từng phần của các điều khoản của Hợp đồng này sẽ có hiệu lực riêng biệt và độc lập với các điều khoản khác và nếu vào bất kỳ thời điểm nào một trong những quy định trên vô hiệu, bất hợp pháp hoặc không thể thi hành theo quy định của pháp luật, thì hiệu lực, giá trị pháp lý và khả năng thi hành của các điều khoản còn lại của Hợp đồng này sẽ không bị ảnh hưởng dưới bất kỳ hình thức nào.</p>
      <p>14.6. Hợp đồng này được lập thành 04 (bốn) bản, có giá trị pháp lý như nhau và có hiệu lực kể từ ngày ký. Trong đó, Bên A, B giữ 01 (một);XXXDong giữ 02 (hai) bản để thực hiện.</p>
      <p>BÊN A</p>
      <p>(Ký và ghi rõ họ tên)</p>
      <p>BÊN B</p>
      <p>(Ký và ghi rõ họ tên)</p>
      <p>ĐẠI DIỆN BÊN C</p>
      <p>(Ký và ghi rõ họ tên)</p>
    </div>
  </van-popup>
</template>

<script>
  import Vue from 'vue';
  import { Popup } from 'vant';
  import CompTitle from '@/components/Title'

  Vue.use(Popup);
  export default {
    name: 'Contract',
    components: {
      CompTitle,
    },
    props: ['asyncUserInfo'],
    data() {
      return {
        show: false
      }
    },
    methods: {
      close() {
        this.show = false;
      }
    }
  }

</script>

<style lang="scss" scoped>
  .contract {
    overflow: hidden;

    width: 100%;
    height: 100%;


    .contract-top {
      font-size: 30px;
      line-height: 60px;
      }

    .contract-content {
      font-size: 24px;

      overflow: scroll;

      height: 100%;
      padding: 105px 40px 40px;

      color: #333;

      .title {
        font-size: 38px;

        text-align: center;

        color: #000;
        }

      .cl1 {
        color: #000;
        }

      p {
        margin-top: 20px;

        text-align: justify;
        text-indent: 40px;

        span {
          margin-left: 12px;

          text-decoration: underline;
          }
        }
      }
    }

</style>
