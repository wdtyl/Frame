<template>
  <div class="signlayer">
    <van-popup v-model="show" @close="close">
      <div class="topdesc">
        <!-- 确认签约 -->
        <div class="title">{{$t('message.confirmSigning')}}</div>
        <!-- 已填写的信息,在签约后不能修改。为了能够顺利借款，确认信息无误。 -->
        <p class="desc">{{$t('message.canNotChange')}}</p>
      </div>
      <div class="btns">
        <van-button class="left" type="default" @click="submit">{{$t('message.confirmSigning')}}</van-button>
        <div class="right" @click="close">{{$t('message.checkAgain')}}</div>
      </div>
    </van-popup>
  </div>
</template>
<script>
import Vue from 'vue'
import service from '@/core/js/service'
import util from '@/core/js/util'
import { Popup, Toast, Button } from 'vant'
Vue.use(Popup)
  .use(Toast)
  .use(Button)
export default {
  name: 'signlayer',
  props: {
    sign: {}
  },
  data() {
    return {
      show: false,
      btnLoading: false
    }
  },
  mounted() {
    // this.$parent.showFlag = false;
  },
  methods: {
    // 上传浏览器id和浏览器信息
    browserUpload() {
      this.$http.post(service.browserUpload, {
        browserId: window.browserId || '',
        browserInfo: window.browserInfo || '',
        uid: util.getCookie('uid'),
        countryCode: encodeURIComponent('+84'),
        productCode: 'EASYPAY'
      })
    },
    submit() {
      if (this.btnLoading) return
      this.btnLoading = true

      let sign = Object.assign({}, this.sign)
      // 获取浏览器指纹
      let fingerPrint = _fmOpt.getinfo()
      sign.fingerPrint = fingerPrint

      this.browserUpload()

      // 接口预留
      this.$http.post('/user/sign_info', sign).then(res => {
        if (res.data.code === 100000) {
          this.$router.push('loanstatus')
        } else {
          this.$toast(res.data.message)
        }
        this.btnLoading = false
      })
    },
    close() {
      if (this.btnLoading) return
      this.show = false
    }
  }
}
</script>
<style lang="scss" scoped>
.signlayer {
  .van-popup {
    width: 544px;
    // height: 380px;
    padding-top: 30px;

    border-radius: 10px;

    .topdesc {
      position: relative;

      .title {
        font-size: 36px;
        font-weight: bold;
        line-height: 38px;

        text-align: center;

        color: rgb(51, 51, 51);
      }

      .desc {
        font-size: 32px;
        line-height: 44px;

        width: 430px;
        margin: 0 auto;
        margin-top: 30px;
        padding-bottom: 38px;

        text-align: justify;

        color: rgb(102, 102, 102);
      }
    }

    .topdesc::after {
      position: absolute;
      right: 0;
      bottom: 0;
      left: 0;

      display: block;

      width: 100%;
      height: 2px;

      content: '';
      transform: scaleY(0.5);

      background: #999;
    }

    .btns {
      padding: 0 30px;

      align-items: center;
      justify-content: space-between;

      div {
        font-size: 38px;
        font-weight: bold;
        line-height: 113px;

        height: 113px;

        text-align: center;

        color: rgb(51, 51, 51);
      }

      .left,
      .right {
        font-size: 38px;
        font-weight: bold;
        line-height: 113px;

        width: 100%;
        height: 113px;

        text-align: center;

        color: rgb(51, 51, 51);
        border: none;
      }

      .left {
        color: rgb(104, 155, 252);
      }
    }
  }
}
</style>
