<template>
  <div class="fillinfo contactinfo">
    <loading v-if="isLoading"></loading>
    <comp-title :title="$t('message.contactInfor')" bg-color="rgb(26, 180, 53)" color="#fff" @clickLeft="clickLeft" :show-back="showBackBtn">
    </comp-title>
    <div class="center">
      <!-- <comp-signingTop></comp-signingTop> -->
      <div class="signingNav"></div>
      <div class="meg">
        <!-- 亲属联系人 -->
        <h4>{{$t('message.relatives')}}</h4>
        <ul class="personMeg">
          <li>
            <!-- 关系 -->
            <div>{{$t('message.relations')}}</div>
            <div class="work-info">
              <input v-model="contactInfoList[0].relationTxt" readonly :placeholder="$t('message.pleaseChoose')">
              <i class="selectIcon" @click="relChangePicker_1()"></i>
            </div>
          </li>
          <li>
            <!-- 亲属全名 -->
            <div>{{$t('message.relNanme')}}</div>
            <input :placeholder="$t('message.pleaseEnter')" v-model="contactInfoList[0].name" />
            <i class="clean" @click="clearInput(1)"></i>
          </li>
          <li>
            <!-- 亲属电话 -->
            <div>{{$t('message.relPhone')}}</div>
            <input type="tel" :placeholder="$t('message.pleaseEnter')" v-model="contactInfoList[0].mobile" />
          </li>
        </ul>
        <!-- 亲属联系人 -->
        <h4>{{$t('message.relatives')}}</h4>
        <ul class="personMeg noBottom">
          <li>
            <!-- 关系 -->
            <div>{{$t('message.relations')}}</div>
            <div class="work-info">
              <input v-model="contactInfoList[1].relationTxt" readonly :placeholder="$t('message.pleaseChoose')">
              <i class="selectIcon" @click="relChangePicker_2()"></i>
            </div>

          </li>
          <li>
            <!-- 联系人全名 -->
            <div>{{$t('message.otherName')}}</div>
            <input :placeholder="$t('message.pleaseEnter')" v-model="contactInfoList[1].name" />
            <i class="clean" @click="clearInput(2)"></i>
          </li>
          <li>
            <!-- 联系人电话 -->
            <div>{{$t('message.otherPhone')}}</div>
            <input type="tel" :placeholder="$t('message.pleaseEnter')" v-model="contactInfoList[1].mobile" />
          </li>
        </ul>
        <!-- zalo & 其他手机号 -->
        <ul class="personMeg">
          <!-- zalo手机号 -->
          <li class="liflex pnum">
            <div class="fl tstyle">{{$t('message.zaloPhone')}}</div>
            <input type="tel" :placeholder="$t('message.pleaseEnter')" class="frinput1" v-model="baseInfo.zaloPhone">
          </li>
          <li class="liflex pnum">
            <div class="pdbtm tstyle">{{$t('message.otherMobile')}}</div>
            <input type="tel" :placeholder="$t('message.pleaseEnter')" v-model="baseInfo.otherMobile" maxlength="10">
          </li>
        </ul>
        <!-- 下一步 -->
        <div class="completebtn" @click="confirmCon">{{$t('message.nextStep')}}</div>
        <!-- 返回 -->
        <div class="backbtn" @click="clickLeft">{{$t('message.goBack')}}</div>
        <div class="bottom-tip">{{$t('message.bottomTip')}}</div>

      </div>
    </div>
    <!-- 关系1选择 -->
    <van-popup v-model="relObj_1.ShowPicker" position="bottom">
      <van-picker :default-index="relDefault1" show-toolbar :columns="relObj_1.list" @confirm="relConfirm_1" @cancel="relOncancel_1" value-key="dictDataValue" />
    </van-popup>
    <!-- 关系2选择 -->
    <van-popup v-model="relObj_2.ShowPicker" position="bottom">
      <van-picker :default-index="relDefault2" show-toolbar :columns="relObj_2.list" @confirm="relConfirm_2" @cancel="relOncancel_2" value-key="dictDataValue" />
    </van-popup>
  </div>
</template>
<script>
  import Vue from 'vue';
  import CompTitle from '@/components/Title';
  // import CompSigningTop from '@/components/SigningTop';
  import Loading from '@/components/loading'
  import '../css/signing.scss'
  import service from '@/core/js/service'
  import constant from '@/core/js/constant';
  import util from '@/core/js/util'
  import { Picker, Popup, Toast } from 'vant';
  Vue.use(Picker).use(Popup).use(Toast);
  export default {
    components: {
      CompTitle,
      // CompSigningTop,
      Loading
    },
    data() {
      return {
        isLoading: true,
        showBackBtn: true,
        baseInfo: {
          zaloPhone: '',
          otherMobile: ''
        },
        contactInfoList: [{
            cType: '1',
            mobile: '', // 亲属电话
            name: '', // 亲属姓名
            relation: '', // 关系
            relationTxt: ''
          },
          {
            cType: '1',
            mobile: '', // 联系人电话
            name: '', //  联系人姓名
            relation: '', // 关系
            relationTxt: ''
          },
        ],
        // 关系1
        relObj_1: {
          ShowPicker: false, //  关系1picker
          list: [], // 关系1列表
        },
        // 关系2
        relObj_2: {
          ShowPicker: false, //  关系2picker
          list: [], // 关系2列表
        },
        relDefault1: '',
        relDefault2: ''
      }
    },
    mounted() {
      util.getUserInfo().then(async (res) => {
        let data = res.data;
        this.contactInfo = data.contactInfo;
        this.baseInfo.zaloPhone = data.baseInfo.zaloPhone || ''
        this.baseInfo.otherMobile = data.workInfo.otherMobile || ''
        this.contactInfo.forEach((item) => {
          if (Number(item.cType) === 2) {
            item.cType = 1
          }
        });
        if (this.contactInfo.length) {
          this.contactInfoList = this.contactInfo
        }
        this.relDefault1 = await this.getDictInfor({ dictTypeCode: 'r_relation' }, this.relObj_1, 'relation', this.contactInfoList[0]);

        // 关系1
        let contLength = this.contactInfo.length;
        let txt = this.relObj_1.list[this.relObj_1.list.findIndex(element => element.dictDataCode === this.contactInfoList[0].relation)]
        if (!txt) {
          txt = {}
        }
        let relationTxt = contLength > 1 ? txt : '';
        this.contactInfoList[0].relationTxt = relationTxt.dictDataValue || '';

        // 关系2
        // this.relDefault2 = await this.getDictInfor({ dictTypeCode: 'o_relation' }, this.relObj_2, 'relation', this.contactInfoList[1]);
        this.relObj_2.list = this.relObj_1.list
        let list1 = this.contactInfoList[1]
        if (list1['relation']) {
          let defaultNum = this.relObj_2.list.findIndex(e => e === list1['relation'])
          defaultNum = defaultNum >= 0 ? defaultNum : ''
          if (defaultNum < 0) {
            defaultNum = ''
            list1['relation'] = ''
          }
          this.relDefault2 = defaultNum
        }

        // 关系2
        let txt1 = this.relObj_2.list[this.relObj_2.list.findIndex(element => element.dictDataCode === this.contactInfoList[1].relation)]
        if (!txt1) {
          txt1 = {}
        }
        let relationTxt1 = contLength === 2 ? txt1 : '';
        this.contactInfoList[1].relationTxt = relationTxt1.dictDataValue || '';

        // 反显结束
        this.isLoading = false;
      });
    },
    methods: {
      confirmCon() {
        if (!this.contactInfoList[0].relation) {
          this.$toast(this.$t('message.pcKinship')); // 请选择亲属关系
        } else if (this.contactInfoList[0].name.length > 50) {
          this.$toast(this.$t('message.piCorrectlyRName'))
        } else if (!this.contactInfoList[0].name) {
          this.$toast(this.$t('message.relNameCannot')); // 亲属姓名不能为空
        } else if (!this.contactInfoList[0].mobile) {
          this.$toast(this.$t('message.relPhoneCannot')); // 亲属手机号不能为空
        } else if (/^(\d)\1+$/.test(this.contactInfoList[0].mobile) || !constant.MOBILE_REG.test(this.contactInfoList[0].mobile)) {
          this.$toast(this.$t('message.peRelPhone')); // 请输入正确的亲属手机号
        } else if (!this.contactInfoList[1].relation) {
          this.$toast(this.$t('message.pcKinship')); // 请选择其他联系人关系
        } else if (this.contactInfoList[1].name.length > 50) {
          this.$toast(this.$t('message.piCorrectlyRName'))
        } else if (!this.contactInfoList[1].name) {
          this.$toast(this.$t('message.relNameCannot')); // 其他联系人姓名不能为空
        } else if (!this.contactInfoList[1].mobile) {
          this.$toast(this.$t('message.relPhoneCannot')); // 其他联系人电话不能为空
        } else if (/^(\d)\1+$/.test(this.contactInfoList[1].mobile) || !constant.MOBILE_REG.test(this.contactInfoList[1].mobile)) {
          this.$toast(this.$t('message.peRelPhone')); // 请输入正确的其他联系人手机号
        } else if (this.contactInfoList[0].name === this.contactInfoList[1].name) {
          this.$toast(this.$t('message.noRepeatName')); // 请勿输入相同的联系人姓名
        } else if (this.contactInfoList[0].mobile === this.contactInfoList[1].mobile) {
          this.$toast(this.$t('message.noRepeatMobile')); // 请勿输入相同的联系人电话
        } else if (this.baseInfo.zaloPhone && (/^(\d)\1+$/.test(this.baseInfo.zaloPhone) || !constant.MOBILE_REG.test(this.baseInfo.zaloPhone))) {
          this.$toast(this.$t('message.pePhone')); // 请输入正确的手机号
        } else if (this.baseInfo.otherMobile && (/^(\d)\1+$/.test(this.baseInfo.otherMobile) || !constant.MOBILE_REG.test(this.baseInfo.otherMobile))) {
          this.$toast(this.$t('message.pePhone')); // 请输入正确的手机号
        } else {
          this.$http.post('/user/contact_info', { contacts: JSON.stringify(this.contactInfoList), otherMobile: this.baseInfo.otherMobile, zaloPhone: this.baseInfo.zaloPhone }).then(res => {
            if (res.data.code === 100000) {
              this.$router.push('sign');
            } else {
              this.$toast(res.data.message)
            }
          })
        }
      },
      getDictInfor(dictObj, selObj, val, dataInfor) {
        return this.$http.post(service.getDictionary, dictObj).then(res => {
          selObj.list = res.data.data.dataGather;
          let defaultIndex = '';
          if (dataInfor[val]) {
            defaultIndex = selObj.list.findIndex(element => element.dictDataCode === dataInfor[val])
            if (defaultIndex < 0) {
              dataInfor[val] = ''
            }
          }
          return defaultIndex;
        })
      },
      clickLeft() {
        this.$router.go(-1)
      },
      // 关系1选择
      relConfirm_1(value, index) {
        this.relObj_1.ShowPicker = false;
        this.contactInfoList[0].relationTxt = value.dictDataValue;
        this.contactInfoList[0].relation = value.dictDataCode;
      },
      relOncancel_1() {
        this.relObj_1.ShowPicker = false;
      },
      relChangePicker_1(index) {
        this.relObj_1.ShowPicker = true;
      },
      // 关系2选择
      relConfirm_2(value, index) {
        this.relObj_2.ShowPicker = false;
        this.contactInfoList[1].relationTxt = value.dictDataValue;
        this.contactInfoList[1].relation = value.dictDataCode;
      },
      relOncancel_2() {
        this.relObj_2.ShowPicker = false;
      },
      relChangePicker_2(index) {
        this.relObj_2.ShowPicker = true;
      },
      // 清空input值
      clearInput(msg) {
        if (msg === 1) {
          this.contactInfoList[0].name = '';
          this.$set(this.contactInfoList, 0, this.contactInfoList[0])
        } else if (msg === 2) {
          let conlist = Array.from(this.contactInfoList);
          conlist[1].name = '';
          this.contactInfoList = conlist;
        }
      }
    }
  }

</script>
<style lang="scss" scoped>
  .contactinfo {
    background: #fff;

    .center {
      overflow: hidden;

      padding-top: 85px;

      .noBottom {
        margin-bottom: 0;
      }

      .personMeg {
        li {
          input.frinput {
            float: right;

            width: 50%;
            padding-right: 60px;

            text-align: right;
          }

          input {
            font-size: 28px;

            padding-left: 25px;
          }

        }

        div.tstyle::before {
          content: '';
          padding-right: 30px;
        }

      }

      .signingNav {
        background: url('../images/navicon2.png') 0 0 no-repeat;
        background-size: 100% 100%;
      }

      .tips {
        font-size: 28px;

        color: rgb(51, 51, 51);

        span {
          color: rgb(0, 27, 255);
        }
      }

      .completebtn {
        font-size: 34px;
        line-height: 84px;

        width: 600px;
        height: 84px;
        margin: 20px auto;

        text-align: center;

        color: #fff;
        border-radius: 10px;
        background: $themeBgColor;
        box-shadow: 0 6px 10px rgba(39, 177, 60, .42);
      }

      .backbtn {
        font-size: 34px;
        line-height: 84px;

        width: 600px;
        height: 84px;
        margin: 40px auto;

        text-align: center;

        color: rgb(153, 153, 153);
        border: 1px solid rgb(79, 79, 79);
        border-radius: 10px;
      }
    }
  }

</style>
