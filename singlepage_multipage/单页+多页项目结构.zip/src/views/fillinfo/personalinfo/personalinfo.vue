<template>
  <div class="fillinfo signing">
    <loading v-if="isLoading"></loading>
    <comp-title :title="$t('message.personalInfor')" bg-color="rgb(26, 180, 53)" color="#fff" @clickLeft="clickLeft" :show-back="showBackBtn"></comp-title>
    <div class="center">
      <!-- <comp-signingTop></comp-signingTop> -->
      <div class="signingNav"></div>
      <div class="meg">
        <ul class="personMeg">
          <!-- 姓名 -->
          <li>
            <div class="pdbtm">{{$t('message.userName')}}</div>
            <input :placeholder="$t('message.pleaseEnter')" v-model="userInfo.name">
            <i class="clean" @click="clearInput('name')"></i>
          </li>
          <!-- 身份证号 -->
          <li>
            <div class="pdbtm">{{$t('message.idCard')}}</div>
            <input type="number" :placeholder="$t('message.pleaseEnter')" v-model="userInfo.idCard">
          </li>
          <!-- 从事行业 -->
          <!-- <li class="liflex">
            <div class="fl">{{$t('message.career')}}</div>
            <input v-model="userInfo.industryTxt" readonly class="frinput" :placeholder="$t('message.pleaseChoose')">
            <i class="selectIcon selectIcon1" @click="causeChangePicker"></i>
          </li> -->
          <!-- 生日 -->
          <li>
            <div class="pdbtm">{{$t('message.birthdayDate')}}</div>
            <input type="tel" placeholder="dd.mm.yyyy" v-model="userInfo.birthday">
          </li>
          <li>
            <div>{{$t('message.career')}}</div>
            <div class="work-info">
              <input :value="causeName" readonly class="frinput" :placeholder="$t('message.pleaseChoose')">
              <i class="selectIcon" @click="causeChangePicker"></i>
            </div>
          </li>
          <!-- 性别 -->
          <li class="liflex">
            <div class="fl">{{$t('message.gender')}}</div>
            <p>
              <label>
                <input type="radio" :value="manValut" name="sex" :checked="checkedMan" @change="changeInput(1)">
                <i></i>
                <span>{{$t('message.man')}}</span>
              </label>
              <label>
                <input type="radio" :value="womanValue" name="sex" :checked="checkedWoman" @change="changeInput(2)">
                <i></i>
                <span>{{$t('message.woman')}}</span>
              </label>
            </p>
          </li>
          <!-- Facebook注册手机号 -->
          <!-- <li class="liflex pnum">
            <div class="fl tstyle">{{$t('message.fbPhone')}}</div>
            <input type="tel" :placeholder="$t('message.pleaseEnter')" class="frinput1" v-model="userInfo.fbPhone">
          </li> -->
          <!-- zalo注册手机号 -->
          <!-- <li class="liflex pnum">
            <div class="fl tstyle">{{$t('message.zaloPhone')}}</div>
            <input type="tel" :placeholder="$t('message.pleaseEnter')" class="frinput1" v-model="userInfo.zaloPhone">
          </li> -->
          <!-- 居住地址 -->
          <li class="address">
            <div class="pdbtm">{{$t('message.resAddress')}}</div>
            <dl>
              <!-- 省 -->
              <dt>{{$t('message.province')}}</dt>
              <dd>
                <input v-model="userInfo.province" readonly class="frinput" :placeholder="$t('message.pleaseChoose')">
                <i class="selectIcon" @click="prChangePicker"></i>
              </dd>
            </dl>
            <!-- 城市  -->
            <dl>
              <dt>{{$t('message.area')}}</dt>
              <dd>
                <input v-model="userInfo.city" readonly class="frinput" :placeholder="$t('message.pleaseChoose')">
                <i class="selectIcon" @click="cityChangePicker"></i>
              </dd>
            </dl>
            <!-- 社区  -->
            <dl>
              <dt>{{$t('message.commune')}}</dt>
              <dd>
                <input v-model="userInfo.county" readonly class="frinput" :placeholder="$t('message.pleaseChoose')">
                <i class="selectIcon" @click="coChangePicker"></i>
              </dd>
            </dl>
          </li>
          <!-- 详细地址 -->
          <li>
            <div class="pdbtm">{{$t('message.dlAddrss')}}</div>
            <input :placeholder="$t('message.streetNum')" v-model="userInfo.address">
          </li>
          <!-- 居住时长 -->
          <!-- <li class="liflex">
            <div class="fl">{{$t('message.longLive')}}</div>
            <input v-model="userInfo.liveTimeTxt" readonly class="frinput" :placeholder="$t('message.pleaseChoose')">
            <i class="selectIcon selectIcon1" @click="liveChangePicker"></i>
          </li> -->
        </ul>
        <!-- 下一步 -->
        <div class="completebtn" @click="confirmUserInfo">{{$t('message.nextStep')}}</div>
        <!-- 返回 -->
        <div class="backbtn" @click="goBack">{{$t('message.goBack')}}</div>
        <div class="bottom-tip">{{$t('message.bottomTip')}}</div>
      </div>
    </div>
    <!-- 事业 -->
    <van-popup v-model="causeObj.ShowPicker" position="bottom">
      <van-picker :default-index="causeIndex" show-toolbar :columns="causeObj.list" @confirm="causeConfirm" @cancel="causeOncancel" value-key="dictDataValue" />
    </van-popup>
    <!-- 省选择 -->
    <van-popup v-model="prObj.ShowPicker" position="bottom">
      <van-picker :default-index="prDefault" show-toolbar :columns="prObj.list" @confirm="prConfirm" @cancel="prOncancel" />
    </van-popup>
    <!-- 城市 -->
    <van-popup v-model="cityObj.ShowPicker" position="bottom">
      <van-picker :default-index="cityDefault" show-toolbar :columns="cityObj.list_c" @confirm="cityConfirm" @cancel="cityOncancel" />
    </van-popup>
    <!-- 社区 -->
    <van-popup v-model="coObj.ShowPicker" position="bottom">
      <van-picker :default-index="coDefault" show-toolbar :columns="coObj.list_c" @confirm="coConfirm" @cancel="coOncancel" />
    </van-popup>
    <!-- 居住时长 -->
    <!-- <van-popup v-model="liveObj.ShowPicker" position="bottom">
      <van-picker :default-index="liveDefault" show-toolbar :columns="liveObj.list" @confirm="liveConfirm" @cancel="liveOncancel" value-key="dictDataValue" />
    </van-popup> -->
  </div>
</template>

<script>
  import Vue from 'vue';
  import CompTitle from '@/components/Title';
  // import CompSigningTop from '@/components/SigningTop';
  import Loading from '@/components/loading'
  import '../css/signing.scss';
  import service from '@/core/js/service'
  import util from '@/core/js/util'
  import { Picker, Popup, Toast } from 'vant';
  // import constant from '@/core/js/constant';
  Vue.use(Picker).use(Popup).use(Toast);
  export default {
    components: {
      CompTitle,
      // CompSigningTop,
      Loading
    },
    data() {
      return {
        isLoading: true,
        showBackBtn: true,
        userInfo: {
          name: '', // 姓名
          idCard: '', // 身份证号
          birthday: '', // 生日
          // industry: '', //   事业赋值
          gender: '',
          // fbPhone: '', // facebook手机号
          // zaloPhone: '', // zalo手机号
          province: '', //  省赋值
          city: '', //  城市赋值
          county: '', // 社区赋值
          address: '', // 详细地址
          // liveTime: '', // 居住时长赋值
          industry: '', // 事业码表
          // liveTimeTxt: ''
        },
        checkedMan: false, // 男
        checkedWoman: false, // 女
        manValut: 'M',
        womanValue: 'F',
        // // 事业
        causeShowName: '', // 事业展示值
        causeObj: {
          ShowPicker: false, //  事业picker
          list: [] //  事业数组
        },
        // 省
        prObj: {
          ShowPicker: false, //  省picker
          list: [], // 省列表
        },
        // 城市
        cityObj: {
          ShowPicker: false, // 城市picker
          list: {}, // 总城市列表
          list_c: [], // 单省城市列表
        },
        // 社区
        coObj: {
          ShowPicker: false, // 社区picker
          list: {}, // 社区列表
          list_c: [], // 单城市社区列表
        },
        // 居住时长
        // liveObj: {
        //   ShowPicker: false, // 居住时长picker
        //   list: [], // 居住时长数组
        // },
        causeDefault: '',
        liveDefault: '',
        prDefault: '',
        cityDefault: '',
        coDefault: ''
      };
    },
    created() {
      this.findWork()
      this.handleGetCityInfoSucc();
    },
    mounted() {
      util.getUserInfo().then(async (res) => {
        let data = res.data;
        data.baseInfo.zaloPhone = data.baseInfo.zaloPhone ? data.baseInfo.zaloPhone : ''
        data.baseInfo.fbPhone = data.baseInfo.fbPhone ? data.baseInfo.fbPhone : ''
        this.userInfo = data.baseInfo;
        switch (this.userInfo.gender) {
          case 'F':
            this.checkedWoman = true;
            this.userInfo.gender = this.womanValue; // 女
            break;
          case 'M':
            this.checkedMan = true;
            this.userInfo.gender = this.manValut; // 男
            break;
          default:
            break;
        }
        // this.causeDefault = await util.getDictInfor({ dictTypeCode: 'industry' }, this.causeObj, 'industry', this.userInfo);
        // this.liveDefault = await util.getDictInfor({ dictTypeCode: 'live_time' }, this.liveObj, 'liveTime', this.userInfo);
        // 事业
        // let industry = this.causeObj.list[this.causeObj.list.findIndex(element => element.dictDataCode === data.baseInfo.industry)]

        // this.userInfo.industryTxt = industry ? industry.dictDataValue : '';
        // 居住时长
        // let liveTime = this.liveObj.list[this.liveObj.list.findIndex(element => element.dictDataCode === data.baseInfo.liveTime)]

        // this.userInfo.liveTimeTxt = liveTime ? liveTime.dictDataValue : '';
        // 省
        this.prDefault = this.prObj.list.findIndex(element => element === data.baseInfo.province);
        this.userInfo.province = this.prObj.list[this.prDefault] || '';
        // 城市
        this.cityObj.list_c = this.cityObj.list[this.userInfo.province] || [];
        this.cityDefault = this.cityObj.list_c.findIndex(element => element === data.baseInfo.city);
        this.userInfo.city = this.cityObj.list_c[this.cityDefault] || '';
        // 社区
        let coList = this.coObj.list[this.userInfo.province];
        this.coObj.list_c = coList ? this.coObj.list[this.userInfo.province][this.userInfo.city] : [];
        // this.coObj.list_c = this.coObj.list[this.userInfo.province][this.userInfo.city] || [];
        this.coDefault = this.coObj.list_c.findIndex(element => element === data.baseInfo.county);
        this.userInfo.county = this.coObj.list_c[this.coDefault] || '';
        // 反显结束
        this.isLoading = false;
      });
    },
    methods: {
      goBack() {
        window.location = './index.html';
      },
      confirmUserInfo() {
        //  else if (!this.userInfo.fbPhone && !this.userInfo.zaloPhone) {
        //   this.$toast(this.$t('message.phoneCannot')); // 请填写Facebook手机号或者zalo手机号
        // } else if (this.userInfo.fbPhone && (/^(\d)\1+$/.test(this.userInfo.fbPhone) || !constant.MOBILE_REG.test(this.userInfo.fbPhone))) {
        //   this.$toast(this.$t('message.pePhone')); // 请输入正确的手机号
        // } else if (this.userInfo.zaloPhone && (/^(\d)\1+$/.test(this.userInfo.zaloPhone) || !constant.MOBILE_REG.test(this.userInfo.zaloPhone))) {
        //   this.$toast(this.$t('message.pePhone')); // 请输入正确的手机号
        // }  else if (!this.userInfo.liveTime) {
        //   this.$toast(this.$t('message.pcResidence')); // 请选择居住时长
        // }
        for (let key in this.userInfo) {
          if (!this.userInfo[key]) {
            delete this.userInfo[key]
          }
        }
        let birnum = this.userInfo.birthday.split('.');
        if (!this.userInfo.name) {
          this.$toast(this.$t('message.nameCannot')); // 姓名不能为空
        } else if (this.userInfo.name.length > 50) {
          this.$toast(this.$t('message.piCorrectlyName'));
        } else if (!this.userInfo.idCard || !/^\d{9}(\d{3})?$/.test(this.userInfo.idCard)) {
          this.$toast(this.$t('message.piCorrectlyIDCard'));
        } else if (!this.userInfo.birthday) {
          this.$toast(this.$t('message.birDayCannot')); // 生日不能为空
        } else if ((birnum[0] > 31 || birnum[0] < 1) || (birnum[1] > 12 || birnum[1] < 1) || birnum[2] < 1850) {
          this.$toast(this.$t('message.birthdayError'));
        } else if (!this.userInfo.gender) {
          this.$toast(this.$t('message.pcGender')); // 请选择性别
        } else if (!this.userInfo.province) {
          this.$toast(this.$t('message.pcpRovince')); // 请选择省
        } else if (!this.userInfo.city) {
          this.$toast(this.$t('message.pcDistrict')); // 请选择区
        } else if (!this.userInfo.county) {
          this.$toast(this.$t('message.pcCommune')); // 请选择公社
        } else if (!this.userInfo.address || this.userInfo.address.length > 99) {
          this.$toast(this.$t('message.piCorrectlyAddress'));
        } else if (!this.userInfo.industry) {
          this.$toast(this.$t('message.pcResidence')); // 请选择居住时长
        } else {
          this.$http.post('/user/base_info', this.userInfo).then(res => {
            if (res.data.code === 100000) {
              this.$router.push('contactinfo');
            } else {
              this.$toast(res.data.message)
            }
          })
        }
      },
      changeInput(index) {
        if (index === 1) {
          this.userInfo.gender = this.manValut; // 男
        } else if (index === 2) {
          this.userInfo.gender = this.womanValue; // 女
        }
      },
      clickLeft() {
        window.location = './index.html';
      },
      //  获取城市
      handleGetCityInfoSucc() {
        let res;
        require.ensure(
          [],
          require => {
            res = require('./vietnam-city-new.js');
            this.prObj.list = res.provinceList;
            this.cityObj.list = res.cityList;
            this.coObj.list = res.countyList;
          },
          'cityJson'
        );
      },
      // 获取事业码表
      findWork() {
        this.$http.post(service.getDictionary, { dictTypeCode: 'industry' }).then(res => {
          let result = res.data.data
          this.causeObj.list = result.dataGather
        })
      },
      // // 事业
      causeConfirm(value, index) {
        this.causeObj.ShowPicker = false;
        this.userInfo.industry = value.dictDataCode;
        this.userInfo.industryTxt = value.dictDataValue;
      },
      causeOncancel() {
        this.causeObj.ShowPicker = false;
      },
      causeChangePicker() {
        this.causeObj.ShowPicker = true;
      },
      // 省
      prConfirm(value, index) {
        this.prObj.ShowPicker = false;
        this.userInfo.province = value;
        this.cityObj.list_c = this.cityObj.list[value];
      },
      prOncancel() {
        this.prObj.ShowPicker = false;
      },
      prChangePicker(index) {
        this.prObj.ShowPicker = true;
      },
      // 城市
      cityConfirm(value, index) {
        this.cityObj.ShowPicker = false;
        this.userInfo.city = value;
        this.coObj.list_c = this.coObj.list[this.userInfo.province][value];
      },
      cityOncancel() {
        this.cityObj.ShowPicker = false;
      },
      cityChangePicker(index) {
        if (this.userInfo.province === '') {
          this.$toast('请选择省');
        } else {
          this.cityObj.ShowPicker = true;
        }
      },
      // 社区
      coConfirm(value, index) {
        this.coObj.ShowPicker = false;
        this.userInfo.county = value;
        console.log(value);
      },
      coOncancel() {
        this.coObj.ShowPicker = false;
      },
      coChangePicker(index) {
        if (this.userInfo.province === '') {
          this.$toast('请选择省');
        } else if (this.userInfo.city === '') {
          this.$toast('请选择城市');
        } else {
          this.coObj.ShowPicker = true;
        }
      },
      // 居住时长
      // liveConfirm(value, index) {
      //   this.liveObj.ShowPicker = false;
      //   this.userInfo.liveTime = value.dictDataCode;
      //   this.userInfo.liveTimeTxt = value.dictDataValue;
      // },
      // liveOncancel() {
      //   this.liveObj.ShowPicker = false;
      // },
      // liveChangePicker(index) {
      //   this.liveObj.ShowPicker = true;
      // },
      // 清空input值
      clearInput(msg) {
        this.userInfo[msg] = '';
      },
    },
    watch: {
      newPr(val, oldVal) {
        if (oldVal) {
          if (val !== oldVal) {
            this.userInfo.city = '';
            this.userInfo.county = '';
          }
        }
      },
      newCity(val, oldVal) {
        if (oldVal) {
          if (val !== oldVal) {
            this.userInfo.county = '';
          }
        }
      },
      // 生日格式
      birDate(val, oldVal) {
        if (val) {
          if (val.length > oldVal.length) {
            if (val.length === 2) {
              this.userInfo.birthday = this.userInfo.birthday + '.'
            }
            if (val.length === 5) {
              this.userInfo.birthday = this.userInfo.birthday + '.'
            }
            if (val.length > 10) {
              this.userInfo.birthday = this.userInfo.birthday.substring(0, 10);
            }
          }
        }
      }
    },
    computed: {
      newPr() {
        return this.userInfo.province
      },
      newCity() {
        return this.userInfo.city
      },
      birDate() {
        return this.userInfo.birthday || ''
      },
      causeIndex() {
        return this.causeObj.list.findIndex(e => e.dictDataCode === this.userInfo.industry) || 0
      },
      causeName() {
        let name = this.causeObj.list[this.causeIndex]
        if (name) {
          return name.dictDataValue
        } else {
          return ''
        }
      },
    }
  };

</script>
<style lang="scss" scoped>
  .signing {
    background: #fff;

    .center {
      overflow: hidden;

      padding-top: 84px;

      color: rgb(51, 51, 51);

      .personMeg {
        li {
          height: 139px;
          padding: 30px 0;

          input {
            font-size: 28px;

            padding-left: 25px;
            }

          div.pdbtm {
            padding-bottom: 10px;
            }

          div {
            padding: 0;
            }

          div.fl {
            float: left;
            }

          div.tstyle {
            font-size: 30px;

            padding-left: 25px;
            }

          div.tstyle::before {
            display: none;
            }

          // .selectIcon {
          //   bottom: 17px;
          //   }

          // .selectIcon1 {
          //   bottom: 50%;

          //   transform: translateY(50%);
          //   }

          .clean {
            bottom: 17px;
            }

          input.frinput {
            width: 50%;
            padding-right: 65px;

            // text-align: right;
            }

          input.frinput1 {
            width: 50%;

            text-align: right;
            }

          input.cityipt {
            overflow: hidden;

            width: 90%;

            white-space: nowrap;
            text-overflow: ellipsis;
            }
          }

        li.address {
          height: auto;

          // border-bottom: none;

          dl {
            font-size: 30px;
            line-height: 60px;

            position: relative;

            overflow: hidden;

            height: 60px;
            margin-top: 40px;
            padding-left: 25px;



            dt {
              float: left;

              width: 20%;
              }

            dd {
              float: left;

              width: 74%;

              input {
                width: 100%;
                padding-right: 10px;

                text-align: right;
                }

              .selectIcon {
                bottom: 8px;
                }
              }
            }

          dl:nth-of-type(1) {
            margin-top: 0;
            }
          }

        .pnum {
          input.frinput1 {
            width: 40%;
            }
          }

        .liflex {
          display: flex;

          align-items: center;
          justify-content: space-between;

          p {
            text-align: right;

            label {
              position: relative;

              width: 80px;

              text-align: right;

              input {
                position: absolute;
                top: 10px;

                float: none;

                width: 14px;
                height: 14px;
                }

              input[type='radio'] {
                display: none;
                }

              span {
                position: relative;

                float: none;

                padding-left: 49px;

                color: rgb(39, 177, 60);
                }

              input[type='radio']+i {
                position: absolute;
                top: 0;
                left: 0;

                display: block;

                width: 40px;
                height: 40px;

                content: '';
                transform: scale(.5);

                border: 1px solid #646464;
                border-radius: 100%;
                }

              input[type='radio']:checked+i::after {
                position: absolute;
                top: 3px;
                left: 3px;

                display: block;

                width: 28px;
                height: 28px;

                content: '';

                border-radius: 100%;
                background: #646464;
                }
              }

            label:nth-of-type(1) {
              padding-right: 54px;
              }
            }
          }
        }

      .signingNav {
        background: url('../images/navicon1.png') 0 0 no-repeat;
        background-size: 100% 100%;
        }

      .tips {
        font-size: 28px;

        color: rgb(51, 51, 51);

        span {
          color: rgb(0, 27, 255);
          }
        }

      .completebtn {
        font-size: 34px;
        line-height: 84px;

        width: 600px;
        height: 84px;
        margin: 20px auto;

        text-align: center;

        color: #fff;
        border-radius: 10px;
        background: $themeBgColor;
        box-shadow: 0 6px 10px rgba(39, 177, 60, .42);
        }

      .backbtn {
        font-size: 34px;
        line-height: 84px;

        width: 600px;
        height: 84px;
        margin: 40px auto;

        text-align: center;

        color: rgb(153, 153, 153);
        border: 1px solid rgb(79, 79, 79);
        border-radius: 10px;
        }
      }
    }

</style>
