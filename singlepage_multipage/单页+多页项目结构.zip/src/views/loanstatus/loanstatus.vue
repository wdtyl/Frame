<template>
  <div class="loanstatus">
    <loading v-if="isLoading"></loading>
    <comp-title :title="title" bg-color="rgb(26, 180, 53)" color="#fff" @clickLeft="clickLeft" :show-back="showBackBtn"></comp-title>
    <div v-if="status === '1' && loanDetail.idCardStatus === '0'">
      <div class="main_body">
        <div class="all-tip">
          <p><span>*</span>{{$t('addition.word8')}}</p>
        </div>
        <div class="uploader_container">
          <van-uploader ref="uploader1" :after-read="onRead1"></van-uploader>
          <div class="placeholder">
            <div class="plho" v-show="!src1" @click="choose1">
              <img class="plh1" v-lazy="plh1" alt srcset>
              <div class="tip">{{$t('addition.word1')}}</div>
            </div>
            <div class="img_container" v-show="src1" @click="choose1">
              <img id="src1" :src="src1" alt srcset>
            </div>
          </div>
        </div>
        <div class="uploader_container container2">
          <van-uploader ref="uploader2" :after-read="onRead2"></van-uploader>
          <div class="placeholder">
            <div class="plho" v-show="!src2" @click="choose2">
              <img class="plh2" v-lazy="plh2" alt srcset>
              <div class="tip tip2">{{$t('addition.word2')}}</div>
            </div>
            <div class="img_container" v-show="src2" @click="choose2">
              <img id="src2" :src="src2" alt srcset>
            </div>
          </div>
        </div>
        <div class="completebtn" :class="{'disabled': !(src1 !== '' && src2 !== '')}" @click="src1 !== '' && src2 !== '' && confirmPop()">{{$t('addition.word10')}}</div>
        <!-- <div class="agree">{{$t('addition.word3')}}</div> -->
      </div>
    </div>
    <div v-else>
      <div class="stcont" v-if="status !== ''">
        <!-- 放款状态图片 -->
        <img :src="status === '1' ? require('./images/loaninaudit.png') : (status === '3' ? require('./images/lending.png') : (status === '4' ? require('./images/applyfail.png') : require('./images/applyfail.png')))" alt class="img-3" :class="{'img-1': status==='1', 'img-2': status==='3', 'img-3': status==='4'}">
        <!-- 借款申请审核中 / 借款申请已通过审核，放款中 / 您提交的银行账户有误，放款失败 -->
        <p class="stutxt">{{status === '1' ? $t('message.loanReview') : (status === '3' ? $t('message.applyReleased') : (status === '4' ? $t('message.bankInforFail') : $t('message.loanApplyFail')))}}</p>
        <!-- 刷新界面查看贷款状态 -->
        <p class="refreshdesc" v-if="status==='1'">{{$t('message.refreshInter')}}</p>
      </div>
      <ul v-if="status === '1' || status === '3'">
        <!-- 申请日期 -->
        <li class="item">
          <span>{{$t('message.applyDate')}}</span>
          <span>{{loanDetail.applyDate}}</span>
        </li>
        <!-- 申请金额 -->
        <li class="item">
          <span>{{$t('message.applyAmount')}}</span>
          <span>{{loanDetail.applyAmount | number(0,'.','.')}}VND</span>
        </li>
        <!-- 申请期限 -->
        <li class="item">
          <span>{{$t('message.applyPeriod')}}</span>
          <span>{{loanDetail.repayDay}}{{$t('message.daysNum')}}</span>
        </li>
        <!-- 申请状态 -->
        <li class="item bordernone">
          <span>{{$t('message.applyStatus')}}</span>
          <span class="txtcolor">{{status==='1' ? $t('message.review') : $t('message.pass')}}</span>
        </li>
        <!-- 返回首页 -->
        <!-- <button class="goindex" v-if="status==='1'" @click="goIndex">{{$t('message.goIndex')}}</button> -->
        <!-- 您的借款申请正在审核中，预计1-2个工作日内工作人员会联系您，请保持手机通畅 / 您的借款申请已通过审核，正在审核，预计1-2个工作日内到账；若未收到款请先与您银行卡所在银行进行核对，其它问题请联系客服：111111111； -->
        <div class="btmtxt">{{status==='1' ? $t('message.keepPhone') : $t('message.contactCustomer')}}</div>
      </ul>
    </div>
    <in-form ref="showFlag"></in-form>
  </div>
</template>
<script>
  // import '../fillinfo/css/signing.scss';
  import Vue from 'vue'
  import Compressor from 'compressorjs';
  import CompTitle from '@/components/Title.vue'
  import Loading from '@/components/loading'
  import service from '@/core/js/service'
  import InForm from './components/inform.vue';
  import { Uploader, Toast, Icon } from 'vant'
  Vue.use(Uploader)
    .use(Toast)
    .use(Icon)
  export default {
    name: 'loanstatus',
    components: {
      CompTitle,
      Loading,
      InForm
    },
    data() {
      return {
        isLoading: true,
        title: '', //  审核页面title
        showBackBtn: true,
        status: '', // 状态 loaninaudit 审核 , lending 通过, applyfail 失败
        idCardStatus: '', // 还款凭证状态
        loanDetail: {},
        src1: '',
        src2: '',
        plh1: require('./images/plh1.png'),
        plh2: require('./images/plh2.png')
      }
    },
    mounted() {
      let applyId = this.$route.params.applyId || ''
      this.findLoanDetail(applyId).then(res => {
        let result = res.data
        if (result.applyStatus > 4 && result.applyStatus < 6) {
          this.$router.push('loandetails')
          return
        } else if (result.applyStatus > 6 || !result.applyStatus) {
          window.location = './index.html'
          return
        }

        this.loanDetail = result
        this.status = result.applyStatus.toString()
        //  && xxx = 0
        console.log(result.applyStatus === 1 && result.idCardStatus === '0')
        if (result.applyStatus === 1 && result.idCardStatus === '0') {
          this.$refs.showFlag.show = true
          this.getUploadProgress()
          return
        }
        // 取消loading
        this.isLoading = false
      })
    },
    methods: {
      clickLeft() {
        this.$router.go(-1)
      },
      findLoanDetail(applyId) {
        return this.$http.post(service.getLoanDetail, { applyId }).then(res => res.data)
      },
      goIndex() {
        window.location = './index.html'
      },
      choose1() {
        this.$refs.uploader1.$refs.input.click()
      },
      choose2() {
        this.$refs.uploader2.$refs.input.click()
      },
      showImg(file, index) {
        // 一加浏览器图片翻转问题
        let reg = /oneplus/i
        let rotate = false
        let promise = new Promise((resolve, reject) => {
          if (reg.test(window.navigator.userAgent)) {
            EXIF.getData(file.file, function() {
              if (EXIF.getTag(this, 'Orientation') === 6) {
                rotate = true
              }
              resolve()
            });
          } else {
            resolve()
          }
        })
        promise.then(() => {
          if (index === 1) {
            let src1 = document.querySelector('#src1')
            src1.style.visibility = 'hidden';
            this.src1 = file.content
            this.resizeImg(src1, rotate)
          } else if (index === 2) {
            let src2 = document.querySelector('#src2')
            src2.style.visibility = 'hidden';
            this.src2 = file.content
            this.resizeImg(src2, rotate)
          }
        })
      },
      resizeImg(img, rotate) {
        if (rotate) {
          img.onload = function() {
            let naturalWidth = img.naturalWidth
            let naturalHeight = img.naturalHeight
            let imgContainer = document.querySelector('.img_container')
            let icWidth = imgContainer.offsetWidth
            let icHeight = imgContainer.offsetHeight
            let ratio = naturalWidth / naturalHeight
            let icRatio = icWidth / icHeight
            if (ratio >= icRatio) {
              img.classList.add('rotate1')
            } else {
              img.classList.add('rotate2')
            }
            img.style.visibility = 'visible';
          }
        } else {
          img.classList.remove('rotate1')
          img.classList.remove('rotate2')
          img.style.visibility = 'visible';
        }
      },
      onRead1(file, detail) {
        if (this.src1 === file.content) {
          return
        }
        let formData = new FormData()
        formData.append('type', 'idCard')
        formData.append('extra_param', 0)
        this.showImg(file, 1)
        this.compress(file, formData, 1)
      },
      onRead2(file, detail) {
        if (this.src2 === file.content) {
          return
        }
        let formData = new FormData()
        formData.append('type', 'liveness')
        formData.append('extra_param', 0)
        this.showImg(file, 2)
        this.compress(file, formData, 2)
      },
      // 压缩图片
      compress(file, formData, index) {
        let _this = this
        let compress = new Compressor(file.file, { // eslint-disable-line
          quality: 0.4,
          success(result) {
            // alert(result.size / 1024 / 1024 + 'MB')
            // The third parameter is required for server
            formData.append('image', result);
            // Send the compressed image file to server with XMLHttpRequest.
            _this.upload(formData, index)
          },
          error(err) {
            // 压缩出错，直接上传
            formData.append('image', file.file);
            _this.upload(formData, index)
            console.log(err.message);
          },
        });
      },
      // 上传照片
      upload(formData, index) {
        this.isLoading = true

        this.$http
          .post(service.upload, formData, {
            isFile: true
          })
          .then(res => {
            if (Number(res.data.code) === 100000) {
              this.isLoading = false
            } else {
              if (index === 1) {
                this.src1 = ''
              } else if (index === 2) {
                this.src2 = ''
              }
              this.isLoading = false
              this.$toast(this.$t('addition.word5'))
            }
          })
          .catch(() => {
            if (index === 1) {
              this.src1 = ''
            } else if (index === 2) {
              this.src2 = ''
            }
            this.isLoading = false
            this.$toast(this.$t('addition.word4'))
          })
      },
      // 获取图片上传地址
      getUploadProgress() {
        this.$http
          .post(service.getUploadProgress)
          .then(res => {
            if (Number(res.data.code) === 100000) {
              this.isLoading = false
              let data = res.data.data
              this.src1 = data.idCard0
              this.src2 = data.liveness0
            } else {
              this.isLoading = false
              this.$toast(res.data.message)
            }
          })
          .catch(() => {
            this.isLoading = false
          })
      },
      // 完成
      confirmPop() {
        this.isLoading = true
        this.$http
          .post(service.getUploadProgress)
          .then(res => {
            if (Number(res.data.code) === 100000) {
              this.isLoading = false
              let data = res.data.data
              if (data.idCard0 && data.liveness0) {
                // this.$router.push('sign')
                this.loanDetail.idCardStatus = 1
              } else {
                this.$toast('addition.word6')
              }
            } else {
              this.isLoading = false
              this.$toast(res.data.message)
            }
          })
          .catch(() => {
            this.isLoading = false
          })
      }
    }
  }

</script>
<style lang="scss" scoped>
  .loanstatus {
    padding: 86px 0 35px 0;

    background: #fff;

    .all-tip {
      margin-top: 98px;
      text-align: center;
      font-size: 28px;
      color: #333;

      span {
        color: #ff0000;
        }
      }

    .img-3 {
      width: 495px;
      height: 282px;
      }

    .stcont {
      width: 100%;
      margin-bottom: 75px;
      padding-top: 40px;

      background: #fff;

      img {
        display: block;

        width: auto;
        margin: 0 auto;
        }

      .img-1 {
        width: 441px;
        height: 287px;
        }

      .img-2 {
        width: 548px;
        height: 312px;
        }

      // .img-3 {
      //   width: 495px;
      //   height: 282px;
      // }

      p {
        font-size: 34px;
        line-height: 50px;

        height: 50px;

        text-align: center;
        }

      .refreshdesc {
        color: rgb(252, 136, 45);
        }
      }

    ul {
      overflow: hidden;

      padding: 0 30px;

      li {
        display: flex;

        height: 110px;

        border-top: 1px solid #e6e6e6;

        align-items: center;
        justify-content: space-between;

        span:nth-of-type(1) {
          font-size: 30px;

          color: rgb(102, 102, 102);
          }

        span:nth-of-type(2) {
          font-size: 32px;

          color: rgb(51, 51, 51);
          }

        span.txtcolor {
          color: rgb(39, 178, 60);
          }
        }

      .bordernone {
        border-bottom: 1px solid #e6e6e6;
        }
      }

    .goindex {
      font-size: 32px;

      display: block;

      width: 670px;
      height: 90px;
      margin: 97px auto 0;

      color: #fff;
      border-radius: 10px;
      background: rgb(39, 177, 60);
      box-shadow: 0 6px 10px rgba(39, 177, 60, .42);
      }

    .btmtxt {
      font-size: 24px;
      line-height: 35px;

      margin-top: 58px;
      padding: 0 45px;

      color: #1ab435;
      }

    .canvas_container {
      height: 0;
      width: 0;
      // overflow: hidden;
      }

    .main_body {
      background-color: #fff;
      padding-bottom: 80px;
      }

    .block {
      height: 10px;

      background-color: #f5f5f5;
      }

    .signingNav {
      background: url('../fillinfo/images/navicon3.png') 0 0 no-repeat;
      background-size: 100% 100%;
      }

    .uploader_container {
      padding-top: 40px;
      background-color: #fff;

      &.container2 {
        padding-top: 40px;
        }
      }

    .van-uploader {
      float: left;
      visibility: hidden;
      }

    .placeholder {
      width: 560px;
      height: 330px;
      margin: 0 auto;

      border-radius: 7px;
      background-color: #f5f8ff;

      .plho {
        text-align: center;
        }

      .plh1 {
        width: 283px;
        height: 185px;
        margin-top: 44px;
        }

      .plh2 {
        width: 252px;
        height: 207px;
        margin-top: 28px;
        }

      .tip {
        font-size: 30px;

        margin-top: 16px;
        padding: 0 10px;

        color: #000;

        &.tip2 {
          margin-top: 10px;
          }
        }
      }

    .completebtn {
      font-size: 34px;
      line-height: 84px;

      width: 600px;
      height: 84px;
      margin: 70px auto 20px;

      text-align: center;

      color: #fff;
      border-radius: 10px;
      background: $themeBgColor;

      &.disabled {
        background: #ccc;
        }
      }

    .img_container {
      overflow: hidden;

      width: 100%;
      height: 100%;

      img {
        position: relative;
        top: 50%;
        left: 50%;

        max-width: 100%;
        max-height: 100%;

        transform: translate(-50%, -50%);

        &.rotate1 {
          width: 100%;
          height: auto;
          transform: translate(-50%, -50%) rotate(90deg);
          }

        &.rotate2 {
          height: 100%;
          width: auto;
          transform: translate(-50%, -50%) rotate(90deg);
          }
        }
      }

    .agree {
      font-size: 28px;

      text-align: center;

      color: #000;
      }
    }

</style>
