<template>
  <div class="inform">
    <van-popup v-model="show" @close="close">
      <div class="topdesc">
        <div class="module"></div>
        <div class="title">{{$t('addition.word11')}}</div>
        <p class="desc">{{$t('addition.word12')}}{{$t('addition.word13')}}</p>
        <div class="btns">
          <div class="right" @click="close">{{$t('addition.word14')}}</div>
        </div>
      </div>
    </van-popup>
  </div>
</template>
<script>
  import Vue from 'vue'
  import { Popup, Button } from 'vant'
  Vue.use(Popup)
    .use(Button)
  let timer
  export default {
    name: 'inform',
    data() {
      return {
        show: false,
        // btnLoading: false
      }
    },
    mounted() {
      // this.$parent.showFlag = false;
      timer = setTimeout(() => {
        this.show = false
      }, 3000);
    },
    methods: {
      close() {
        // if (this.btnLoading) return
        clearTimeout(timer)

        this.show = false
      }
    }
  }

</script>
<style lang="scss" scoped>
  .inform {
    .van-popup {
      overflow: initial;
      width: 516px;
      // height: 380px;

      border-radius: 30px;

      .module {
        width: 174px;
        height: 174px;
        background: url('./images/module.png') no-repeat;
        background-size: cover;
        margin: -25px auto 0;
        }

      .topdesc {
        position: relative;

        .title {
          font-size: 34px;
          line-height: 38px;

          text-align: center;

          color: #333;
          }

        .desc {
          font-size: 28px;
          line-height: 45px;

          width: 226px;
          margin: 0 auto;
          margin-top: 20px;
          padding-bottom: 60px;

          text-align: center;

          color: rgb(102, 102, 102);
          }
        }

      .btns {
        padding: 0 62px;

        align-items: center;
        justify-content: space-between;

        .right {
          font-size: 32px;
          font-weight: bold;
          line-height: 88px;

          width: 100%;
          height: 88px;

          text-align: center;

          border: none;
          background-color: #ff5028;
          box-shadow: -9px 6px 13px 0px rgba(255, 80, 40, 0.3);
          border-radius: 44px;
          color: #ffffff;
          margin-bottom: 66px;
          }

        }
      }
    }

</style>
