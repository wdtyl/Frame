<template>
  <div class="aboutus">
    <comp-title :title="title" bg-color="rgb(26, 180, 53)" color="#fff" @clickLeft="clickLeft" :show-back="true">
    </comp-title>
    <div class="main">
      <div class="top">
        <!-- <img class="top_img" v-lazy="topImg" alt=""> -->
        <img class="top_img" v-lazy="topImg" alt="">
        <p class="app_name">Easypay</p>
      </div>
      <div class="info">
        <div>
          <div class="title">
            <span>EasyPay - cho vay tiêu dùng ngắn hạn</span>
          </div>
          <div class="content">
            Đối với tiêu dùng cá nhân của mọi người, chúng tôi sẽ cung cấp dịch vụ tư vấn. Và cung cấp một số phương thức cho vay, không cần bằng chứng thu nhập, chỉ cần nộp đơn trực tuyến, cung cấp thông tin tài khoản, bạn sẽ nhận được khoản vay ngay lập tức.
          </div>
        </div>
        <div>
          <div class="title">
            <span>Chăm sóc khách hàng：</span>
          </div>
          <div class="content">
            <div>Email : cs@easypay.vn</div>
            <div style="text-align: left">Chăm sóc khách hàng：0938932313 zalo /0938738303 zalo </div>
          </div>
        </div>
        <div>
          <div class="title">
            <span>Thời gian làm việc</span>
          </div>
          <div class="content">
            Thứ Hai đến thứ Sáu 9:00-18:00
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import CompTitle from '@/components/Title';
  export default {
    components: {
      CompTitle,
    },
    data() {
      return {
        title: 'về chúng tôi',
        topImg: require('./images/logo.png')
      }
    },
    mounted() {

    },
    methods: {
      clickLeft() {
        this.$router.go(-1)
      },
    }
  }

</script>

<style lang="scss" scoped>
  .aboutus {
    // height: 100%;
    background-color: #fff;

    .main {
      padding: 85px 30px 0;

      .top {
        margin: 0 auto;
        padding: 70px 0 0;
      }

      .top_img {
        display: block;
        width: 150px;
        height: 150px;
        margin: 0 auto;
        box-shadow: 2px 2px 20px 0px #ded;
      }

      .app_name {
        text-align: center;
        margin: 34px 0;
        font-size: 36px;
        line-height: 1;
        color: #4d4d4d;
      }

      .info {
        padding-bottom: 100px;

        .title {
          font-weight: 700;

          height: 32px;
          margin: 56px 0 36px;
          padding-left: 20px;

          color: #333;
          background: url(./images/bg-rect.png) left top no-repeat;
          background-size: 6px 100%;

          span {
            font-size: 32px;
            line-height: 32px;

            float: left;

            margin-top: 4px;
          }
        }
      }

      .content {
        font-size: 28px;
        line-height: 44px;

        margin: 0 10px;

        text-align: justify;

        color: #666;
      }
    }
  }

</style>
