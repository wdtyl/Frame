<template>
  <div class="repayguide">
    <comp-title :title="$t('message.repayGuide')" bg-color="rgb(26, 180, 53)" color="#fff" @clickLeft="clickLeft" :show-back="isShowBack"></comp-title>
    <div class="main">
      <div class="my-steps">
        <div class="my-step">
          <div class="my-step-item">
            <div class="my-step-content">
              <div class="my-step-title">Techcombank</div>
              <div class="my-step-theme">
                <p>Tên tài khoản : CONG TY TNHH THUONG MAI DAI THANH </p>
                <p>Số Tài Khoản : 191 3476 4609 023</p>
                <p>Tên Ngân Hàng : NH TMCP Ky Thuong VN techcombank ( chi nhánh Lãnh Binh Thăng)</p>
              </div>
              <div class="my-step-title">Sacombank</div>
              <div class="my-step-theme">
                <p>Tên tài khoản ：CONG TY TNHH THUONG MAI DAI THANH</p>
                <p>Số tài khoản：0602 3216 8288</p>
                <p>Tên Ngân Hàng: Ngân hàng Sài Gòn Thương Tín (Sacombank) - chi nhánh Bình Tây</p>
              </div>
              <div class="my-step-tip">Chú ý: Khi hoàn tiền, xin vui lòng ghi mã hoàn tiền tại nội dung chuyển khoản nhằm giúp việc xác nhận đơn thanh toán của quý khách thuận tiện hơn
                <p>Chú ý: xin xác nhận lại tài khoản hoàn tiền, tất cả những thông báo trả nợ không bao gồm 2 tài khoản này đều là giả mạo
                </p>
              </div>
            </div>
            <div class="my-step-icon a1"></div>
            <div class="my-step-line"></div>
          </div>
          <div class="my-step-item">
            <div class="my-step-content">
              <div class="my-step-title">chú ý: khi hoàn tiền, xin vui lòng ghi mã hoàn tiền tại nội dung chuyển khoản nhằm giúp việc xác nhận đơn thanh toán của quý khách thuận tiện hơn</div>
            </div>
            <div class="my-step-icon a2"></div>
            <div class="my-step-line"></div>
          </div>
          <div class="my-step-item">
            <div class="my-step-content">
              <div class="my-step-title">lưu sao kê ngân hàng và tải lên tại APP</div>
            </div>
            <div class="my-step-icon a3"></div>
          </div>
        </div>
      </div>
    </div>
    <div class="tip">
      <p>
        <span>Ngân hàng giờ làm việc:</span>Thứ Hai ến thứ Sáu 9:00-18:00
      </p>
      <p>
        <span>Email :</span> cs@easypay.vn
      </p>
      <p>
        <span>Chăm sóc khách hàng：</span>‭0938932313 zalo /0938738303 zalo
      </p>
    </div>
    <div class="button_container" v-if="isShowBack">
      <!-- 现在还款 -->
      <van-button class="go_repay" @click="goRepay">{{$t('message.repayNow')}}</van-button>
    </div>
  </div>
</template>

<script>
  import Vue from 'vue'
  import { Button } from 'vant'
  import CompTitle from '@/components/Title'
  import util from '@/core/js/util'
  Vue.use(Button)
  export default {
    components: {
      CompTitle
    },
    data() {
      return {
        isShowBack: true
      }
    },
    mounted() {
      let query = this.$route.query
      if (query.hasOwnProperty('xjfawfj')) {
        this.isShowBack = false
      }
    },
    methods: {
      clickLeft() {
        this.$router.go(-1)
      },
      goRepay() {
        // 跳转贷款历史
        if (util.getCookie('uid')) {
          this.$router.push('loanhistory')
        } else {
          window.location = './index.html'
        }
      }
    }
  }

</script>

<style lang="scss" scoped>
  .repayguide {
    height: 100%;
  }

  .main {
    background: #f5f5f5;

    margin: 85px 30px 0;

    .my-steps {
      background: #fff;
      padding-left: 72px;
      padding-top: 40px;

      .my-step-item {
        position: relative;

        .my-step-content {
          padding: 6px 0 52px;

          .my-step-title {
            font-size: 26px;
            line-height: 46px;
            color: #27b13c;
          }

          .my-step-theme {
            font-size: 24px;
            color: #666;
            padding: 15px 30px;
            background-color: #f5f5f5;

            margin-top: 10px;
            margin-bottom: 15px;

            p {
              margin-bottom: 10px;
              line-height: 42px;

              &:last-child {
                margin-bottom: 0;
              }
            }
          }

          .my-step-tip {
            font-size: 20px;
            line-height: 38px;
            color: #999999;

            p {
              color: red;
            }
          }
        }

        .my-step-icon {
          position: absolute;
          left: -72px;
          top: 0;
          z-index: 2;
          width: 48px;
          height: 48px;

          &.a1 {
            background: url('./images/1@2x.png');

            background-size: 100%;
          }

          &.a2 {
            background: url('./images/2@2x.png');

            background-size: 100%;
          }

          &.a3 {
            background: url('./images/3@2x.png');

            background-size: 100%;
          }
        }

        .my-step-line {
          position: absolute;
          left: -48px;
          top: 0;
          z-index: 1;
          width: 2px;
          height: 100%;
          background: #ebebeb;
        }
      }
    }

    .info {
      font-size: 28px;

      margin: 220px 0 74px 150px;

      color: #666;

      .item {
        margin-bottom: 6px;
      }
    }
  }

  .tip {
    background: #f5f5f5;
    padding: 30px;
    font-size: 24px;

    p {
      line-height: 46px;
      margin-bottom: 10px;
      color: #999999;

      span {
        color: #666;
      }
    }
  }

  .button_container {
    background: #f5f5f5;
    text-align: center;
  }

  .go_repay {
    font-size: 38px;

    width: 362px;
    height: 86px;
    margin-bottom: 100px;

    color: #fff;
    border-radius: 10px;
    background-color: #27b23d;
  }

</style>
