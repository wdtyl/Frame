<template>
  <div class="login-box">
    <comp-title
      :title="title"
      bg-color="rgb(26, 180, 53)"
      color="#fff"
      @clickLeft="clickLeft"
      :show-back="true"
    ></comp-title>
    <div class="input-area">
      <div class="area-code">+84</div>
      <div class="input">
        <input type="tel" v-model="loginForm.mobile" placeholder="0 xxx xxx xxx" />
      </div>
    </div>
    <van-button
      class="completebtn"
      :loading="isLoading"
      type="primary"
      :loading-text="$t('login.w2')"
      size="large"
      @click="activation"
    >{{$t('login.w2')}}</van-button>
    <div class="footer">{{$t('login.w3')}}</div>
    <van-dialog
      v-model="isShowVerif"
      :title="$t('login.w5')"
      class="my-dialog"
      :show-confirm-button="false"
    >
      <div class="img" @click="refreshVerifCode">
        <img :src="verifInfo.image" />
      </div>
      <van-password-input
        :value="verifForm.digits"
        :mask="false"
        :length="4"
        :gutter="25"
        :focused="showKeyboard"
        @focus="showKeyboard = true"
      />
      <van-button
        class="completebtn submitbtn"
        :loading="submitLogin"
        type="primary"
        :loading-text="$t('login.w6')"
        size="large"
        @click="userLogin"
        :disabled="verifForm.digits.length !== 4"
      >{{$t('login.w6')}}</van-button>
    </van-dialog>
    <van-number-keyboard
      :show="showKeyboard"
      @input="onInput"
      @delete="onDelete"
      @blur="showKeyboard = false"
    />
  </div>
</template>

<script>
import Vue from 'vue'
import util from '@/core/js/util'
import CompTitle from '@/components/Title.vue'
// import service from '@/core/js/service'
import { Toast, Button, Dialog, PasswordInput, NumberKeyboard } from 'vant'
const channelKey = util.getQueryStringRegExp('channelKey') || ''

Vue.use(Toast)
  .use(Button)
  .use(Dialog)
  .use(PasswordInput)
  .use(NumberKeyboard)
export default {
  name: 'login',
  components: {
    CompTitle
  },
  data() {
    return {
      title: this.$t('login.w1'),
      loginForm: {
        mobile: ''
      },
      verifInfo: {
        id: '',
        image: ''
      },
      verifForm: {
        digits: ''
      },
      isLoading: false,
      submitLogin: false,
      isShowVerif: false,
      showKeyboard: false
    }
  },
  methods: {
    clickLeft() {
      this.$router.go(-1)
    },
    activation() {
      let reg = /^0\d{9}$/
      let reg1 = /^(\d)\1+$/
      this.isLoading = true
      if (!reg.test(this.loginForm.mobile) || reg1.test(this.loginForm.mobile)) {
        this.$toast(this.$t('login.w4'))
        this.isLoading = false
        return false
      }
      this.findVerifCode().then(() => {
        this.isLoading = false
        this.isShowVerif = true
      })
    },
    findVerifCode() {
      return this.$http.get('/query/captcha', { params: { mobile: this.loginForm.mobile } }).then(res => {
        if (res.data.code === 100000) {
          this.verifInfo = res.data.data
        } else {
          this.$toast(res.data.message)
        }
        return res
      })
    },
    refreshVerifCode() {
      this.verifForm.digits = ''
      this.findVerifCode()
    },
    userLogin() {
      this.submitLogin = true
      let form = {
        mobile: this.loginForm.mobile,
        channelName: channelKey,
        captchaId: this.verifInfo.id,
        digits: this.verifForm.digits
      }
      this.$http.post('/user/login_by_captcha', form).then(res => {
        let data = res.data
        if (data.code === 100000) {
          // 跳转首页
          this.verifInfo.digits = ''
          this.$toast(this.$t('login.w7'))
          setTimeout(() => {
            window.location = `./index.html?uid=${data.data.uid}&token=${data.data.token}&channelKey=${channelKey}`
          }, 200)
        } else if (data.code === 300002) {
          this.$toast(this.$t('login.w8'))
          this.refreshVerifCode()
        } else {
          this.$toast(data.message)
        }
        this.submitLogin = false
      })
    },
    onInput(key) {
      this.verifForm.digits = (this.verifForm.digits + key).slice(0, 4)
    },
    onDelete() {
      this.verifForm.digits = this.verifForm.digits.slice(0, this.verifForm.digits.length - 1)
    }
  }
}
</script>

<style lang="scss" scoped>
.login-box {
  padding: 258px 46px 0;
  height: 100%;
  min-height: 900px;
  overflow: hidden;
  position: relative;
}

.input-area {
  display: flex;

  border: solid 1px #c3c3c3;
  border-radius: 5px;
  font-size: 33px;

  line-height: 100px;

  .area-code {
    width: 140px;

    color: #3d403f;
    font-weight: bold;
    text-align: center;
    background-color: #eeeeee;
    border-right: solid 1px #c3c3c3;
  }

  .input {
    // line-height: 100px;
    color: #3d403f;
    flex: 1;

    input {
      padding-left: 30px;
      width: 100%;
    }
  }
}

.completebtn {
  margin-top: 40px;
  font-size: 32px;
  line-height: 96px;
  height: 96px;

  padding: 0;

  text-align: center;

  color: #fff;
  border-radius: 10px;
  background-color: $themeBgColor;
  box-shadow: 0 6px 10px rgba(39, 177, 60, 0.42);
}

.submitbtn {
  margin: 0 0 48px;
  line-height: 80px;
  height: 80px;
  font-size: 30px;
}

.footer {
  font-size: 26px;
  line-height: 30px;
  text-align: center;
  color: #999999;
  position: absolute;
  bottom: 67px;
  width: 80%;
  left: 50%;
  transform: translateX(-50%);
}

.my-dialog {
  border-radius: 10px;
  width: 80%;
  /deep/.van-dialog__header {
    font-size: 26px !important;
    color: #000000 !important;
    padding-top: 40px !important;
  }
}

/deep/.van-dialog__content {
  margin-top: 32px;
  padding: 0 30px;

  .img {
    width: 300px;
    height: 96px;

    margin: 0 auto;

    img {
      width: 100%;
      height: 100%;
    }
  }
}

.van-password-input {
  margin: 61px 0 50px;

  .van-password-input__security {
    height: 105px;

    li {
      background-color: #eeeeee;
      border-radius: 10px;
      line-height: 105px;
      font-size: 46px;
      overflow: hidden;

      .van-password-input__cursor {
        animation: none;
        width: 100%;
        height: 3px;
        background-color: #00b13d;
        top: 98%;
      }
    }
  }
}

.van-number-keyboard {
  z-index: 9999 !important;

  /deep/.van-number-keyboard__body {
    .van-key {
      line-height: 90px !important;
      height: 90px !important;
    }
  }
}
</style>
