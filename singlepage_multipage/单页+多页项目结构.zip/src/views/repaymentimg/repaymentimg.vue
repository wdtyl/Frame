<template>
  <div class="fillinfo additional">
    <loading v-if="isLoading"></loading>
    <comp-title :title="$t('')" bg-color="rgb(26, 180, 53)" color="#fff" @clickLeft="clickLeft" :show-back="true"></comp-title>
    <div class="main_body">
      <div class="all-tip">
        <p><span>*</span>{{$t('addition.word9')}}</p>
      </div>
      <div class="uploader_container">
        <van-uploader ref="uploader1" :after-read="onRead1"></van-uploader>
        <div class="placeholder">
          <div class="plho" v-show="!src1" @click="choose1">
            <img class="plh1" v-lazy="plh1" alt srcset>
            <div class="tip">{{$t('addition.word7')}}</div>
          </div>
          <div class="img_container" v-show="src1" @click="choose1">
            <img id="src1" :src="src1" alt srcset>
          </div>
        </div>
      </div>
      <div class="completebtn" :class="{'disabled': src1 === ''}" @click="src1 !== '' && confirmPop()">{{$t('addition.word10')}}</div>
    </div>
  </div>
</template>

<script>
  import Compressor from 'compressorjs';
  import Vue from 'vue'
  import CompTitle from '@/components/Title'
  import Loading from '@/components/loading'
  // import util from '@/core/js/util'
  import service from '@/core/js/service'
  import { Uploader, Toast, Icon } from 'vant'
  Vue.use(Uploader)
    .use(Toast)
    .use(Icon)

  export default {
    data() {
      return {
        isLoading: false,
        src1: '',
        applyId: '',
        plh1: require('./images/plh1.png')
      }
    },
    components: {
      CompTitle,
      Loading
    },
    mounted() {
      this.applyId = this.$route.params.applyId || ''
    },
    methods: {
      choose1() {
        this.$refs.uploader1.$refs.input.click()
      },
      choose2() {
        this.$refs.uploader2.$refs.input.click()
      },
      clickLeft() {
        this.$router.go(-1)
      },
      showImg(file) {
        // 一加浏览器图片翻转问题
        let reg = /oneplus/i
        let rotate = false
        let promise = new Promise((resolve, reject) => {
          if (reg.test(window.navigator.userAgent)) {
            EXIF.getData(file.file, function() {
              if (EXIF.getTag(this, 'Orientation') === 6) {
                rotate = true
              }
              resolve()
            });
          } else {
            resolve()
          }
        })
        promise.then(() => {
          let src1 = document.querySelector('#src1')
          src1.style.visibility = 'hidden';
          this.src1 = file.content
          this.resizeImg(src1, rotate)
        })
      },
      resizeImg(img, rotate) {
        if (rotate) {
          img.onload = function() {
            let naturalWidth = img.naturalWidth
            let naturalHeight = img.naturalHeight
            let imgContainer = document.querySelector('.img_container')
            let icWidth = imgContainer.offsetWidth
            let icHeight = imgContainer.offsetHeight
            let ratio = naturalWidth / naturalHeight
            let icRatio = icWidth / icHeight
            if (ratio >= icRatio) {
              img.classList.add('rotate1')
            } else {
              img.classList.add('rotate2')
            }
            img.style.visibility = 'visible';
          }
        } else {
          img.classList.remove('rotate1')
          img.classList.remove('rotate2')
          img.style.visibility = 'visible';
        }
      },
      onRead1(file, detail) {
        if (this.src1 === file.content) {
          return
        }
        let formData = new FormData()
        formData.append('type', 'repayment')
        formData.append('extra_param', 0)
        formData.append('apply_id', this.applyId)
        this.showImg(file)
        this.compress(file, formData)
      },
      // 压缩图片
      compress(file, formData) {
        let _this = this
        let compress = new Compressor(file.file, { // eslint-disable-line
          quality: 0.4,
          success(result) {
            // alert(result.size / 1024 / 1024 + 'MB')
            // The third parameter is required for server
            formData.append('image', result);
            // Send the compressed image file to server with XMLHttpRequest.
            _this.upload(formData)
          },
          error(err) {
            // 压缩出错，直接上传
            formData.append('image', file.file);
            _this.upload(formData)
            console.log(err.message);
          },
        });
      },
      // 上传照片
      upload(formData) {
        this.isLoading = true

        this.$http
          .post(service.upload, formData, {
            isFile: true
          })
          .then(res => {
            if (Number(res.data.code) === 100000) {
              this.isLoading = false
            } else {
              this.src1 = ''
              this.isLoading = false
              this.$toast(this.$t('addition.word5'))
            }
          })
          .catch(() => {
            this.src1 = ''
            this.isLoading = false
            this.$toast(this.$t('addition.word4'))
          })
      },
      // 完成
      confirmPop() {
        this.isLoading = true
        this.$http
          .post(service.submitRePayment, { applyId: this.applyId })
          .then(res => {
            if (Number(res.data.code) === 100000) {
              this.isLoading = false
              this.$router.push({ name: 'loandetails' })
            } else {
              this.isLoading = false
              this.$toast(res.data.message)
            }
          })
          .catch(() => {
            this.isLoading = false
          })
      }
    }
  }

</script>

<style scoped lang='scss'>
  .additional {
    height: 100%;
    background-color: #fff;

    .all-tip {
      margin-top: 98px;
      text-align: center;
      font-size: 28px;
      color: #333;

      span {
        color: #ff0000;
      }
    }

    .canvas_container {
      height: 0;
      width: 0;
      // overflow: hidden;
    }

    .main_body {
      padding-top: 86px;
      background-color: #fff;
      padding-bottom: 80px;
    }

    .block {
      height: 10px;

      background-color: #f5f5f5;
    }

    .signingNav {
      background: url('../fillinfo/images/navicon3.png') 0 0 no-repeat;
      background-size: 100% 100%;
    }

    .uploader_container {
      padding-top: 40px;
      background-color: #fff;

    }

    .van-uploader {
      float: left;
      visibility: hidden;
    }

    .placeholder {
      width: 560px;
      height: 330px;
      margin: 0 auto;

      border-radius: 7px;
      background-color: #f5f8ff;

      .plho {
        text-align: center;
      }

      .plh1 {
        width: 283px;
        height: 185px;
        margin-top: 44px;
      }

      .plh2 {
        width: 252px;
        height: 207px;
        margin-top: 28px;
      }

      .tip {
        font-size: 30px;

        margin-top: 16px;
        padding: 0 10px;

        color: #000;

        &.tip2 {
          margin-top: 10px;
        }
      }
    }

    .completebtn {
      font-size: 34px;
      line-height: 84px;

      width: 600px;
      height: 84px;
      margin: 70px auto 20px;

      text-align: center;

      color: #fff;
      border-radius: 10px;
      background: $themeBgColor;

      &.disabled {
        background: #ccc;
      }
    }

    .img_container {
      overflow: hidden;

      width: 100%;
      height: 100%;

      img {
        position: relative;
        top: 50%;
        left: 50%;

        max-width: 100%;
        max-height: 100%;

        transform: translate(-50%, -50%);

        &.rotate1 {
          width: 100%;
          height: auto;
          transform: translate(-50%, -50%) rotate(90deg);
        }

        &.rotate2 {
          height: 100%;
          width: auto;
          transform: translate(-50%, -50%) rotate(90deg);
        }
      }
    }

    .agree {
      font-size: 28px;

      text-align: center;

      color: #000;
    }
  }

</style>
