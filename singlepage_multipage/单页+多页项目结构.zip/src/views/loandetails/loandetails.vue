<template>
  <div class="loandetails">
    <loading v-if="isLoading"></loading>
    <comp-title :title="$t('message.loanDetails')" bg-color="rgb(26, 180, 53)" color="#fff" @clickLeft="clickLeft" :show-back="showBackBtn"></comp-title>
    <!-- <div class="payment-voucher">
      <p class="payment-voucher-title">{{$t('addition.word15')}}</p>
      <p class="payment-voucher-num">{{loanDetail.contractNo}}</p>
    </div> -->
    <div class="usermsg">
      <div class="username usercont">
        <!-- 客户姓名 -->
        <p class="namedesc btmtxtstyle">{{$t('message.clientName')}}</p>
        <!-- 姓名 -->
        <p class="uname txtstyle ellipsis">{{loanDetail.applyName}}</p>
      </div>
      <div class="line"></div>
      <div class="useridcard usercont">
        <!-- 身份证号 文案 -->
        <p class="carddesc btmtxtstyle">{{$t('message.idCard')}}</p>
        <!-- 身份证号 -->
        <p class="cardnum txtstyle">{{loanDetail.applyIdCard}}</p>
      </div>
    </div>
    <!-- <div class="repayment-tip">
      {{$t('addition.word16')}}
    </div> -->
    <ul class="contractdel">
      <!-- 合同编号 -->
      <li class="item">
        <span>{{$t('message.contractNo')}}</span>
        <span class="txtcolor-num">{{loanDetail.contractNo}}</span>
      </li>
      <!-- 到账金额 -->
      <li class="item">
        <span>{{$t('message.amountArrival')}}</span>
        <span>VND{{loanDetail.loanAmount | number(0,'.','.')}}</span>
      </li>
      <!-- 还款期限 -->
      <li class="item">
        <span>{{$t('message.repayPeriod')}}</span>
        <span class="txtcolor-data">{{loanDetail.repayDay}}{{$t('message.daysNum')}}</span>
      </li>
      <!-- 放款日期 -->
      <li class="item">
        <span>{{$t('message.loanDate')}}</span>
        <span>{{loanDetail.loanDate}}</span>
      </li>
      <!-- 还款日期 -->
      <li class="item">
        <span>{{$t('message.repayDate')}}</span>
        <span>{{loanDetail.repayDate}}</span>
      </li>
      <!-- 剩余还款额 -->
      <li class="item">
        <span>{{$t('message.RemaAmoun')}}</span>
        <span>VND{{loanDetail.leftAmount | number(0,'.','.')}}</span>
      </li>
      <!-- 合同状态 -->
      <li class="item">
        <span>{{$t('message.contractStatus')}}</span>
        <!-- 根据状态判断 待还款 / 已逾期 多少 天 -->
        <span class="txtcolor-time" v-if="loanDetail.applyStatus===6">{{$t('message.overdue')}} {{loanDetail.delayDay}} {{$t('message.overdueDays')}}</span>
        <span class="txtcolor-status" v-if="loanDetail.applyStatus===5">{{$t('message.pendRepayment')}}</span>
        <span class="txtcolor-status" v-if="loanDetail.applyStatus===7">{{$t('message.payOff')}}</span>
      </li>
    </ul>
    <!-- 还款 -->
    <button v-if="loanDetail.applyStatus!=7" class="repay" :class="[loanDetail.repaymentStatus !== '0' ? 'repay-bottom' : '']" @click="jump">{{$t('message.pendR')}}</button>
    <!-- 上传还款凭证 -->
    <button v-if="loanDetail.applyStatus!=7 && loanDetail.repaymentStatus === '0'" class="repay-voucher" @click="goRepayment">{{$t('addition.word17')}}</button>
    <!-- 上传还款凭证 -->
    <button v-if="loanDetail.applyStatus!=7 && loanDetail.repaymentStatus !== '0'" class="repay-voucher" @click="goRepayment">{{$t('addition.word18')}}</button>
  </div>
</template>
<script>
  import CompTitle from '@/components/Title'
  import service from '@/core/js/service'
  import Loading from '@/components/loading'
  export default {
    name: 'loandetails',
    components: {
      CompTitle,
      Loading
    },
    data() {
      return {
        isLoading: true,
        showBackBtn: true,
        loanDetail: {}
      }
    },
    created() {
      let applyId = this.$route.params.applyId || ''
      this.findLoanDetail(applyId).then(res => {
        // 取消loading
        if (res.data.applyStatus < 5) {
          this.$router.push('loanstatus')
          return
        } else if (res.data.applyStatus > 7 || !res.data.applyStatus) {
          window.location = './index.html'
          return
        }
        this.isLoading = false
        this.loanDetail = res.data
      })
    },
    methods: {
      clickLeft() {
        this.$router.go(-1)
      },
      findLoanDetail(applyId) {
        return this.$http.post(service.getLoanDetail, { applyId }).then(res => res.data)
      },
      jump() {
        // this.$router.push({ name: 'repayguide' })
        this.$router.push({ path: 'funpayRepayment', query: { contract_id: this.loanDetail.applyId } })
      },
      goRepayment() {
        this.$router.push({ name: 'repaymentimg', params: { applyId: this.loanDetail.applyId } })
      }
    }
  }

</script>
<style lang="scss" scoped>
  .loandetails {
    height: 100%;
    padding-top: 86px;
    background: #f7f7f7;

    .payment-voucher {
      overflow: hidden;
      padding: 32px 0 48px;
      background: rgb(26, 180, 53);
      ;

      p {
        line-height: 1;
        text-align: center;
        color: #fff;
      }

      .payment-voucher-title {
        font-size: 32px;
        font-weight: bold;
      }

      .payment-voucher-num {
        margin-top: 30px;
        font-size: 50px;
        font-weight: 500;
      }
    }

    .repayment-tip {
      background-color: rgba(166, 220, 174, 0.2);
      padding: 12px 52px;
      line-height: 42px;
      font-size: 24px;
      color: #27b13c;
    }

    .usermsg {
      display: flex;

      width: 100%;
      height: 160px;

      background-color: rgba(26, 180, 53, .9);

      align-items: center;

      .usercont {
        width: 49.5%;

        text-align: center;

        .txtstyle {
          font-size: 32px;
          font-weight: bold;
          line-height: 32px;

          height: 32px;

          color: #fff;
        }

        .btmtxtstyle {
          font-weight: 500;
          font-size: 26px;
          line-height: 26px;

          margin-bottom: 26px;

          height: 26px;

          color: #fff;
        }
      }

      .line {
        width: 2px;
        height: 54px;

        background: #e6e6e6;
      }
    }

    .contractdel {
      overflow: hidden;

      margin-top: 12px;
      padding-left: 30px;

      background: #fff;

      .item {
        display: flex;

        height: 90px;
        padding-right: 31px;

        border-bottom: 1px solid #e6e6e6;

        align-items: center;
        justify-content: space-between;

        span {
          font-size: 28px;
        }

        span:nth-of-type(1) {
          color: rgb(51, 51, 51);
        }

        span:nth-of-type(2) {
          color: rgb(153, 153, 153);
        }

        span.txtcolor-num {
          color: rgb(252, 136, 45);
        }

        span.txtcolor-data {
          color: rgb(102, 102, 102);
        }

        span.txtcolor-status {
          color: rgb(39, 177, 60);
        }

        span.txtcolor-time {
          color: #b71c1b;
        }
      }

      li.item:last-child {
        border-bottom: none;
      }
    }

    .repay {
      font-size: 32px;

      display: block;

      width: 670px;
      height: 90px;
      margin: 79px auto 0;

      color: #fff;
      border-radius: 10px;
      background: rgb(26, 180, 53);
      // box-shadow: 0 6px 10px rgba(39, 177, 60, 0.42);
    }

    .repay-bottom {
      margin-bottom: 60px;
    }

    .repay-voucher {
      font-size: 32px;

      display: block;
      background: #f7f7f7;
      width: 670px;
      height: 90px;
      border: 1px solid rgb(26, 180, 53);
      color: rgb(26, 180, 53);
      margin: 36px auto 54px;
      border-radius: 10px;
    }
  }

</style>
