import '../index/index.scss'
import './new.scss'
import axios from '@/core/js/api'
import util from '@/core/js/util'
import lang from '@/lang/index.js'

let loginBox = document.getElementById('login-box')
let leftMenu = document.getElementById('left-menu')
let mask = document.getElementById('mask')
let loadingBox = document.getElementById('loading')
// 贷款额度 DOM
let loanAmount = document.getElementById('loan-amount')
let loanAmountMin = document.getElementById('price-min')
let loanAmountMax = document.getElementById('price-max')
let repaymentValue = document.getElementById('repayment-price')
// 贷款期限 DOM
let repaymentDate = document.getElementById('repayment-date')

let appIdEle = document.getElementsByClassName('app-id')[0]
let redirectEle = document.getElementsByClassName('redirect')[0]
let stateEle = document.getElementsByClassName('state')[0]
let phoneNumberEle = document.getElementsByClassName('phone-number')[0]
let formEle = document.getElementById('form')
let phoneEle = document.getElementById('inp')

// 显示语言
let local = util.getQueryStringRegExp('local')
if (!local) {
  local = localStorage.getItem('local') || 'vn'
} else {
  local = local === 'zh' ? local : 'vn'
}
localStorage.setItem('local', local)

let flag = false
// let serviceFee = 0.021
// let dailyRate = 0.0004
let maxAmount = 0
// 页面用户信息
let userInfo = {}
// 用于存储贷款信息
let loanInfo = {
  loanAmount: '',
  loanDay: '',
  contractAmount: '',
  alsoAmount: ''
}
let trianlList = [] // 金额预算列表
let priceList = [] // 金额列表
// 渠道key
let channelKey
// facebook重定向url
let redirectUrl = process.env.VUE_APP_NEW_REDIRECT
// facebook跳转地址根据环境配置
redirectEle.value = process.env.VUE_APP_REDIRECTFB

let priceSlider // 滑块

function initSlider(conf) {
  // eslint-disable-next-line
  let slider = new Slider('#amount', {
    min: conf.min,
    max: conf.max,
    tooltip: 'hide',
    tooltip_position: 'top',
    step: conf.step,
    value: conf.value,
    rangeHighlights: [
      {
        start: conf.start,
        end: conf.max
      }
    ],
    formatter: (function(a) {
      return function(a) {
        return 'VND ' + a.toLocaleString('vi-vi') + ' '
      }
    })(this)
  })
  gl.setPrice(conf)

  slider.on('change', e => {
    if (e.newValue > conf.start) {
      document.querySelector('.slider-rangeHighlight').classList.add('active')
      document.querySelector('.sliders-top').classList.add('active')
      slider.setAttribute('rangeHighlights', [
        {
          start: conf.start,
          end: e.newValue
        }
      ])
    } else if (e.newValue <= conf.start) {
      document.querySelector('.slider-rangeHighlight').classList.remove('active')
      document.querySelector('.sliders-top').classList.remove('active')
    }
    conf.value = e.newValue
    gl.setPrice(conf)
  })

  return slider
}

// toast
let bw = {}
bw.list = []
bw.timer = null
bw.toast = function(txt) {
  if (bw.list.length) {
    clearTimeout(bw.timer)

    bw.list[0].parentNode.removeChild(bw.list[0])
    bw.list.shift()
  }
  let toast = document.createElement('div')
  toast.classList = 'bw-toast'
  toast.setAttribute('style', 'opacity: 0;')

  let msg = document.createTextNode(txt)
  toast.append(msg)
  bw.list.push(toast)
  document.body.append(toast)

  setTimeout(function() {
    toast.setAttribute('style', 'opacity: 1;')
  }, 0)
  bw.timer = setTimeout(function() {
    toast.parentNode.removeChild(toast)
    bw.list.shift()
  }, 2000)
}

window.gl = {
  // 跳转
  jump: index => {
    switch (index) {
      case 1:
        //  贷款记录
        window.location = 'main.html#/loanhistory'
        break
      case 2:
        //  还款指南
        window.location = 'main.html#/repayguide'
        break
      case 3:
        //  关于我们
        window.location = 'main.html#/aboutus'
        break
      default:
        break
    }
  },
  // 设置贷款额度
  setPrice: conf => {
    loanAmount.innerHTML = conf.value.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1.')
    loanAmountMin.innerHTML = conf.min.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1.')
    loanAmountMax.innerHTML = conf.max.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1.')

    gl.computeAmount(Number(conf.value), loanInfo.loanDay)
  },
  // 设置贷款日期
  setDate: value => {
    repaymentDate.innerHTML = gl.parseDate(value)
    loanInfo.loanDay = value
    gl.computeAmount(Number(loanInfo.loanAmount), value)
  },
  parseDate: daysNum => {
    let date1 = new Date()
    let date2 = new Date(date1)
    date2.setDate(date1.getDate() + (daysNum - 1))
    const year = date2.getFullYear()
    const month = date2.getMonth() + 1 < 10 ? '0' + (date2.getMonth() + 1) : '' + (date2.getMonth() + 1)
    const day = date2.getDate() < 10 ? '0' + date2.getDate() : '' + date2.getDate()
    return day + '.' + month + '.' + year
  },
  // 计算还款额
  computeAmount: (amount, day) => {
    let priceIndex = priceList.findIndex(e => e === amount)
    let amountItem
    if (priceIndex < 0) {
      amountItem = { contractAmount: 0, repayAmount: 0 }
    } else {
      amountItem = trianlList[priceIndex]
    }
    loanInfo.loanAmount = amount // 借款金额
    loanInfo.contractAmount = amountItem.contractAmount // 合同金额 展示为借款金额
    loanInfo.alsoAmount = amountItem.repayAmount // 应还金额
    repaymentValue.innerHTML = amountItem.repayAmount.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1.')
  },
  // 返回登陆状态
  checkLogin: () => {
    return !!util.getCookie('uid')
  },
  // 显示登陆
  showLogin: () => {
    loginBox.classList.add('show')
  },
  hideLogin: () => {
    loginBox.classList.remove('show')
    phoneEle.value = ''
  },
  // 登陆
  submit: () => {
    if (flag) {
      return false
    }
    let phone = phoneEle.value
    let reg = /^0\d{9}$/
    let reg1 = /^(\d)\1+$/

    if (!reg.test(phone) || reg1.test(phone)) {
      bw.toast(window.$i18n('w15'))
      return false
    }

    flag = true
    gl.switchLoding(true)
    if (window.requestIdleCallback) {
      requestIdleCallback(function() {
        Fingerprint2.get(function(components) {
          gl.initFb(phone, JSON.stringify(components))
        })
      })
    } else {
      setTimeout(function() {
        Fingerprint2.get(function(components) {
          gl.initFb(phone, JSON.stringify(components))
        })
      }, 500)
    }
  },
  initFb: (phone, components) => {
    axios
      .post('/fblogin/initfb', {
        phone: phone,
        channel: 'vnh5',
        channelName: channelKey,
        deviceInfo: components,
        redirectUrl
      })
      .then(res => {
        let result = res.data.data
        appIdEle.value = result.appId
        stateEle.value = result.state
        phoneNumberEle.value = phone
        formEle.submit()
        gl.switchLoding(false)
        flag = false
      })
      .catch(() => {
        gl.switchLoding(false)
        flag = false
      })
  },
  showMenu: () => {
    leftMenu.classList.add('show')
    mask.classList.add('show')
  },
  hideMenu: () => {
    leftMenu.classList.remove('show')
    mask.classList.remove('show')
  },
  goDetail: () => {
    if (!gl.checkLogin()) {
      gl.showLogin()
      return false
    }
    if ((userInfo.status === 7 || userInfo.status === 8) && loanInfo.loanAmount > maxAmount) {
      bw.toast(window.$i18n('w20') + maxAmount.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1.') + window.$i18n('w21'))
      priceSlider.setValue(maxAmount, true, true)
      return
    }
    localStorage.setItem('loanInfo', JSON.stringify(loanInfo))
    // 1:审核中 2:审核拒绝 3:放款中 4::放款失败 5:待还款 6:已逾期 7:已结清/可复借 8:无借款记录
    if (userInfo.status <= 4) {
      window.location = 'main.html#/loanstatus'
    } else if (userInfo.status === 5 || userInfo.status === 6) {
      window.location = 'main.html#/loandetails'
    } else if (userInfo.status === 7) {
      //  已结清，复借
      window.location = 'main.html#/signingagain'
    } else if (userInfo.status === 8) {
      // 新用户未借款
      window.location = 'main.html#/personalinfo'
    }
  },
  findUserInfo: () => {
    // 获取用户信息
    return axios.post('/user/info').then(data => {
      return data
    })
  },
  findProductInfo: () => {
    // 获取费率详情
    return axios.post('/loan/product_info').then(data => {
      return data
    })
  },
  getLocation: () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        function(position) {
          var latitude = position.coords.latitude // 纬度
          var longitude = position.coords.longitude // 经度
          localStorage.setItem('positionInfo', JSON.stringify({ latitude, longitude }))
        },
        function(error) {
          console.log(error)
        }
      )
    }
  },
  findPageInfo: status => {
    let btnText = ''
    switch (status) {
      case 1: // 审核中 查看审核进度
        btnText = window.$i18n('w16')
        break
      case 2: // 审核拒绝 查看审核进度
        btnText = window.$i18n('w16')
        break
      case 3: // 放款中 查看放款进度
        btnText = window.$i18n('w17')
        break
      case 4: // 放款失败 查看审核进度
        btnText = window.$i18n('w17')
        break
      case 5: // 待还款  立即还款
        btnText = window.$i18n('w18')
        break
      case 6: // 已逾期  立即还款
        btnText = window.$i18n('w18')
        break
      case 7: // 已结清/  立即申请
        btnText = window.$i18n('w10')
        break
      case 8: // 无借款记录  立即申请
        btnText = window.$i18n('w10')
        break

      default:
        break
    }
    return btnText
  },
  switchLoding: state => {
    if (state) {
      loadingBox.classList.add('show')
    } else {
      loadingBox.classList.remove('show')
    }
  },
  h5config: () => {
    axios.get(`/h5_config?channelKey=${channelKey}`)
  },
  warning: () => {
    bw.toast(window.$i18n('w19'))
  },
  setProduct: async priceConf => {
    gl.switchLoding(true)

    let res = await gl.findProductInfo()
    if (res.data.code === 100000) {
      let result = res.data.data
      priceConf.max = result.showMaxAmount || 0
      priceConf.min = result.showMinAmount || 0
      priceConf.start = result.maxAmount || 0
      priceConf.value = result.maxAmount || 0
      maxAmount = result.maxAmount || 0
      trianlList = gl.findTrianList(result.trialResultList).trianlList
    } else {
      bw.toast(res.data.message)
    }
  },
  priceArr: (start, end, step) => {
    let arr = []
    if (!start || !end || !step || start > end) return [0]
    for (let i = start; i <= end; i += step) {
      arr.push(i)
    }
    return arr
  },
  findTrianList: trialResultList => {
    return trialResultList[0]
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  util.i18n(lang, local)

  let uid = util.getQueryStringRegExp('uid') || ''
  let token = util.getQueryStringRegExp('token') || ''
  channelKey = util.getQueryStringRegExp('channelKey') || ''
  if (uid) {
    util.setCookie('uid', uid, 30)
  }
  if (token) {
    util.setCookie('token', token, 30)
  }
  let login = document.getElementById('login')
  let buttonConfirm = document.getElementById('button-confirm')
  let priceConf = { min: 0, max: 0, value: 0, step: 500000, start: 0, maxAmount: 0 }
  // 获取用户地理位置
  gl.getLocation()
  // 用户已登陆 获取用户信息
  if (gl.checkLogin()) {
    // 页面loading 状态
    util.setCookie('uid', util.getCookie('uid'), 30)
    util.setCookie('token', util.getCookie('token'), 30)
    axios.defaults.headers.common['uid'] = util.getCookie('uid')
    axios.defaults.headers.common['token'] = util.getCookie('token')
    gl.switchLoding(true)
    // 已登陆 隐藏登陆按钮
    login.classList.add('hidden')
    // 获取用户信息
    let res = await gl.findUserInfo()
    if (res.data.code === 100000) {
      let result = res.data.data
      userInfo = result
      if (result.status <= 4) {
        window.location = 'main.html#/loanstatus'
        return
      } else if (result.status === 5 || result.status === 6) {
        window.location = 'main.html#/loandetails'
        return
      } else {
        // 设置用户可借款最大额度
        priceConf.max = result.productInfo.showMaxAmount || 0
        priceConf.min = result.productInfo.showMinAmount || 0
        priceConf.start = result.productInfo.maxAmount || 0
        priceConf.value = result.productInfo.maxAmount || 0
        maxAmount = result.productInfo.maxAmount || 0
        trianlList = gl.findTrianList(result.productInfo.trialResultList).trianlList
        // 根据用户状态设置按钮文案
        buttonConfirm.innerHTML = gl.findPageInfo(result.status)
      }
    } else if (res.data.code === 500003 || res.data.code === 500009) {
      util.setCookie('uid', ' ', -1)
      util.setCookie('token', ' ', -1)
      axios.defaults.headers.common['uid'] = util.getCookie('uid')
      axios.defaults.headers.common['token'] = util.getCookie('token')
      login.classList.remove('hidden')
      await gl.setProduct(priceConf)
    } else {
      bw.toast(res.data.message)
    }
  } else {
    await gl.setProduct(priceConf)
  }
  gl.h5config()
  // 设置滑块
  priceList = gl.priceArr(priceConf.min, priceConf.max, priceConf.step)
  priceSlider = initSlider(priceConf)
  gl.setDate(10)
  gl.switchLoding(false)
})
document.addEventListener('touchstart', e => {
  e.stopPropagation()
  // e.preventDefault()
  return false
})
