import './app.scss'
import Vue from 'vue'
import App from './App.vue'
import router from './router'
import axios from '@/core/js/api'
import i18n from '@/lang/lang.js'
import { Locale, Lazyload } from 'vant'
import vn from '@/lang/vant_vn'
import util from '@/core/js/util'
import { number } from '@/core/js/filter'

// 获取浏览器设备指纹  https://github.com/Valve/fingerprintjs2
if (window.requestIdleCallback) {
  requestIdleCallback(function() {
    Fingerprint2.get(
      {
        excludes: {
          canvas: true,
          webgl: true
        }
      },
      function(components) {
        var browserInfoArr = []
        var values = components.map(function(component) {
          browserInfoArr.push(component)
          return component.value
        })

        // 浏览器id
        var murmur = Fingerprint2.x64hash128(values.join(''), 31)
        window.browserInfo = JSON.stringify(browserInfoArr)
        window.browserId = murmur
      }
    )
  })
} else {
  setTimeout(function() {
    Fingerprint2.get(
      {
        excludes: {
          canvas: true,
          webgl: true
        }
      },
      function(components) {
        var browserInfoArr = []
        var values = components.map(function(component) {
          browserInfoArr.push(component)
          return component.value
        })

        // 浏览器id
        var murmur = Fingerprint2.x64hash128(values.join(''), 31)
        window.browserInfo = JSON.stringify(browserInfoArr)
        window.browserId = murmur
      }
    )
  }, 500)
}

Vue.use(Lazyload)

let local = localStorage.getItem('local')
if (!local || local !== 'zh') {
  Locale.use('vn', vn)
}

Vue.config.productionTip = false

// 路由跳转判断
router.beforeEach((to, from, next) => {
  // 关于我们， 贷款指南不需要登陆校验
  if (to.name === 'aboutus' || to.name === 'repayguide' || to.name === 'transition' || to.name === 'login') {
    next()
  } else {
    if (util.getCookie('uid')) {
      next()
      axios.defaults.headers.common['uid'] = util.getCookie('uid')
      axios.defaults.headers.common['token'] = util.getCookie('token')
    } else {
      window.location = './index.html'
    }
  }
})

Vue.prototype.$http = axios
Vue.filter('number', number)

new Vue({
  i18n,
  router,
  render: h => h(App)
}).$mount('#app')
