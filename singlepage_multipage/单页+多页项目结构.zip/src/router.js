import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

export default new Router({
  routes: [
    // 个人信息
    {
      path: '/personalinfo',
      name: 'personalinfo',
      component: () => import(/* webpackChunkName: "personalinfo" */ './views/fillinfo/personalinfo/personalinfo.vue')
    },
    // 联系信息
    {
      path: '/contactinfo',
      name: 'contactinfo',
      component: () => import(/* webpackChunkName: "contactinfo" */ './views/fillinfo/contactinfo/contactinfo.vue')
    },
    // 补充信息
    {
      path: '/additional',
      name: 'additional',
      component: () => import(/* webpackChunkName: "additional" */ './views/fillinfo/additional/additional.vue')
    },
    // 工作信息
    {
      path: '/workinfo',
      name: 'workinfo',
      component: () => import(/* webpackChunkName: "workinfo" */ './views/fillinfo/workinfo/workinfo.vue')
    },
    // 签约
    {
      path: '/sign',
      name: 'sign',
      component: () => import(/* webpackChunkName: "sign" */ './views/fillinfo/sign/sign.vue')
    },
    // 复借
    {
      path: '/signingagain',
      name: 'signingagain',
      component: () => import(/* webpackChunkName: "signingagain" */ './views/fillinfo/signingagain/signingagain.vue')
    },
    // 贷款历史
    {
      path: '/loanhistory',
      name: 'loanhistory',
      component: () => import(/* webpackChunkName: "loanhistory" */ './views/loanhistory/loanhistory.vue')
    },
    // 贷款详情
    {
      path: '/loandetails/:applyId?',
      name: 'loandetails',
      component: () => import(/* webpackChunkName: "loandetails" */ './views/loandetails/loandetails.vue')
    },
    // 关于我们
    {
      path: '/aboutus',
      name: 'aboutus',
      component: () => import(/* webpackChunkName: "aboutus" */ './views/aboutus/aboutus.vue')
    },
    // 还款指南
    {
      path: '/repayguide',
      name: 'repayguide',
      component: () => import(/* webpackChunkName: "repayguide" */ './views/repayguide/repayguide.vue')
    },
    // 贷款状态
    {
      path: '/loanstatus/:applyId?',
      name: 'loanstatus',
      component: () => import(/* webpackChunkName: "loanstatus" */ './views/loanstatus/loanstatus.vue')
    },
    // 上传还款凭证
    {
      path: '/repaymentimg/:applyId',
      name: 'repaymentimg',
      component: () => import(/* webpackChunkName: "repaymentimg" */ './views/repaymentimg/repaymentimg.vue')
    },
    // 获取vc码页面
    {
      path: '/funpayRepayment',
      name: 'funpayRepayment',
      component: () => import(/* webpackChunkName: "funpayRepayment" */ './views/funpayRepayment/funpayRepayment.vue')
    },
    {
      path: '/login',
      name: 'login',
      component: () => import(/* webpackChunkName: "login" */ './views/login/login.vue')
    }
  ]
})
