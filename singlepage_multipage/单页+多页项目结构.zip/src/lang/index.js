// 首页国际化资源
export default {
  zh: {
    w1: '登陆',
    w2: '借款金额',
    w3: '借款期限',
    w4: '天',
    w5: '还款日期',
    w6: '到期应还',
    w7: '贷款历史',
    w8: '还款指南',
    w9: '关于我们',
    w10: '立即申请',
    w11: '客服',
    w12: '请填写开户手机号',
    w13: '确定',
    w14: '请输入手机号',
    w15: '请输入正确的手机号',
    w16: '查看审核状态',
    w17: '查看放款进度',
    w18: '立即还款',
    w19: '抱歉，目前只针对信用资质极佳及复贷用户开放，请积累信用资质（节假日优惠活动不定期开放）',
    w20: '抱歉，高于',
    w21: '目前只针对信用资质极佳及复贷用户开放，请积累信用资质（节假日优惠活动不定期开放）'
  },
  vn: {
    w1: 'Đăng nhập',
    w2: 'Số tiền vay',
    w3: 'Kỳ hạn vay',
    w4: 'Ngày',
    w5: 'Thời gian hoàn trả',
    w6: 'Đến kỳ phải trả',
    w7: 'Lịch sử vay mượn',
    w8: 'Hướng dẫn vay tiền',
    w9: 'Về chúng tôi',
    w10: 'Đăng ký ngay',
    w11: 'Chăm sóc khách hàng',
    w12: 'Nhập số điện thoại',
    w13: 'Xác nhận',
    w14: 'Vui lòng nhập số điện thoại của bạn',
    w15: 'Xin mời điền số điện thoại',
    w16: 'Kiểm tra trạng thái xét duyệt',
    w17: 'Kiểm tra trạng thái chuyển khoản',
    w18: 'Hoàn tiền ngay',
    w19:
      'xin thông cảm, hiện tại chỉ hỗ trợ các khách hàng cấp cao, xin vui lòng tích lũy kinh nghiệm (các sự kiện ưu đãi được tổ chức không định kỳ)',
    w20: 'xin thông cảm, mức vay',
    w21:
      'hiện tại chỉ áp dụng cho các khách hàng cấp cao, xin hãy tích lũy điểm kinh nghiệm (các sự kiện ưu đãi có thể được triển khai không định kỳ)'
  }
}
