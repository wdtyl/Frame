<template>
  <div class="comp-title" :style="styleObject">
    <div class="left">
      <div class="left-corner clear" @click="clickLeft">
        <div class="corner-box fl" v-if="showBack">
          <van-icon class="corner" name="arrow-left" />
        </div>
        <span v-if="backText && !$slots.left">{{backText}}</span>
        <slot v-else-if="$slots.left" name="left" />
      </div>
    </div>
    <div class="middle">{{title}}</div>
    <div class="right" @click="clickRight">
      <div v-if="!$slots.right">{{rightText}}</div>
      <div v-else>
        <slot name="right" />
      </div>
    </div>
  </div>
</template>

<script>
  import Vue from 'vue';
  import {
    Icon
  } from 'vant';

  Vue.use(Icon);
  export default {
    props: {
      title: String,
      showBack: {
        type: Boolean,
        default: false
      },
      backText: String,
      backUrl: String,
      rightText: String,
      rightUrl: String,
      color: String,
      bgColor: {
        type: String,
        default: '#fff'
      },
      borderColor: String
    },
    data() {
      return {
        styleObject: {
          background: this.bgColor,
          color: this.color,
          borderBottom: ''
        }
      };
    },
    methods: {
      clickLeft() {
        this.$emit('clickLeft');
      },
      clickRight() {
        this.$emit('clickRight');
      }
    },
    mounted() {
      if (this.borderColor) {
        this.styleObject.borderBottom = `1px solid ${this.borderColor}`;
      }
    }
  };

</script>

<style lang="scss" scoped>
  .comp-title {
      font-size: 32px;
      line-height: 86px;

      position: fixed;
      z-index: 999;
      top: 0;
      right: 0;
      left: 0;

      height: 86px;

      .left {
          line-height: 86px;

          position: absolute;
          left: 20px;

          .left-corner {
              line-height: 86px;

              .corner {
                  font-size: 32px;

                  position: relative;
                  top: 3px;

                  // vertical-align: middle;
                  &::after {
                      position: absolute;
                      top: -20px;
                      right: -20px;
                      bottom: -20px;
                      left: -20px;

                      content: '';
                  }
              }
          }

          .back-icon {
              position: relative;

              display: inline-block;

              width: 20px;
              height: 86px;
              margin-right: 10px;

              vertical-align: text-top;

              background: url(images/title/back-icon.png) no-repeat center center;
              background-size: contain;

              &::after {
                  position: absolute;
                  top: 0;
                  right: -30px;
                  bottom: 0;
                  left: -20px;

                  content: '';
              }
          }
      }

      .middle {
          font-size: 36px;

          box-sizing: border-box;
          max-width: 60%;
          margin: 0 auto;

          text-align: center;
      }

      .right {
          position: absolute;
          top: 0;
          right: 20px;
      }
  }

</style>
