<template>
  <div class="signingTop">
    <ul class="">
      <li><span>{{$t('message.applyAmount')}}</span><em>VND{{info.loanAmount | number(0,'.','.')}}</em></li>
      <li><span>{{$t('message.loanTerm')}}</span><em>{{info.loanDay}}{{$t('message.daysNum')}}</em></li>
      <li><span>{{$t('message.repayAmount')}}</span><em>VND{{info.alsoAmount | number(0,'.','.')}}</em></li>
    </ul>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        info: {}
      }
    },
    created() {
      let loanInfo = JSON.parse(localStorage.getItem('loanInfo')) || {}
      this.info = loanInfo
      if (!loanInfo.contractAmount && !loanInfo.loanDay) {
        window.location = './index.html'
      }
    }
  }

</script>

<style lang="scss" scoped>
  .signingTop {
    font-size: 32px;

    width: 100%;
    padding: 20px 30px;

    color: #fff;
    background: $themeBgColor;

    li {
      line-height: 45px;

      height: 45px;
      }

    span {
      float: left;

      width: 50%;

      text-align: left;
      }

    em {
      font-style: normal;

      float: right;

      width: 50%;

      text-align: right;
      }
    }

</style>
