<template>
  <div class="loading">
    <div class="loading-img"></div>
  </div>
</template>
<script>
  export default {

  }

</script>
<style lang="scss" scoped>
  .loading {
    position: fixed;
    z-index: 9999;
    top: 0;
    left: 0;

    width: 100%;
    height: 100%;

    background: rgba(0, 0, 0, .3);

    .loading-img {
      position: absolute;
      top: 50%;
      left: 50%;

      width: 100px;
      height: 100px;

      transform: translate(-50%, -50%);

      background: url('images/loading.gif') no-repeat center center;
    }
  }

</style>
